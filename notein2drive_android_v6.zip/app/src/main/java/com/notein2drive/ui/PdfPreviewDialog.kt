package com.notein2drive.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Full-screen scrollable multi-page PDF viewer powered by Android's native `PdfRenderer`.
 * Renders all pages lazily inside a `LazyColumn` with an in-memory LRU cache and zoom controls.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfPreviewDialog(
    pdfFile: File,
    title: String,
    onDismiss: () -> Unit,
) {
    var pageCount by remember(pdfFile) { mutableIntStateOf(0) }
    var errorMsg by remember(pdfFile) { mutableStateOf<String?>(null) }
    var zoomFactor by remember(pdfFile) { mutableFloatStateOf(1.0f) }

    val renderMutex = remember(pdfFile) { Mutex() }
    val bitmapCache = remember(pdfFile) {
        object : LruCache<Int, Bitmap>(12) {}
    }

    var holder by remember(pdfFile) { mutableStateOf<Pair<ParcelFileDescriptor, PdfRenderer>?>(null) }

    DisposableEffect(pdfFile) {
        try {
            if (!pdfFile.exists()) {
                errorMsg = "PDF file not found"
            } else {
                val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                holder = pfd to renderer
                pageCount = renderer.pageCount
                if (pageCount <= 0) errorMsg = "PDF has no pages"
            }
        } catch (e: Exception) {
            errorMsg = e.message ?: "Failed to open PDF"
        }

        onDispose {
            bitmapCache.evictAll()
            runCatching { holder?.second?.close() }
            runCatching { holder?.first?.close() }
            holder = null
        }
    }

    val listState = rememberLazyListState()
    val visiblePage by remember {
        derivedStateOf { (listState.firstVisibleItemIndex + 1).coerceIn(1, maxOf(1, pageCount)) }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            if (pageCount > 0) {
                                Text(
                                    "Page $visiblePage of $pageCount  •  Scroll for all pages",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close preview")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { zoomFactor = (zoomFactor - 0.25f).coerceAtLeast(0.75f) },
                            enabled = zoomFactor > 0.75f,
                        ) {
                            Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom out")
                        }
                        IconButton(
                            onClick = { zoomFactor = (zoomFactor + 0.25f).coerceAtMost(2.5f) },
                            enabled = zoomFactor < 2.5f,
                        ) {
                            Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom in")
                        }
                    },
                )
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(Color(0xFF0B1120)),
                contentAlignment = Alignment.Center,
            ) {
                when {
                    errorMsg != null -> Text(
                        errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(24.dp),
                    )

                    pageCount > 0 && holder != null -> {
                        val renderer = holder!!.second
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(pageCount, key = { it }) { idx ->
                                PdfPageCard(
                                    renderer = renderer,
                                    pageIndex = idx,
                                    pageCount = pageCount,
                                    zoomFactor = zoomFactor,
                                    mutex = renderMutex,
                                    cache = bitmapCache,
                                )
                            }
                        }
                    }

                    else -> CircularProgressIndicator()
                }
            }
        }
    }
}

@Composable
private fun PdfPageCard(
    renderer: PdfRenderer,
    pageIndex: Int,
    pageCount: Int,
    zoomFactor: Float,
    mutex: Mutex,
    cache: LruCache<Int, Bitmap>,
) {
    var bmp by remember(pageIndex) { mutableStateOf(cache.get(pageIndex)) }

    LaunchedEffect(pageIndex) {
        if (bmp == null) {
            val rendered = withContext(Dispatchers.IO) {
                mutex.withLock {
                    cache.get(pageIndex) ?: runCatching {
                        renderer.openPage(pageIndex).use { page ->
                            val scale = 1.75f
                            val w = (page.width * scale).toInt().coerceIn(200, 1800)
                            val h = (page.height * scale).toInt().coerceIn(200, 2600)
                            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            Canvas(b).drawColor(AndroidColor.WHITE)
                            page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            cache.put(pageIndex, b)
                            b
                        }
                    }.getOrNull()
                }
            }
            bmp = rendered
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth(),
    ) {
        if (bmp != null) {
            val aspect = bmp!!.width.toFloat() / bmp!!.height.toFloat().coerceAtLeast(1f)
            Image(
                bitmap = bmp!!.asImageBitmap(),
                contentDescription = "Page ${pageIndex + 1}",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth(zoomFactor.coerceAtMost(1f))
                    .aspectRatio(aspect)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White),
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(modifier = Modifier.size(28.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Page ${pageIndex + 1} of $pageCount",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF94A3B8),
        )
    }
}
