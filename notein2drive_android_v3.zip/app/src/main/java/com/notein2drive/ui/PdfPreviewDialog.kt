package com.notein2drive.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Built-in full-screen PDF viewer powered by Android's native `PdfRenderer`.
 * Supports multi-page navigation and pinch-to-zoom / pan gestures.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfPreviewDialog(
    pdfFile: File,
    title: String,
    onDismiss: () -> Unit,
) {
    var pageIndex by remember(pdfFile) { mutableIntStateOf(0) }
    var pageCount by remember(pdfFile) { mutableIntStateOf(0) }
    var bitmap by remember(pdfFile) { mutableStateOf<Bitmap?>(null) }
    var errorMsg by remember(pdfFile) { mutableStateOf<String?>(null) }
    var loading by remember(pdfFile) { mutableStateOf(true) }

    var scale by remember(pdfFile, pageIndex) { mutableFloatStateOf(1f) }
    var offset by remember(pdfFile, pageIndex) { mutableStateOf(Offset.Zero) }

    LaunchedEffect(pdfFile, pageIndex) {
        loading = true
        errorMsg = null
        val rendered = withContext(Dispatchers.IO) {
            try {
                if (!pdfFile.exists()) {
                    throw IllegalStateException("PDF file not found")
                }
                ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        val total = renderer.pageCount
                        if (total <= 0) {
                            return@withContext Triple(0, null, "PDF has no pages")
                        }
                        val safeIdx = pageIndex.coerceIn(0, total - 1)
                        renderer.openPage(safeIdx).use { page ->
                            val renderScale = 2.0f
                            val w = (page.width * renderScale).toInt().coerceIn(200, 2400)
                            val h = (page.height * renderScale).toInt().coerceIn(200, 3400)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            val canvas = Canvas(bmp)
                            canvas.drawColor(AndroidColor.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            Triple(total, bmp, null)
                        }
                    }
                }
            } catch (e: Exception) {
                Triple(0, null, e.message ?: "Failed to render PDF")
            }
        }
        pageCount = rendered.first
        bitmap = rendered.second
        errorMsg = rendered.third
        loading = false
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            if (pageCount > 0) {
                                Text(
                                    "Page ${pageIndex + 1} of $pageCount  •  Pinch to zoom",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close preview")
                        }
                    },
                    actions = {
                        if (scale > 1.05f) {
                            IconButton(onClick = { scale = 1f; offset = Offset.Zero }) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "Reset zoom")
                            }
                        }
                    },
                )
            },
            bottomBar = {
                if (pageCount > 1) {
                    Surface(tonalElevation = 4.dp) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            FilledTonalButton(
                                onClick = { if (pageIndex > 0) pageIndex-- },
                                enabled = pageIndex > 0,
                            ) {
                                Icon(Icons.Rounded.ChevronLeft, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("Previous")
                            }
                            Text(
                                "${pageIndex + 1} / $pageCount",
                                style = MaterialTheme.typography.labelLarge,
                            )
                            FilledTonalButton(
                                onClick = { if (pageIndex < pageCount - 1) pageIndex++ },
                                enabled = pageIndex < pageCount - 1,
                            ) {
                                Text("Next")
                                Spacer(Modifier.width(4.dp))
                                Icon(Icons.Rounded.ChevronRight, contentDescription = null)
                            }
                        }
                    }
                }
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(Color(0xFF0B1120))
                    .pointerInput(pageIndex) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (scale * zoom).coerceIn(1f, 5f)
                            scale = newScale
                            offset = if (newScale > 1f) {
                                Offset(offset.x + pan.x, offset.y + pan.y)
                            } else {
                                Offset.Zero
                            }
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                when {
                    loading -> CircularProgressIndicator()
                    errorMsg != null -> Text(
                        errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(24.dp),
                    )
                    bitmap != null -> Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = title,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offset.x,
                                translationY = offset.y,
                            ),
                    )
                }
            }
        }
    }
}
