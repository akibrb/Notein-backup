package com.notein2drive.sync

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * Exports all converted PDFs from the internal mirror directory into any user-selected
 * Android device folder (via Storage Access Framework `OpenDocumentTree`) preserving
 * the exact nested folder hierarchy.
 */
object LocalExporter {

    data class ExportResult(
        val exported: Int,
        val skipped: Int,
        val failed: Int,
    )

    fun exportHierarchyToTree(
        context: Context,
        mirrorRoot: File,
        destTreeUri: Uri,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
        log: (String) -> Unit = {},
    ): ExportResult {
        val rootDoc = DocumentFile.fromTreeUri(context, destTreeUri)
            ?: throw IllegalArgumentException("Cannot access selected destination folder")

        val pdfFiles = mirrorRoot.walkTopDown()
            .filter { it.isFile && it.name.lowercase().endsWith(".pdf") }
            .sortedBy { it.relativeTo(mirrorRoot).path.lowercase() }
            .toList()

        if (pdfFiles.isEmpty()) {
            return ExportResult(0, 0, 0)
        }

        val dirCache = HashMap<String, DocumentFile>()
        dirCache[""] = rootDoc

        fun ensureDir(parts: List<String>): DocumentFile {
            var current = rootDoc
            var key = ""
            for (part in parts) {
                key = if (key.isEmpty()) part else "$key/$part"
                val cached = dirCache[key]
                if (cached != null) {
                    current = cached
                } else {
                    val existing = current.findFile(part)?.takeIf { it.isDirectory }
                    val next = existing ?: current.createDirectory(part)
                        ?: throw IllegalStateException("Could not create folder '$part'")
                    dirCache[key] = next
                    current = next
                }
            }
            return current
        }

        var exported = 0
        var skipped = 0
        var failed = 0

        pdfFiles.forEachIndexed { idx, pdf ->
            val rel = pdf.relativeTo(mirrorRoot).path.replace(File.separatorChar, '/')
            val segments = rel.split('/')
            val folderParts = segments.dropLast(1)
            val fileName = segments.last()

            try {
                val targetDir = ensureDir(folderParts)
                val existing = targetDir.findFile(fileName)
                if (existing != null && existing.isFile && existing.length() == pdf.length()) {
                    skipped++
                    log("= Local $rel (unchanged)")
                } else {
                    existing?.delete()
                    val created = targetDir.createFile("application/pdf", fileName.removeSuffix(".pdf"))
                        ?: throw IllegalStateException("Could not create $rel")
                    context.contentResolver.openOutputStream(created.uri)?.use { out ->
                        pdf.inputStream().use { input -> input.copyTo(out) }
                    } ?: throw IllegalStateException("Could not write $rel")
                    exported++
                    log("+ Saved locally: $rel")
                }
            } catch (e: Exception) {
                failed++
                log("! Export failed ($rel): ${e.message}")
            }
            onProgress(idx + 1, pdfFiles.size)
        }

        return ExportResult(exported, skipped, failed)
    }
}
