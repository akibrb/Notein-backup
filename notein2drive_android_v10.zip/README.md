# Notein2Drive (Native Android App)

Native Kotlin + Jetpack Compose Android app that scans Notein backups (`.zip`), designated folders (via Android Storage Access Framework, including nested `.zip` archives), or individual `.in` files, converts every note to a vector PDF on-device using Android's `PdfDocument`, and mirrors the exact folder hierarchy into a separate Google Drive folder.

## Features
* **100% On-Device Vector Conversion**: Unpacks `.in` files to a temporary cache directory so SQLite replays `-wal`/`-shm` cleanly, decodes Notein's protobuf strokes (`PbParse` + `StrokeDecoder`), applies 3x3 matrices, pressure-calibrated widths, and Catmull-Rom splines, and draws vector PDFs via `android.graphics.pdf.PdfDocument`.
* **Exact Folder Hierarchy**: Combines on-disk subfolders + nested `.zip` backups + Notein `folder_tree/folder.tree` (`folder_tree.json` + `note_meta.json.parentId`), strips `n_<uuid>` wrappers, skips trashed notes/folders by default, handles cycles/orphans (`_Unknown folder <id8>`), and disambiguates duplicate titles.
* **Google Drive v3 Mirror**: Creates folders idempotently, tags each uploaded PDF with `appProperties.notein_id`, updates/moves files in place on re-sync, retries transient HTTP 429/5xx errors, and supports **Prune** (moves deleted notes and empty subfolders to Drive Trash).
* **Crash-Safe Incremental Sync**: Saves `.notein_manifest.json` after every single note so interruptions never lose progress, and isolates bad notes so one failure never stops the batch.

## Setup & Build (Android Studio)

1. **Unzip and open** this folder in **Android Studio (Ladybug / 2024.2+)** with JDK 17.
2. **One-time Google Cloud Console setup (for Google Drive Sign-In)**:
   * Open [Google Cloud Console](https://console.cloud.google.com/) -> select/create a project -> enable **Google Drive API**.
   * Configure **OAuth consent screen** (External) -> add your Google email under **Test users**.
   * Go to **Credentials -> Create Credentials -> OAuth client ID -> Android**:
     * **Package name**: `com.notein2drive`
     * **SHA-1 certificate fingerprint**: run `./gradlew signingReport` in Android Studio Terminal and copy the `debug` (or `release`) SHA-1.
3. **Run unit tests**:
   ```bash
   ./gradlew testDebugUnitTest
   ```
4. **Build & install on your Android device**:
   * Connect your phone via USB (or click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**) and run the `app` configuration.
5. **Using the app**:
   * Tap **Sign in with Google** (grants minimal `drive.file` scope — the app can only touch files/folders it creates).
   * Tap **Pick .zip / .in** or **Pick Folder** to select your Notein backup or designated directory.
   * Tap **Scan** to inspect the exact detected folder tree, **Convert** for a local mirror (saved under `Android/data/com.notein2drive/files/Notein_PDFs`), or **Sync Drive** (start with **Dry run** checked, then uncheck for live upload).

## Known Converter Limits (same as desktop engine)
* Not yet rendered: background PDFs for PDF-annotated notes (`PdfInfoEntity`), text boxes (`TextBoxEntity`), old-format `record_json` strokes, and true Multiply blending for highlighters. Warnings are logged per note when detected.
