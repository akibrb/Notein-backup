package com.notein2drive

import com.notein2drive.core.HierarchyDiscoverer
import com.notein2drive.core.PbParse
import com.notein2drive.core.StrokeDecoder
import com.notein2drive.sync.ManifestStore
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class NoteinCoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun writeFakeIn(file: File, metaJson: String) {
        file.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(file)).use { z ->
            z.putNextEntry(ZipEntry("note_meta.json"))
            z.write(metaJson.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }

    private fun writeFolderTree(file: File, treeJson: String) {
        file.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(file)).use { z ->
            z.putNextEntry(ZipEntry("folder_tree.json"))
            z.write(treeJson.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }

    @Test
    fun testSafeName() {
        assertEquals("Untitled", HierarchyDiscoverer.safeName(".."))
        assertEquals("a_b", HierarchyDiscoverer.safeName("a/b"))
        assertEquals("Q_ a_b_", HierarchyDiscoverer.safeName("Q: a*b?"))
    }

    @Test
    fun testSyntheticHierarchyAndNestedZip() {
        val root = tmp.newFolder("designated")
        val bk = File(root, "backup_dir")
        writeFolderTree(
            File(bk, "folder_tree/folder.tree"),
            """[
                {"id":"A","title":"Sem 2","creationTime":1},
                {"id":"B","title":"EEE/205","parentId":"A"},
                {"id":"T","title":"Old","inTrashBin":true},
                {"id":"X","title":"loop","parentId":"Y"},
                {"id":"Y","title":"loop2","parentId":"X"}
            ]""",
        )
        writeFakeIn(File(bk, "n_11111111-1111-1111-1111-111111111111/a.in"), """{"id":"n1","title":"Notes","parentId":"B","creationTime":1}""")
        writeFakeIn(File(bk, "n_22222222-2222-2222-2222-222222222222/b.in"), """{"id":"n2","title":"Notes","parentId":"B","creationTime":2}""")
        writeFakeIn(File(bk, "n_33333333-3333-3333-3333-333333333333/c.in"), """{"id":"n3","title":"Trashed","parentId":"T"}""")
        writeFakeIn(File(bk, "n_44444444-4444-4444-4444-444444444444/d.in"), """{"id":"n4","title":"Orphan","parentId":"ZZZZZZZZ-9"}""")
        writeFakeIn(File(bk, "n_55555555-5555-5555-5555-555555555555/e.in"), """{"id":"n5","title":"Cycle","parentId":"X"}""")

        val inv = HierarchyDiscoverer.discoverFromFile(bk)
        try {
            val paths = inv.entries.map { it.pdfRel }.sorted()
            assertEquals(
                listOf(
                    "Sem 2/EEE_205/Notes (2).pdf",
                    "Sem 2/EEE_205/Notes.pdf",
                    "_Unknown folder ZZZZZZZZ/Orphan.pdf",
                    "loop2/loop/Cycle.pdf",
                ),
                paths,
            )
            assertTrue(inv.warnings.any { it.contains("cycle") })
        } finally {
            inv.cleanup()
        }
    }

    @Test
    fun testPbParseAndStrokeDecoder() {
        val out = ByteArrayOutputStream()
        out.write((4 shl 3) or 5)
        out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(5.0f).array())
        val xy = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN)
            .putFloat(10f).putFloat(20f)
            .putFloat(40f).putFloat(60f)
            .array()
        out.write((10 shl 3) or 2)
        out.write(xy.size)
        out.write(xy)

        val fields = PbParse.parse(out.toByteArray())
        assertEquals(2, fields.size)
        val decoded = StrokeDecoder.decode(out.toByteArray())
        assertEquals(5.0f, decoded.brush, 1e-4f)
        val curve = StrokeDecoder.toCurve(decoded, "fit")
        assertFalse(curve.isDot)
        assertEquals(2, curve.xs.size)
    }

    @Test
    fun testManifestRoundTripAndSha256() {
        val dir = tmp.newFolder("out")
        val sample = File(dir, "sample.bin").apply { writeText("hello notein") }
        val h1 = ManifestStore.sha256(sample)
        val h2 = ManifestStore.sha256(sample)
        assertEquals(64, h1.length)
        assertEquals(h1, h2)

        val initial = mapOf(
            "n1" to ManifestStore.Record(
                modified = 12345L,
                inSize = 999L,
                pdfRel = "2-2/Hello.pdf",
                driveId = "drv_1",
                inSha256 = h1,
                pdfSha256 = h2,
            )
        )
        ManifestStore.save(dir, initial)
        val loaded = ManifestStore.load(dir)
        assertEquals(initial, loaded)
    }
}
