package com.notein2drive.sync

import android.content.Context
import com.notein2drive.core.HierarchyDiscoverer
import com.notein2drive.core.NoteinConverter
import com.notein2drive.drive.DriveMirror
import java.io.File
import java.util.concurrent.CancellationException

/**
 * Orchestrates incremental conversion and Google Drive upload across all discovered notes.
 * Reports per-note live status, supports clean cancellation, and uses SHA-256 hashes so
 * identical files are never replaced on Drive.
 */
object SyncEngine {

    data class SyncSummary(
        val converted: Int,
        val skipped: Int,
        val uploaded: Int,
        val driveUnchanged: Int,
        val prunedLocal: Int,
        val prunedDrive: Int,
        val failed: List<Pair<String, String>>,
        val warnings: List<String>,
    )

    fun run(
        context: Context,
        inventory: HierarchyDiscoverer.Inventory,
        outDir: File,
        mirror: DriveMirror? = null,
        force: Boolean = false,
        dryRun: Boolean = false,
        prune: Boolean = false,
        widthModel: String = "fit",
        watermarkText: String? = null,
        isCancelled: () -> Boolean = { false },
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
        onStatus: (String) -> Unit = {},
        log: (String) -> Unit = {},
    ): SyncSummary {
        outDir.mkdirs()
        val manifest = ManifestStore.load(outDir)
        var converted = 0
        var skipped = 0
        var uploaded = 0
        var driveUnchanged = 0
        var prunedLocal = 0
        var prunedDrive = 0
        val failed = ArrayList<Pair<String, String>>()
        val warnings = ArrayList<String>()

        val sorted = inventory.entries.sortedBy { it.pdfRel.lowercase() }
        val activeIds = sorted.map { it.noteId }.toSet()

        sorted.forEachIndexed { idx, entry ->
            if (isCancelled()) throw CancellationException("Cancelled")
            onStatus("Processing (${idx + 1}/${sorted.size}): ${entry.pdfRel}")

            val pdfFile = File(outDir, entry.pdfRel)
            val prev = manifest[entry.noteId]
            val inHash = try {
                ManifestStore.sha256(entry.inFile)
            } catch (_: Exception) {
                ""
            }

            val sameLocalInput = prev != null &&
                ((inHash.isNotBlank() && prev.inSha256 == inHash) ||
                    (prev.inSha256.isBlank() && prev.modified == entry.modified && prev.inSize == entry.inSize)) &&
                prev.pdfRel == entry.pdfRel &&
                pdfFile.exists()

            val upToDate = sameLocalInput && (mirror == null || !prev!!.driveId.isNullOrBlank())

            if (upToDate && !force) {
                skipped++
                log("= ${entry.pdfRel} (exact match, skipped)")
                onProgress(idx + 1, sorted.size)
                return@forEachIndexed
            }

            if (dryRun) {
                val tag = if (sameLocalInput) "check Drive hash" else "convert + sync"
                log("+ ${entry.pdfRel} <- ${entry.inFile.name} ($tag, dry run)")
                onProgress(idx + 1, sorted.size)
                return@forEachIndexed
            }

            try {
                if (prev != null && prev.pdfRel.isNotBlank() && prev.pdfRel != entry.pdfRel) {
                    val oldPdf = File(outDir, prev.pdfRel)
                    if (oldPdf.exists()) oldPdf.delete()
                }

                val pdfHash: String
                if (sameLocalInput && !force) {
                    pdfHash = prev!!.pdfSha256.ifBlank { ManifestStore.sha256(pdfFile) }
                } else {
                    val st = NoteinConverter.convert(context, entry.inFile, pdfFile, widthModel, watermarkText, isCancelled)
                    converted++
                    st.warnings.forEach { warnings.add("${entry.pdfRel}: $it") }
                    log("+ ${entry.pdfRel}  pages=${st.pages} strokes=${st.strokes} shapes=${st.shapes} images=${st.images}")
                    pdfHash = ManifestStore.sha256(pdfFile)
                }

                var driveId = prev?.driveId
                if (mirror != null) {
                    onStatus("Uploading (${idx + 1}/${sorted.size}): ${entry.pdfRel}")
                    val (fid, action) = mirror.uploadPdf(
                        localPdf = pdfFile,
                        noteId = entry.noteId,
                        folderParts = entry.folderParts,
                        fileName = pdfFile.name,
                        modified = entry.modified,
                        inSha256 = inHash,
                        pdfSha256 = pdfHash,
                        forceUpload = force,
                    )
                    driveId = fid
                    when (action) {
                        "unchanged" -> {
                            driveUnchanged++
                            log("  = Drive unchanged (not replaced): $fid")
                        }
                        "moved" -> {
                            uploaded++
                            log("  -> Drive moved/renamed (content unchanged): $fid")
                        }
                        else -> {
                            uploaded++
                            log("  -> Drive $action: $fid")
                        }
                    }
                }

                manifest[entry.noteId] = ManifestStore.Record(
                    modified = entry.modified,
                    inSize = entry.inSize,
                    pdfRel = entry.pdfRel,
                    driveId = driveId,
                    inSha256 = inHash,
                    pdfSha256 = pdfHash,
                )
                ManifestStore.save(outDir, manifest)
            } catch (ce: CancellationException) {
                throw ce
            } catch (ex: Exception) {
                failed.add(entry.pdfRel to (ex.message ?: ex.javaClass.simpleName))
                log("! ${entry.pdfRel}: ${ex.message ?: ex}")
            }

            onProgress(idx + 1, sorted.size)
        }

        if (prune && !isCancelled()) {
            val staleIds = manifest.keys.filter { it !in activeIds }
            for (nid in staleIds) {
                val rel = manifest[nid]?.pdfRel ?: nid
                if (dryRun) {
                    log("- $rel (would prune locally)")
                    prunedLocal++
                } else {
                    val f = File(outDir, rel)
                    if (f.exists()) f.delete()
                    manifest.remove(nid)
                    prunedLocal++
                    log("- $rel (pruned locally)")
                }
            }
            if (!dryRun && staleIds.isNotEmpty()) {
                ManifestStore.save(outDir, manifest)
                pruneEmptyLocalDirs(outDir)
            }

            if (mirror != null) {
                val trashedFiles = mirror.pruneMissing(activeIds, dryRun = dryRun)
                prunedDrive = trashedFiles.size
                for (f in trashedFiles) {
                    log("- Drive ${f.name} (${f.id}) ${if (dryRun) "(dry run)" else "(trashed)"}")
                }
                val trashedFolders = mirror.pruneEmptyFolders(dryRun = dryRun)
                for ((fid, name) in trashedFolders) {
                    log("- Drive empty folder $name ($fid) ${if (dryRun) "(dry run)" else "(trashed)"}")
                }
            }
        }

        return SyncSummary(
            converted = converted,
            skipped = skipped,
            uploaded = uploaded,
            driveUnchanged = driveUnchanged,
            prunedLocal = prunedLocal,
            prunedDrive = prunedDrive,
            failed = failed,
            warnings = warnings,
        )
    }

    private fun pruneEmptyLocalDirs(root: File) {
        root.walkBottomUp().forEach { f ->
            if (f.isDirectory && f.canonicalPath != root.canonicalPath) {
                if (f.listFiles().isNullOrEmpty()) {
                    f.delete()
                }
            }
        }
    }
}
