package com.notein2drive.sync

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.util.concurrent.CancellationException

/**
 * Exports all converted PDFs from the internal mirror directory into any user-selected
 * Android device folder (via SAF `OpenDocumentTree`) preserving exact nested folders.
 * Caches per-directory child listings so large folders export in O(N) instead of O(N^2).
 */
object LocalExporter {

    data class ExportResult(
        val exported: Int,
        val skipped: Int,
        val failed: Int,
    )

    fun exportHierarchyToTree(
        context: Context,
        mirrorRoot: File,
        destTreeUri: Uri,
        isCancelled: () -> Boolean = { false },
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
        onStatus: (String) -> Unit = {},
        log: (String) -> Unit = {},
    ): ExportResult {
        val rootDoc = DocumentFile.fromTreeUri(context, destTreeUri)
            ?: throw IllegalArgumentException("Cannot access selected destination folder")

        val pdfFiles = mirrorRoot.walkTopDown()
            .filter { it.isFile && it.name.lowercase().endsWith(".pdf") }
            .sortedBy { it.relativeTo(mirrorRoot).path.lowercase() }
            .toList()

        if (pdfFiles.isEmpty()) {
            return ExportResult(0, 0, 0)
        }

        val dirCache = HashMap<String, DocumentFile>()
        val childIndexCache = HashMap<String, MutableMap<String, DocumentFile>>()
        dirCache[""] = rootDoc

        fun childrenOf(dirKey: String, dirDoc: DocumentFile): MutableMap<String, DocumentFile> {
            return childIndexCache.getOrPut(dirKey) {
                val map = HashMap<String, DocumentFile>()
                for (c in dirDoc.listFiles()) {
                    val n = c.name ?: continue
                    map[n] = c
                }
                map
            }
        }

        fun ensureDir(parts: List<String>): Pair<String, DocumentFile> {
            var current = rootDoc
            var key = ""
            for (part in parts) {
                val parentKey = key
                key = if (key.isEmpty()) part else "$key/$part"
                val cached = dirCache[key]
                if (cached != null) {
                    current = cached
                } else {
                    val siblings = childrenOf(parentKey, current)
                    val existing = siblings[part]?.takeIf { it.isDirectory }
                    val next = existing ?: current.createDirectory(part)
                        ?: throw IllegalStateException("Could not create folder '$part'")
                    siblings[part] = next
                    dirCache[key] = next
                    current = next
                }
            }
            return key to current
        }

        var exported = 0
        var skipped = 0
        var failed = 0

        pdfFiles.forEachIndexed { idx, pdf ->
            if (isCancelled()) throw CancellationException("Cancelled")
            val rel = pdf.relativeTo(mirrorRoot).path.replace(File.separatorChar, '/')
            onStatus("Saving (${idx + 1}/${pdfFiles.size}): $rel")
            val segments = rel.split('/')
            val folderParts = segments.dropLast(1)
            val fileName = segments.last()

            try {
                val (dirKey, targetDir) = ensureDir(folderParts)
                val siblings = childrenOf(dirKey, targetDir)
                val existing = siblings[fileName]
                if (existing != null && existing.isFile && existing.length() == pdf.length()) {
                    skipped++
                    log("= Local $rel (unchanged)")
                } else {
                    existing?.delete()
                    val created = targetDir.createFile("application/pdf", fileName.removeSuffix(".pdf"))
                        ?: throw IllegalStateException("Could not create $rel")
                    context.contentResolver.openOutputStream(created.uri)?.use { out ->
                        pdf.inputStream().use { input -> input.copyTo(out) }
                    } ?: throw IllegalStateException("Could not write $rel")
                    siblings[fileName] = created
                    exported++
                    log("+ Saved locally: $rel")
                }
            } catch (e: Exception) {
                failed++
                log("! Export failed ($rel): ${e.message}")
            }
            onProgress(idx + 1, pdfFiles.size)
        }

        return ExportResult(exported, skipped, failed)
    }
}
