package com.notein2drive.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.notein2drive.core.HierarchyDiscoverer
import com.notein2drive.drive.DriveMirror
import com.notein2drive.drive.GoogleAuthHelper
import com.notein2drive.sync.LocalExporter
import com.notein2drive.sync.ManifestStore
import com.notein2drive.sync.SyncEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.atomic.AtomicBoolean

data class LocalPdfItem(
    val relPath: String,
    val folderPath: String,
    val fileName: String,
    val file: File,
    val sizeBytes: Long,
    val syncedToDrive: Boolean,
)

data class FolderNode(
    val path: String,          // "" for Root (unfiled), "University", "University/EEE", etc.
    val name: String,          // Display name
    val parentPath: String?,   // null for top-level / Root
    val depth: Int,
    val directNotes: Int,
    val totalNotes: Int,
    val hasChildren: Boolean,
)

data class UiState(
    val signedInEmail: String? = null,
    val appSha1: String = "",
    val sourceUri: Uri? = null,
    val sourceIsTree: Boolean = false,
    val sourceLabel: String = "No backup or folder selected",
    val localSaveUri: Uri? = null,
    val localSaveLabel: String = "App internal folder (tap Choose to pick device folder)",
    val rootFolderName: String = "Notein PDFs",
    val includeTrashed: Boolean = false,
    val forceReconvert: Boolean = false,
    val dryRun: Boolean = true,
    val pruneDeleted: Boolean = false,
    val watermarkEnabled: Boolean = false,
    val watermarkText: String = "",
    val busy: Boolean = false,
    val progress: Float = 0f,
    val statusLine: String = "Select a Notein backup.zip or folder to begin.",
    val folderNodes: List<FolderNode> = emptyList(),
    val noteFolderPaths: Set<String> = emptySet(),       // all paths that directly contain >=1 note
    val selectedFolderPaths: Set<String> = emptySet(),   // subset of noteFolderPaths selected by user
    val expandedFolders: Set<String> = emptySet(),
    val totalScannedNotes: Int = 0,
    val treePreview: String = "",
    val localPdfs: List<LocalPdfItem> = emptyList(),
    val previewPdf: LocalPdfItem? = null,
    val logs: List<String> = emptyList(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("notein2drive_prefs", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var account: GoogleSignInAccount? = null
    private var activeJob: Job? = null
    private val cancelFlag = AtomicBoolean(false)

    init {
        cleanStaleTempCache(application)
        val savedUriStr = prefs.getString("local_save_uri", null)
        val savedLabel = prefs.getString("local_save_label", null)
        val wmEnabled = prefs.getBoolean("watermark_enabled", false)
        val wmText = prefs.getString("watermark_text", "") ?: ""
        val sha1 = GoogleAuthHelper.getAppSha1(application)
        _state.update {
            it.copy(
                appSha1 = sha1,
                localSaveUri = savedUriStr?.let { s -> runCatching { Uri.parse(s) }.getOrNull() },
                localSaveLabel = savedLabel ?: it.localSaveLabel,
                watermarkEnabled = wmEnabled,
                watermarkText = wmText,
            )
        }
        refreshAccount()
        refreshLocalPdfs()
    }

    private fun cleanStaleTempCache(ctx: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            ctx.cacheDir.listFiles()?.forEach { f ->
                if (f.isDirectory && (
                        f.name.startsWith("notein_stage_") ||
                        f.name.startsWith("notein_zip_") ||
                        f.name.startsWith("notein_nested_") ||
                        f.name.startsWith("notein_conv_")
                    )
                ) {
                    f.deleteRecursively()
                }
            }
        }
    }

    private fun mirrorDir(): File {
        val ctx = getApplication<Application>()
        return File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Notein_PDFs")
    }

    fun cancelActiveTask() {
        cancelFlag.set(true)
        activeJob?.cancel()
        appendLog("! Cancelled by user (completed notes were saved).")
        _state.update { it.copy(busy = false, statusLine = "Cancelled. Already-converted notes were saved.") }
        refreshLocalPdfs()
    }

    fun refreshAccount() {
        val ctx = getApplication<Application>()
        account = GoogleAuthHelper.getLastSignedInAccount(ctx)
        _state.update { it.copy(signedInEmail = account?.email) }
    }

    fun refreshLocalPdfs() {
        viewModelScope.launch(Dispatchers.IO) {
            val root = mirrorDir()
            if (!root.exists()) {
                _state.update { it.copy(localPdfs = emptyList()) }
                return@launch
            }
            val manifest = ManifestStore.load(root)
            val syncedPaths = manifest.values
                .filter { !it.driveId.isNullOrBlank() }
                .map { it.pdfRel }
                .toSet()

            val items = root.walkTopDown()
                .filter { it.isFile && it.name.lowercase().endsWith(".pdf") }
                .map { f ->
                    val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
                    val slash = rel.lastIndexOf('/')
                    val folder = if (slash >= 0) rel.substring(0, slash) else "Root"
                    LocalPdfItem(
                        relPath = rel,
                        folderPath = folder,
                        fileName = f.name,
                        file = f,
                        sizeBytes = f.length(),
                        syncedToDrive = rel in syncedPaths,
                    )
                }
                .sortedBy { it.relPath.lowercase() }
                .toList()

            _state.update { it.copy(localPdfs = items) }
        }
    }

    fun onSignedIn(acct: GoogleSignInAccount?) {
        account = acct
        _state.update {
            it.copy(
                signedInEmail = acct?.email,
                statusLine = if (acct != null) "Connected as ${acct.email}" else "Google Sign-In cancelled",
            )
        }
    }

    fun onSignInFailed(t: Throwable) {
        val msg = GoogleAuthHelper.explainSignInError(t)
        appendLog("! $msg")
        _state.update { it.copy(statusLine = msg) }
    }

    fun setSource(uri: Uri, isTree: Boolean, label: String) {
        _state.update {
            it.copy(
                sourceUri = uri,
                sourceIsTree = isTree,
                sourceLabel = label,
                folderNodes = emptyList(),
                noteFolderPaths = emptySet(),
                selectedFolderPaths = emptySet(),
                totalScannedNotes = 0,
                statusLine = "Selected: $label (tap Scan to choose folders)",
            )
        }
    }

    fun setLocalSaveFolder(uri: Uri, label: String) {
        prefs.edit()
            .putString("local_save_uri", uri.toString())
            .putString("local_save_label", label)
            .apply()
        _state.update {
            it.copy(
                localSaveUri = uri,
                localSaveLabel = label,
                statusLine = "Local save folder set to: $label",
            )
        }
    }

    fun clearLocalSaveFolder() {
        prefs.edit().remove("local_save_uri").remove("local_save_label").apply()
        _state.update {
            it.copy(
                localSaveUri = null,
                localSaveLabel = "App internal folder (tap Choose to pick device folder)",
                statusLine = "Reset local save location to app internal folder.",
            )
        }
    }

    // -- Folder selection tree logic -------------------------------------------------------------

    private fun buildFolderNodes(entries: List<HierarchyDiscoverer.NoteEntry>): Pair<List<FolderNode>, Set<String>> {
        val directCounts = HashMap<String, Int>()
        val allPaths = LinkedHashSet<String>()

        for (e in entries) {
            val fullPath = e.folderParts.joinToString("/")
            directCounts[fullPath] = (directCounts[fullPath] ?: 0) + 1
            if (fullPath.isEmpty()) {
                allPaths.add("")
            } else {
                var acc = ""
                for (part in e.folderParts) {
                    acc = if (acc.isEmpty()) part else "$acc/$part"
                    allPaths.add(acc)
                }
            }
        }

        val nodes = allPaths.sortedWith(compareBy<String>({ it.isNotEmpty() }, { it.lowercase() })).map { path ->
            val isRoot = path.isEmpty()
            val parts = if (isRoot) emptyList() else path.split("/")
            val parent = when {
                isRoot -> null
                parts.size == 1 -> null
                else -> parts.dropLast(1).joinToString("/")
            }
            val direct = directCounts[path] ?: 0
            val total = if (isRoot) {
                direct
            } else {
                directCounts.entries.sumOf { (k, v) ->
                    if (k == path || k.startsWith("$path/")) v else 0
                }
            }
            val hasKids = !isRoot && allPaths.any { it.startsWith("$path/") }
            FolderNode(
                path = path,
                name = if (isRoot) "Root (Unfiled notes)" else parts.last(),
                parentPath = parent,
                depth = if (isRoot) 0 else parts.size - 1,
                directNotes = direct,
                totalNotes = total,
                hasChildren = hasKids,
            )
        }

        return nodes to directCounts.keys.toSet()
    }

    /** Returns all note-bearing folder paths belonging to `folderPath` (itself + descendants). */
    fun leafPathsUnder(folderPath: String, allNotePaths: Set<String> = _state.value.noteFolderPaths): Set<String> {
        if (folderPath.isEmpty()) {
            return if ("" in allNotePaths) setOf("") else emptySet()
        }
        return allNotePaths.filterTo(LinkedHashSet()) { it == folderPath || it.startsWith("$folderPath/") }
    }

    fun toggleFolderSelection(folderPath: String) {
        _state.update { st ->
            val targets = leafPathsUnder(folderPath, st.noteFolderPaths)
            if (targets.isEmpty()) return@update st
            val allSelected = targets.all { it in st.selectedFolderPaths }
            val updated = if (allSelected) st.selectedFolderPaths - targets else st.selectedFolderPaths + targets
            st.copy(selectedFolderPaths = updated)
        }
    }

    fun selectAllFolders() = _state.update { it.copy(selectedFolderPaths = it.noteFolderPaths) }
    fun clearAllFolders() = _state.update { it.copy(selectedFolderPaths = emptySet()) }

    fun toggleFolderExpanded(folderPath: String) {
        _state.update { st ->
            val next = if (folderPath in st.expandedFolders) st.expandedFolders - folderPath else st.expandedFolders + folderPath
            st.copy(expandedFolders = next)
        }
    }

    fun expandAllFolders() = _state.update { st ->
        st.copy(expandedFolders = st.folderNodes.filter { it.hasChildren }.map { it.path }.toSet())
    }

    fun collapseAllFolders() = _state.update { it.copy(expandedFolders = emptySet()) }

    fun selectedNoteCount(st: UiState = _state.value): Int =
        st.folderNodes.sumOf { node -> if (node.path in st.selectedFolderPaths) node.directNotes else 0 }

    fun openPreview(item: LocalPdfItem) = _state.update { it.copy(previewPdf = item) }
    fun closePreview() = _state.update { it.copy(previewPdf = null) }
    fun clearLogs() = _state.update { it.copy(logs = emptyList()) }

    fun updateRootFolderName(v: String) = _state.update { it.copy(rootFolderName = v) }
    fun updateIncludeTrashed(v: Boolean) = _state.update { it.copy(includeTrashed = v) }
    fun updateForceReconvert(v: Boolean) = _state.update { it.copy(forceReconvert = v) }
    fun updateDryRun(v: Boolean) = _state.update { it.copy(dryRun = v) }
    fun updatePruneDeleted(v: Boolean) = _state.update { it.copy(pruneDeleted = v) }
    fun updateWatermarkEnabled(v: Boolean) {
        prefs.edit().putBoolean("watermark_enabled", v).apply()
        _state.update { it.copy(watermarkEnabled = v) }
    }
    fun updateWatermarkText(v: String) {
        prefs.edit().putString("watermark_text", v).apply()
        _state.update { it.copy(watermarkText = v) }
    }

    private fun appendLog(line: String) {
        _state.update { it.copy(logs = (it.logs + line).takeLast(400)) }
    }

    fun scan() {
        val st = _state.value
        val uri = st.sourceUri ?: return
        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Reading & unpacking source...", logs = emptyList()) }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                inv = HierarchyDiscoverer.discoverFromUri(getApplication(), uri, st.sourceIsTree, st.includeTrashed)
                val (nodes, notePaths) = buildFolderNodes(inv.entries)
                val defaultExpanded = if (nodes.size <= 10) {
                    nodes.filter { it.hasChildren }.map { it.path }.toSet()
                } else {
                    emptySet() // keep top-level compact when many subfolders exist
                }
                val tree = inv.renderTree().ifBlank { "(no notes found)" }
                inv.warnings.forEach { appendLog("warning: $it") }
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        folderNodes = nodes,
                        noteFolderPaths = notePaths,
                        selectedFolderPaths = notePaths, // all selected by default
                        expandedFolders = defaultExpanded,
                        totalScannedNotes = inv.entries.size,
                        treePreview = tree,
                        statusLine = "Found ${inv.entries.size} note(s) in ${nodes.size} folder(s). Select folders below.",
                    )
                }
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Scan cancelled.") }
            } catch (e: Exception) {
                appendLog("! Scan error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Scan failed: ${e.message}") }
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun convertOrSync(uploadToDrive: Boolean) {
        val st = _state.value
        val uri = st.sourceUri ?: return
        if (uploadToDrive && !st.dryRun && account?.account == null) {
            _state.update { it.copy(statusLine = "Sign in with Google first to sync to Drive.") }
            return
        }
        if (st.folderNodes.isNotEmpty() && st.selectedFolderPaths.isEmpty()) {
            _state.update { it.copy(statusLine = "Select at least one folder before converting or syncing.") }
            return
        }

        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    busy = true,
                    progress = 0f,
                    statusLine = "Reading & unpacking source...",
                    logs = emptyList(),
                )
            }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                val ctx = getApplication<Application>()
                inv = HierarchyDiscoverer.discoverFromUri(ctx, uri, st.sourceIsTree, st.includeTrashed)
                val (nodes, allNotePaths) = buildFolderNodes(inv.entries)
                val activeSelection = if (st.folderNodes.isNotEmpty()) st.selectedFolderPaths else allNotePaths
                val isPartialSelection = activeSelection.size < allNotePaths.size

                val filteredEntries = inv.entries.filter { e ->
                    e.folderParts.joinToString("/") in activeSelection
                }
                val filteredInv = inv.copy(entries = filteredEntries)

                _state.update {
                    it.copy(
                        folderNodes = if (it.folderNodes.isEmpty()) nodes else it.folderNodes,
                        noteFolderPaths = if (it.noteFolderPaths.isEmpty()) allNotePaths else it.noteFolderPaths,
                        selectedFolderPaths = if (it.folderNodes.isEmpty()) allNotePaths else it.selectedFolderPaths,
                        totalScannedNotes = inv.entries.size,
                        treePreview = filteredInv.renderTree(),
                    )
                }
                inv.warnings.forEach { appendLog("warning: $it") }

                val effectivePrune = if (st.pruneDeleted && isPartialSelection) {
                    appendLog("note: Partial folder selection active — pruning skipped to protect unselected folders.")
                    false
                } else {
                    st.pruneDeleted
                }

                val mirror = if (uploadToDrive && !st.dryRun) {
                    val token = GoogleAuthHelper.fetchAccessToken(ctx, account!!.account!!)
                    DriveMirror(accessToken = token, rootName = st.rootFolderName.ifBlank { "Notein PDFs" })
                } else null

                val outDir = mirrorDir()
                val summary = SyncEngine.run(
                    context = ctx,
                    inventory = filteredInv,
                    outDir = outDir,
                    mirror = mirror,
                    force = st.forceReconvert,
                    dryRun = uploadToDrive && st.dryRun,
                    prune = effectivePrune,
                    watermarkText = if (st.watermarkEnabled) st.watermarkText.takeIf { it.isNotBlank() } else null,
                    isCancelled = { cancelFlag.get() },
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                    log = { appendLog(it) },
                )

                var exportNote = ""
                val saveUri = st.localSaveUri
                if (saveUri != null && !(uploadToDrive && st.dryRun) && !cancelFlag.get()) {
                    val exp = LocalExporter.exportHierarchyToTree(
                        context = ctx,
                        mirrorRoot = outDir,
                        destTreeUri = saveUri,
                        isCancelled = { cancelFlag.get() },
                        onProgress = { done, total ->
                            val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                            _state.update { it.copy(progress = frac) }
                        },
                        onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                        log = { appendLog(it) },
                    )
                    exportNote = " • Saved locally: ${exp.exported} new, ${exp.skipped} unchanged"
                }

                val unchangedTotal = summary.skipped + summary.driveUnchanged
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Done (${filteredEntries.size} selected): ${summary.converted} converted, " +
                            "${summary.uploaded} uploaded, $unchangedTotal unchanged, ${summary.failed.size} failed.$exportNote",
                    )
                }
                refreshLocalPdfs()
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Cancelled. Completed notes were saved.") }
                refreshLocalPdfs()
            } catch (e: Exception) {
                appendLog("! Error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Failed: ${e.message}") }
                refreshLocalPdfs()
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun exportAllToLocalFolder(destTreeUri: Uri, label: String? = null) {
        if (label != null) {
            setLocalSaveFolder(destTreeUri, label)
        }
        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Saving PDFs hierarchically to device folder...") }
            try {
                val res = LocalExporter.exportHierarchyToTree(
                    context = getApplication(),
                    mirrorRoot = mirrorDir(),
                    destTreeUri = destTreeUri,
                    isCancelled = { cancelFlag.get() },
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                    log = { appendLog(it) },
                )
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Saved locally: ${res.exported} written, ${res.skipped} already up-to-date, ${res.failed} failed.",
                    )
                }
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Local save cancelled.") }
            } catch (e: Exception) {
                appendLog("! Export error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Local save failed: ${e.message}") }
            }
        }
    }
}
