package com.notein2drive.core

/**
 * Minimal protobuf wire-format reader (no .proto schema needed).
 * Direct Kotlin port of notein2drive/pbparse.py.
 */
object PbParse {
    data class Field(
        val fieldNo: Int,
        val wireType: Int,
        val varintValue: Long = 0L,
        val bytesValue: ByteArray = ByteArray(0),
    )

    private fun readVarint(b: ByteArray, start: Int): Pair<Long, Int> {
        var i = start
        var result = 0L
        var shift = 0
        while (true) {
            val x = b[i].toInt() and 0xFF
            i++
            result = result or ((x and 0x7F).toLong() shl shift)
            shift += 7
            if ((x and 0x80) == 0) {
                return result to i
            }
        }
    }

    fun parse(b: ByteArray): List<Field> {
        var i = 0
        val out = ArrayList<Field>()
        while (i < b.size) {
            val (key, nextIdx) = readVarint(b, i)
            i = nextIdx
            val fieldNo = (key ushr 3).toInt()
            val wireType = (key and 7L).toInt()
            when (wireType) {
                0 -> {
                    val (v, ni) = readVarint(b, i)
                    i = ni
                    out.add(Field(fieldNo, wireType, varintValue = v))
                }
                1 -> {
                    out.add(Field(fieldNo, wireType, bytesValue = b.copyOfRange(i, i + 8)))
                    i += 8
                }
                2 -> {
                    val (len, ni) = readVarint(b, i)
                    i = ni
                    val n = len.toInt()
                    out.add(Field(fieldNo, wireType, bytesValue = b.copyOfRange(i, i + n)))
                    i += n
                }
                5 -> {
                    out.add(Field(fieldNo, wireType, bytesValue = b.copyOfRange(i, i + 4)))
                    i += 4
                }
                else -> throw IllegalArgumentException("Unsupported protobuf wire type: $wireType")
            }
        }
        return out
    }
}
