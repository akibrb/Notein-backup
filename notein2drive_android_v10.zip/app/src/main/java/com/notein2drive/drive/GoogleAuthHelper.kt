package com.notein2drive.drive

import android.accounts.Account
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * Handles Google Sign-In with the minimal `drive.file` scope, retrieves OAuth2 access tokens,
 * reads the installed APK's SHA-1 fingerprint for easy Google Cloud Console setup, and explains
 * sign-in error codes clearly.
 */
object GoogleAuthHelper {

    const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"

    fun buildSignInClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DRIVE_FILE_SCOPE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getLastSignedInAccount(context: Context): GoogleSignInAccount? {
        val acct = GoogleSignIn.getLastSignedInAccount(context) ?: return null
        val hasScope = GoogleSignIn.hasPermissions(acct, Scope(DRIVE_FILE_SCOPE))
        return if (hasScope) acct else null
    }

    fun signInIntent(context: Context): Intent = buildSignInClient(context).signInIntent

    suspend fun fetchAccessToken(context: Context, account: Account): String = withContext(Dispatchers.IO) {
        GoogleAuthUtil.getToken(context, account, "oauth2:$DRIVE_FILE_SCOPE")
    }

    /** Returns the installed APK's signing certificate SHA-1 formatted as `AA:BB:CC:...`. */
    fun getAppSha1(context: Context): String {
        return try {
            val pm = context.packageManager
            val certBytes: ByteArray = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val sigs = info.signingInfo?.apkContentsSigners
                    ?: info.signingInfo?.signingCertificateHistory
                    ?: return "Unavailable"
                sigs.firstOrNull()?.toByteArray() ?: return "Unavailable"
            } else {
                @Suppress("DEPRECATION")
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
                @Suppress("DEPRECATION")
                info.signatures?.firstOrNull()?.toByteArray() ?: return "Unavailable"
            }
            val digest = MessageDigest.getInstance("SHA-1").digest(certBytes)
            digest.joinToString(":") { "%02X".format(it) }
        } catch (e: Exception) {
            "Unavailable (${e.message})"
        }
    }

    fun explainSignInError(t: Throwable): String {
        val code = (t as? ApiException)?.statusCode
        return when (code) {
            10 -> "Sign-in failed (Error 10: DEVELOPER_ERROR). Add package 'com.notein2drive' + the SHA-1 shown above as an Android OAuth Client ID in Google Cloud Console."
            12500 -> "Sign-in failed (Error 12500). Check OAuth consent screen & add your Gmail under Test users in Google Cloud Console."
            12501 -> "Google Sign-In was cancelled."
            7 -> "Network error during Google Sign-In. Check your internet connection."
            else -> "Google Sign-In failed${if (code != null) " (code $code)" else ""}: ${t.message}"
        }
    }
}
