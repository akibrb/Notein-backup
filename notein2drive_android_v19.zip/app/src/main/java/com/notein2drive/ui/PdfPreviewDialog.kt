package com.notein2drive.ui

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Full-screen scrollable multi-page PDF viewer powered by Android's native `PdfRenderer`.
 * Uses a single dedicated background thread for open/render/close and a byte-capped LRU cache
 * so large multi-page or infinite-canvas PDFs load reliably without OOM or concurrency crashes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfPreviewDialog(
    pdfFile: File,
    title: String,
    onDismiss: () -> Unit,
) {
    var pageCount by remember(pdfFile) { mutableIntStateOf(0) }
    var errorMsg by remember(pdfFile) { mutableStateOf<String?>(null) }
    var zoom by remember(pdfFile) { mutableFloatStateOf(1.0f) }
    var pan by remember(pdfFile) { mutableStateOf(Offset.Zero) }

    // Single-threaded executor guarantees open, render, and close run sequentially on the same thread
    val renderExecutor = remember(pdfFile) {
        Executors.newSingleThreadExecutor { r ->
            Thread(r, "pdf-preview-renderer").apply { isDaemon = true }
        }
    }
    val renderDispatcher = remember(pdfFile) { renderExecutor.asCoroutineDispatcher() }
    val isClosed = remember(pdfFile) { AtomicBoolean(false) }
    val holderRef = remember(pdfFile) { AtomicReference<Pair<ParcelFileDescriptor, PdfRenderer>?>(null) }

    // Memory-bounded bitmap cache (20 MB max in KB) so large PDFs never trigger OOM
    val bitmapCache = remember(pdfFile) {
        val maxCacheKb = 20 * 1024
        object : LruCache<Int, Bitmap>(maxCacheKb) {
            override fun sizeOf(key: Int, value: Bitmap): Int {
                return (value.allocationByteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    var holder by remember(pdfFile) { mutableStateOf<Pair<ParcelFileDescriptor, PdfRenderer>?>(null) }

    LaunchedEffect(pdfFile) {
        isClosed.set(false)
        errorMsg = null
        pageCount = 0
        try {
            val opened = withContext(renderDispatcher) {
                if (isClosed.get()) return@withContext null
                if (!pdfFile.exists() || pdfFile.length() <= 0L) {
                    throw IllegalStateException("PDF file not found or empty")
                }
                val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = try {
                    PdfRenderer(pfd)
                } catch (t: Throwable) {
                    runCatching { pfd.close() }
                    throw t
                }
                if (renderer.pageCount <= 0) {
                    runCatching { renderer.close() }
                    runCatching { pfd.close() }
                    throw IllegalStateException("PDF has no pages")
                }
                if (isClosed.get()) {
                    runCatching { renderer.close() }
                    runCatching { pfd.close() }
                    return@withContext null
                }
                val pair = pfd to renderer
                holderRef.set(pair)
                pair
            }
            if (opened != null && !isClosed.get()) {
                holder = opened
                pageCount = opened.second.pageCount
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            if (!isClosed.get()) {
                errorMsg = t.message ?: t.javaClass.simpleName
            }
        }
    }

    DisposableEffect(pdfFile) {
        onDispose {
            isClosed.set(true)
            holder = null
            bitmapCache.evictAll()
            runCatching {
                renderExecutor.execute {
                    val h = holderRef.getAndSet(null)
                    runCatching { h?.second?.close() }
                    runCatching { h?.first?.close() }
                }
            }
            renderExecutor.shutdown()
        }
    }

    val listState = rememberLazyListState()
    val visiblePage by remember {
        derivedStateOf { (listState.firstVisibleItemIndex + 1).coerceIn(1, maxOf(1, pageCount)) }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            if (pageCount > 0) {
                                Text(
                                    "Page $visiblePage of $pageCount  •  ${(zoom * 100).roundToInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close preview")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                zoom = (zoom - 0.5f).coerceAtLeast(1.0f)
                                if (zoom <= 1.01f) pan = Offset.Zero
                            },
                            enabled = zoom > 1.0f,
                        ) {
                            Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom out")
                        }
                        IconButton(
                            onClick = { zoom = (zoom + 0.5f).coerceAtMost(6.0f) },
                            enabled = zoom < 6.0f,
                        ) {
                            Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom in")
                        }
                        if (zoom > 1.05f) {
                            IconButton(onClick = { zoom = 1.0f; pan = Offset.Zero }) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "Reset zoom")
                            }
                        }
                    },
                )
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(Color(0xFF0B1120))
                    .pointerInput(Unit) {
                        detectTransformGestures { _, panChange, zoomChange, _ ->
                            val nextZoom = (zoom * zoomChange).coerceIn(1.0f, 6.0f)
                            zoom = nextZoom
                            pan = if (nextZoom > 1.05f) {
                                Offset(pan.x + panChange.x, pan.y + panChange.y)
                            } else {
                                Offset.Zero
                            }
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                when {
                    errorMsg != null -> Text(
                        errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(24.dp),
                    )

                    pageCount > 0 && holder != null -> {
                        val renderer = holder!!.second
                        LazyColumn(
                            state = listState,
                            userScrollEnabled = zoom <= 1.05f,
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = zoom,
                                    scaleY = zoom,
                                    translationX = pan.x,
                                    translationY = pan.y,
                                ),
                        ) {
                            items(pageCount, key = { it }) { idx ->
                                PdfPageCard(
                                    renderer = renderer,
                                    pageIndex = idx,
                                    pageCount = pageCount,
                                    dispatcher = renderDispatcher,
                                    isClosed = isClosed,
                                    cache = bitmapCache,
                                )
                            }
                        }
                    }

                    else -> CircularProgressIndicator()
                }
            }
        }
    }
}

private fun renderPageSafe(
    renderer: PdfRenderer,
    pageIndex: Int,
    maxDim: Float,
): Bitmap {
    renderer.openPage(pageIndex).use { page ->
        val pw = page.width.coerceAtLeast(1).toFloat()
        val ph = page.height.coerceAtLeast(1).toFloat()
        val scale = minOf(1.5f, maxDim / max(pw, ph))
        val w = (pw * scale).roundToInt().coerceIn(32, maxDim.roundToInt())
        val h = (ph * scale).roundToInt().coerceIn(32, maxDim.roundToInt())
        // Android PdfRenderer.Page.render strictly requires ARGB_8888
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.eraseColor(AndroidColor.WHITE)
        page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return b
    }
}

@Composable
private fun PdfPageCard(
    renderer: PdfRenderer,
    pageIndex: Int,
    pageCount: Int,
    dispatcher: CoroutineDispatcher,
    isClosed: AtomicBoolean,
    cache: LruCache<Int, Bitmap>,
) {
    var bmp by remember(pageIndex) { mutableStateOf(cache.get(pageIndex)) }
    var pageError by remember(pageIndex) { mutableStateOf<String?>(null) }
    var retryTick by remember(pageIndex) { mutableIntStateOf(0) }

    LaunchedEffect(pageIndex, retryTick) {
        if (bmp == null) {
            pageError = null
            try {
                val rendered = withContext(dispatcher) {
                    ensureActive()
                    if (isClosed.get()) return@withContext null
                    cache.get(pageIndex) ?: try {
                        val b = renderPageSafe(renderer, pageIndex, maxDim = 1200f)
                        cache.put(pageIndex, b)
                        b
                    } catch (_: OutOfMemoryError) {
                        cache.evictAll()
                        val b = renderPageSafe(renderer, pageIndex, maxDim = 720f)
                        cache.put(pageIndex, b)
                        b
                    }
                }
                if (rendered != null) {
                    bmp = rendered
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                if (!isClosed.get()) {
                    pageError = t.message ?: t.javaClass.simpleName
                }
            }
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth(),
    ) {
        when {
            bmp != null -> {
                val rawAspect = bmp!!.width.toFloat() / bmp!!.height.toFloat().coerceAtLeast(1f)
                val safeAspect = rawAspect.coerceIn(0.18f, 4.0f)
                Image(
                    bitmap = bmp!!.asImageBitmap(),
                    contentDescription = "Page ${pageIndex + 1}",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(safeAspect)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.White),
                )
            }
            pageError != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B))
                        .clickable { retryTick++ }
                        .padding(16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "Unable to render page ${pageIndex + 1}\n($pageError)\nTap to retry",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center,
                    )
                }
            }
            else -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(420.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B)),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Page ${pageIndex + 1} of $pageCount",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF94A3B8),
        )
    }
}
