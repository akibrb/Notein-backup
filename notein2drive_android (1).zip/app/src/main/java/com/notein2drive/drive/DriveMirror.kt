package com.notein2drive.drive

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Google Drive v3 REST mirror using OkHttp and OAuth2 bearer token (`drive.file` scope).
 *
 * - Idempotent folder creation with in-memory `(parentId, name) -> folderId` cache
 * - Idempotent PDF upload keyed by `appProperties.notein_id` (creates, updates in place, or moves)
 * - Supports `--prune` (moves deleted note PDFs and empty subfolders to Drive Trash)
 * - Automatic exponential backoff on transient HTTP 429/5xx errors
 */
class DriveMirror(
    private val accessToken: String,
    private val rootName: String = "Notein PDFs",
    private var rootIdOverride: String? = null,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build(),
) {
    companion object {
        const val FOLDER_MIME = "application/vnd.google-apps.folder"
        private const val FILES_ENDPOINT = "https://www.googleapis.com/drive/v3/files"
        private const val UPLOAD_ENDPOINT = "https://www.googleapis.com/upload/drive/v3/files"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    }

    data class DriveFileInfo(
        val id: String,
        val name: String,
        val parents: List<String>,
        val noteinId: String? = null,
    )

    private val folderCache = HashMap<Pair<String, String>, String>()

    private fun escapeQuery(s: String): String =
        s.replace("\\", "\\\\").replace("'", "\\'")

    private fun executeJson(request: Request, retries: Int = 3): JSONObject {
        var lastError: Exception? = null
        for (attempt in 0 until retries) {
            try {
                client.newCall(request).execute().use { resp ->
                    val bodyStr = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        return if (bodyStr.isBlank()) JSONObject() else JSONObject(bodyStr)
                    }
                    val code = resp.code
                    if (code in setOf(429, 500, 502, 503, 504) && attempt < retries - 1) {
                        Thread.sleep(1000L * (1L shl attempt))
                        return@use
                    }
                    throw IOException("Drive API HTTP $code: $bodyStr")
                }
            } catch (e: IOException) {
                lastError = e
                if (attempt < retries - 1) {
                    Thread.sleep(1000L * (1L shl attempt))
                } else {
                    throw e
                }
            }
        }
        throw lastError ?: IOException("Drive API request failed")
    }

    private fun authBuilder(url: okhttp3.HttpUrl): Request.Builder =
        Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")

    private fun listAll(query: String, fields: String = "files(id,name,parents,appProperties)"): List<JSONObject> {
        val results = ArrayList<JSONObject>()
        var pageToken: String? = null
        do {
            val urlBuilder = FILES_ENDPOINT.toHttpUrl().newBuilder()
                .addQueryParameter("q", query)
                .addQueryParameter("fields", "nextPageToken,$fields")
                .addQueryParameter("pageSize", "100")
                .addQueryParameter("spaces", "drive")
            if (pageToken != null) {
                urlBuilder.addQueryParameter("pageToken", pageToken)
            }
            val json = executeJson(authBuilder(urlBuilder.build()).get().build())
            val files = json.optJSONArray("files") ?: JSONArray()
            for (i in 0 until files.length()) {
                results.add(files.getJSONObject(i))
            }
            pageToken = json.optString("nextPageToken").takeIf { it.isNotBlank() }
        } while (pageToken != null)
        return results
    }

    // -- Folders ---------------------------------------------------------------------------------

    private fun findFolder(name: String, parentId: String): String? {
        val q = "mimeType='$FOLDER_MIME' and name='${escapeQuery(name)}' and '$parentId' in parents and trashed=false"
        val url = FILES_ENDPOINT.toHttpUrl().newBuilder()
            .addQueryParameter("q", q)
            .addQueryParameter("fields", "files(id,name)")
            .addQueryParameter("pageSize", "2")
            .addQueryParameter("spaces", "drive")
            .build()
        val files = executeJson(authBuilder(url).get().build()).optJSONArray("files") ?: return null
        return if (files.length() > 0) files.getJSONObject(0).getString("id") else null
    }

    private fun ensureFolder(name: String, parentId: String): String {
        val key = parentId to name
        folderCache[key]?.let { return it }
        val existing = findFolder(name, parentId)
        val id = existing ?: run {
            val meta = JSONObject()
                .put("name", name)
                .put("mimeType", FOLDER_MIME)
                .put("parents", JSONArray().put(parentId))
            val url = FILES_ENDPOINT.toHttpUrl().newBuilder()
                .addQueryParameter("fields", "id")
                .build()
            val req = authBuilder(url)
                .post(meta.toString().toRequestBody(JSON_MEDIA))
                .build()
            executeJson(req).getString("id")
        }
        folderCache[key] = id
        return id
    }

    fun getRootId(): String {
        if (rootIdOverride.isNullOrBlank()) {
            rootIdOverride = ensureFolder(rootName, "root")
        }
        return rootIdOverride!!
    }

    fun ensurePath(parts: List<String>): String {
        var pid = getRootId()
        for (p in parts) {
            pid = ensureFolder(p, pid)
        }
        return pid
    }

    // -- Files -----------------------------------------------------------------------------------

    private fun findByNoteId(noteId: String): DriveFileInfo? {
        val q = "appProperties has { key='notein_id' and value='${escapeQuery(noteId)}' } and trashed=false"
        val url = FILES_ENDPOINT.toHttpUrl().newBuilder()
            .addQueryParameter("q", q)
            .addQueryParameter("fields", "files(id,name,parents)")
            .addQueryParameter("pageSize", "2")
            .addQueryParameter("spaces", "drive")
            .build()
        val files = executeJson(authBuilder(url).get().build()).optJSONArray("files") ?: return null
        if (files.length() == 0) return null
        val obj = files.getJSONObject(0)
        val parentsArr = obj.optJSONArray("parents") ?: JSONArray()
        val parents = List(parentsArr.length()) { parentsArr.getString(it) }
        return DriveFileInfo(obj.getString("id"), obj.getString("name"), parents, noteId)
    }

    private fun multipartRelatedBody(metadataJson: String, pdfFile: File): RequestBody {
        val boundary = "notein2drive_${System.nanoTime()}"
        val contentType = "multipart/related; boundary=$boundary".toMediaType()
        return object : RequestBody() {
            override fun contentType() = contentType
            override fun writeTo(sink: BufferedSink) {
                sink.writeUtf8("--$boundary\r\n")
                sink.writeUtf8("Content-Type: application/json; charset=UTF-8\r\n\r\n")
                sink.writeUtf8(metadataJson)
                sink.writeUtf8("\r\n--$boundary\r\n")
                sink.writeUtf8("Content-Type: application/pdf\r\n\r\n")
                pdfFile.inputStream().use { input ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        sink.write(buf, 0, n)
                    }
                }
                sink.writeUtf8("\r\n--$boundary--\r\n")
            }
        }
    }

    /** Create or update a PDF on Drive. Returns `(driveFileId, "created" | "updated" | "moved+updated")`. */
    fun uploadPdf(
        localPdf: File,
        noteId: String,
        folderParts: List<String>,
        fileName: String,
        modified: Long,
    ): Pair<String, String> {
        val parentId = ensurePath(folderParts)
        val appProps = JSONObject()
            .put("notein_id", noteId)
            .put("notein_modified", modified.toString())

        val existing = findByNoteId(noteId)
        if (existing == null) {
            val meta = JSONObject()
                .put("name", fileName)
                .put("parents", JSONArray().put(parentId))
                .put("appProperties", appProps)
            val url = UPLOAD_ENDPOINT.toHttpUrl().newBuilder()
                .addQueryParameter("uploadType", "multipart")
                .addQueryParameter("fields", "id")
                .build()
            val req = authBuilder(url).post(multipartRelatedBody(meta.toString(), localPdf)).build()
            val id = executeJson(req).getString("id")
            return id to "created"
        }

        val meta = JSONObject()
            .put("name", fileName)
            .put("appProperties", appProps)
        val moved = parentId !in existing.parents
        val urlBuilder = "$UPLOAD_ENDPOINT/${existing.id}".toHttpUrl().newBuilder()
            .addQueryParameter("uploadType", "multipart")
            .addQueryParameter("fields", "id")
        if (moved) {
            urlBuilder.addQueryParameter("addParents", parentId)
            if (existing.parents.isNotEmpty()) {
                urlBuilder.addQueryParameter("removeParents", existing.parents.joinToString(","))
            }
        }
        val req = authBuilder(urlBuilder.build()).patch(multipartRelatedBody(meta.toString(), localPdf)).build()
        executeJson(req)
        return existing.id to (if (moved) "moved+updated" else "updated")
    }

    // -- Pruning ---------------------------------------------------------------------------------

    fun trashFile(fileId: String) {
        val url = "$FILES_ENDPOINT/$fileId".toHttpUrl().newBuilder()
            .addQueryParameter("fields", "id")
            .build()
        val body = JSONObject().put("trashed", true).toString().toRequestBody(JSON_MEDIA)
        executeJson(authBuilder(url).patch(body).build())
    }

    fun listSyncedFiles(): List<DriveFileInfo> {
        val root = getRootId()
        val folderIds = LinkedHashSet<String>().apply { add(root) }
        val queue = ArrayDeque<String>().apply { add(root) }
        while (queue.isNotEmpty()) {
            val pid = queue.removeFirst()
            val q = "mimeType='$FOLDER_MIME' and '$pid' in parents and trashed=false"
            for (fo in listAll(q, "files(id,name,parents)")) {
                val id = fo.getString("id")
                if (folderIds.add(id)) queue.addLast(id)
            }
        }

        val synced = ArrayList<DriveFileInfo>()
        for (fid in folderIds) {
            val q = "mimeType!='$FOLDER_MIME' and '$fid' in parents and trashed=false"
            for (f in listAll(q, "files(id,name,parents,appProperties)")) {
                val props = f.optJSONObject("appProperties")
                val nid = props?.optString("notein_id")?.takeIf { it.isNotBlank() } ?: continue
                val parentsArr = f.optJSONArray("parents") ?: JSONArray()
                synced.add(
                    DriveFileInfo(
                        id = f.getString("id"),
                        name = f.getString("name"),
                        parents = List(parentsArr.length()) { parentsArr.getString(it) },
                        noteinId = nid,
                    )
                )
            }
        }
        return synced
    }

    fun pruneMissing(activeNoteIds: Set<String>, dryRun: Boolean = false): List<DriveFileInfo> {
        val pruned = ArrayList<DriveFileInfo>()
        for (f in listSyncedFiles()) {
            val nid = f.noteinId ?: continue
            if (nid !in activeNoteIds) {
                if (!dryRun) trashFile(f.id)
                pruned.add(f)
            }
        }
        return pruned
    }

    fun pruneEmptyFolders(dryRun: Boolean = false): List<Pair<String, String>> {
        val root = getRootId()
        val depth = HashMap<String, Int>().apply { put(root, 0) }
        val names = HashMap<String, String>().apply { put(root, rootName) }
        val queue = ArrayDeque<String>().apply { add(root) }

        while (queue.isNotEmpty()) {
            val pid = queue.removeFirst()
            val q = "mimeType='$FOLDER_MIME' and '$pid' in parents and trashed=false"
            for (fo in listAll(q, "files(id,name)")) {
                val fid = fo.getString("id")
                if (fid !in depth) {
                    depth[fid] = (depth[pid] ?: 0) + 1
                    names[fid] = fo.getString("name")
                    queue.addLast(fid)
                }
            }
        }

        val trashed = ArrayList<Pair<String, String>>()
        val candidates = depth.keys.filter { it != root }.sortedByDescending { depth[it] ?: 0 }
        for (fid in candidates) {
            val items = listAll("'$fid' in parents and trashed=false", "files(id)")
            if (items.isEmpty()) {
                if (!dryRun) trashFile(fid)
                folderCache.entries.removeIf { it.value == fid }
                trashed.add(fid to (names[fid] ?: fid))
            }
        }
        return trashed
    }
}
