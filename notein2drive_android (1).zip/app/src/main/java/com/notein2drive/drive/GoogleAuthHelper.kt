package com.notein2drive.drive

import android.accounts.Account
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Handles Google Sign-In with the minimal `drive.file` scope and retrieves fresh OAuth2 access tokens
 * for Google Drive REST API v3 calls.
 */
object GoogleAuthHelper {

    const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"

    fun buildSignInClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DRIVE_FILE_SCOPE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getLastSignedInAccount(context: Context): GoogleSignInAccount? {
        val acct = GoogleSignIn.getLastSignedInAccount(context) ?: return null
        val hasScope = GoogleSignIn.hasPermissions(acct, Scope(DRIVE_FILE_SCOPE))
        return if (hasScope) acct else null
    }

    fun signInIntent(context: Context): Intent = buildSignInClient(context).signInIntent

    suspend fun fetchAccessToken(context: Context, account: Account): String = withContext(Dispatchers.IO) {
        GoogleAuthUtil.getToken(context, account, "oauth2:$DRIVE_FILE_SCOPE")
    }
}
