package com.notein2drive.sync

import org.json.JSONObject
import java.io.File

/**
 * Crash-safe per-note manifest persisted in JSON after every note completes.
 */
object ManifestStore {

    const val MANIFEST_FILE = ".notein_manifest.json"

    data class Record(
        val modified: Long,
        val inSize: Long,
        val pdfRel: String,
        val driveId: String?,
    )

    fun load(outDir: File): MutableMap<String, Record> {
        val file = File(outDir, MANIFEST_FILE)
        val map = LinkedHashMap<String, Record>()
        if (!file.exists()) return map
        val root = JSONObject(file.readText(Charsets.UTF_8))
        val keys = root.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val obj = root.getJSONObject(k)
            map[k] = Record(
                modified = obj.optLong("modified", 0L),
                inSize = obj.optLong("in_size", 0L),
                pdfRel = obj.optString("pdf_rel", ""),
                driveId = obj.optString("drive_id").takeIf { it.isNotBlank() && it != "null" },
            )
        }
        return map
    }

    fun save(outDir: File, map: Map<String, Record>) {
        outDir.mkdirs()
        val root = JSONObject()
        for (k in map.keys.sorted()) {
            val r = map.getValue(k)
            val obj = JSONObject()
                .put("modified", r.modified)
                .put("in_size", r.inSize)
                .put("pdf_rel", r.pdfRel)
                .put("drive_id", r.driveId ?: JSONObject.NULL)
            root.put(k, obj)
        }
        File(outDir, MANIFEST_FILE).writeText(root.toString(2), Charsets.UTF_8)
    }
}
