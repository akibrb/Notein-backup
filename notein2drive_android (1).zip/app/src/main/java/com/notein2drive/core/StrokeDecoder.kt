package com.notein2drive.core

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Decodes Notein protobuf stroke blobs, transforms coordinates with 3x3 row-major matrices,
 * computes pressure-based stroke widths, and subdivides paths with Catmull-Rom splines.
 * Pure Kotlin/JVM implementation for full unit testability.
 */
object StrokeDecoder {

    const val PT = 72f / 150f // 1 Notein unit = 0.48 PDF points

    data class WidthModel(val a: Double, val b: Double, val k: Double)

    val WIDTH_MODELS = mapOf(
        "fit" to WidthModel(0.285, 0.476, 0.02),
        "guide" to WidthModel(0.92, 0.76, 0.045),
    )

    data class DecodedStroke(
        val xy: FloatArray,         // interleaved [x0, y0, x1, y1, ...]
        val pressures: FloatArray,  // per-point pressure
        val brush: Float,
        val argbColor: Int,         // Android 0xAARRGGBB color
        val m12: FloatArray,        // 9 floats, row-major 3x3
        val m13: FloatArray,        // 9 floats, row-major 3x3
    )

    data class StrokeCurve(
        val xs: FloatArray,
        val ys: FloatArray,
        val widths: FloatArray,
        val argbColor: Int,
        val isDot: Boolean,
    )

    private fun readFloatArrayLE(bytes: ByteArray): FloatArray {
        val count = bytes.size / 4
        val out = FloatArray(count)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) {
            out[i] = bb.float
        }
        return out
    }

    private fun readFloatLE(bytes: ByteArray): Float =
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).float

    private fun identity3x3(): FloatArray = floatArrayOf(
        1f, 0f, 0f,
        0f, 1f, 0f,
        0f, 0f, 1f,
    )

    /** Field 5 encodes color as A<<56 | R<<48 | G<<40 | B<<32 -> Android 0xAARRGGBB. */
    fun strokeColorToArgb(c: Long): Int {
        val a = ((c ushr 56) and 0xFFL).toInt()
        val r = ((c ushr 48) and 0xFFL).toInt()
        val g = ((c ushr 40) and 0xFFL).toInt()
        val b = ((c ushr 32) and 0xFFL).toInt()
        val alpha = if (a == 0) 0xFF else a
        return (alpha shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun decode(blob: ByteArray): DecodedStroke {
        var xy = FloatArray(0)
        var aux = FloatArray(0)
        var brush = 1f
        var color = 0xFF000000L shl 32
        var m12 = identity3x3()
        var m13 = identity3x3()

        for (field in PbParse.parse(blob)) {
            when (field.fieldNo) {
                4 -> brush = readFloatLE(field.bytesValue)
                5 -> color = field.varintValue
                10 -> xy = readFloatArrayLE(field.bytesValue)
                11 -> aux = readFloatArrayLE(field.bytesValue)
                12 -> m12 = readFloatArrayLE(field.bytesValue)
                13 -> m13 = readFloatArrayLE(field.bytesValue)
            }
        }

        val numPts = xy.size / 2
        val pressures = FloatArray(numPts) { 0.07f }
        if (aux.size == numPts * 5) {
            for (i in 0 until numPts) {
                pressures[i] = aux[i * 5 + 1]
            }
        }

        return DecodedStroke(
            xy = xy,
            pressures = pressures,
            brush = brush,
            argbColor = strokeColorToArgb(color),
            m12 = m12,
            m13 = m13,
        )
    }

    /** Multiply two 3x3 row-major matrices: A * B. */
    fun mul3x3(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(9)
        for (r in 0 until 3) {
            for (c in 0 until 3) {
                out[r * 3 + c] =
                    a[r * 3 + 0] * b[0 * 3 + c] +
                    a[r * 3 + 1] * b[1 * 3 + c] +
                    a[r * 3 + 2] * b[2 * 3 + c]
            }
        }
        return out
    }

    fun toCurve(s: DecodedStroke, widthModelName: String = "fit"): StrokeCurve {
        val model = WIDTH_MODELS[widthModelName] ?: WIDTH_MODELS.getValue("fit")
        val n = s.xy.size / 2
        if (n == 0) {
            return StrokeCurve(FloatArray(0), FloatArray(0), FloatArray(0), s.argbColor, true)
        }

        val m = mul3x3(s.m13, s.m12)
        val det = m[0].toDouble() * m[4].toDouble() - m[1].toDouble() * m[3].toDouble()
        val sc = sqrt(abs(det))

        val px = FloatArray(n)
        val py = FloatArray(n)
        val pw = FloatArray(n)

        var minX = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        for (i in 0 until n) {
            val x = s.xy[i * 2]
            val y = s.xy[i * 2 + 1]
            val tx = m[0] * x + m[1] * y + m[2]
            val ty = m[3] * x + m[4] * y + m[5]
            px[i] = tx
            py[i] = ty
            if (tx < minX) minX = tx
            if (tx > maxX) maxX = tx
            if (ty < minY) minY = ty
            if (ty > maxY) maxY = ty

            val press = s.pressures[i].toDouble()
            pw[i] = (s.brush * sc * (model.a + model.b * (1.0 - exp(-press / model.k)))).toFloat()
        }

        val span = hypot((maxX - minX).toDouble(), (maxY - minY).toDouble())
        if (n == 1 || span < 1e-3) {
            var avgW = 0f
            for (w in pw) avgW += w
            avgW /= n
            return StrokeCurve(floatArrayOf(px[0]), floatArrayOf(py[0]), floatArrayOf(avgW), s.argbColor, true)
        }

        val (cx, cy, cw) = catmullRom(px, py, pw, step = 2.0)
        return StrokeCurve(cx, cy, cw, s.argbColor, false)
    }

    private fun catmullRom(
        px: FloatArray,
        py: FloatArray,
        pw: FloatArray,
        step: Double = 2.0,
    ): Triple<FloatArray, FloatArray, FloatArray> {
        val n = px.size
        if (n < 3) return Triple(px, py, pw)

        val outX = ArrayList<Float>(n * 3)
        val outY = ArrayList<Float>(n * 3)
        val outW = ArrayList<Float>(n * 3)
        outX.add(px[0])
        outY.add(py[0])
        outW.add(pw[0])

        fun gx(idx: Int) = px[idx.coerceIn(0, n - 1)]
        fun gy(idx: Int) = py[idx.coerceIn(0, n - 1)]

        for (i in 0 until n - 1) {
            val x0 = gx(i - 1); val y0 = gy(i - 1)
            val x1 = gx(i);     val y1 = gy(i)
            val x2 = gx(i + 1); val y2 = gy(i + 1)
            val x3 = gx(i + 2); val y3 = gy(i + 2)

            val segLen = hypot((x2 - x1).toDouble(), (y2 - y1).toDouble())
            val steps = max(1, (segLen / step).toInt())
            for (k in 1..steps) {
                val t = k.toFloat() / steps.toFloat()
                val t2 = t * t
                val t3 = t2 * t
                val rx = 0.5f * (
                    (2f * x1) +
                    (-x0 + x2) * t +
                    (2f * x0 - 5f * x1 + 4f * x2 - x3) * t2 +
                    (-x0 + 3f * x1 - 3f * x2 + x3) * t3
                )
                val ry = 0.5f * (
                    (2f * y1) +
                    (-y0 + y2) * t +
                    (2f * y0 - 5f * y1 + 4f * y2 - y3) * t2 +
                    (-y0 + 3f * y1 - 3f * y2 + y3) * t3
                )
                val rw = pw[i] + (pw[i + 1] - pw[i]) * t
                outX.add(rx)
                outY.add(ry)
                outW.add(rw)
            }
        }
        return Triple(outX.toFloatArray(), outY.toFloatArray(), outW.toFloatArray())
    }
}
