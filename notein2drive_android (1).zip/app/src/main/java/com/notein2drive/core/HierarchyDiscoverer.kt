package com.notein2drive.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

/**
 * Discovers Notein `.in` notes and computes their exact combined folder hierarchy:
 *   `<on-disk subfolders>/<Notein folder chain>/<note title>.pdf`
 *
 * Supports:
 *  - Android SAF Uri (single backup `.zip`, single `.in`, or an entire folder tree with nested `.zip`s)
 *  - Direct local File/directory paths (also used for JVM unit tests)
 */
object HierarchyDiscoverer {

    private val WRAPPER_RE = Regex("^n_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
    private val BAD_CHARS = Regex("""[\\/:*?"<>|\u0000-\u001F]""")

    data class NoteinFolder(
        val id: String,
        val title: String,
        val parentId: String?,
        val inTrashBin: Boolean,
    )

    data class NoteEntry(
        val noteId: String,
        val title: String,
        val inFile: File,
        val folderParts: List<String>,
        var pdfRel: String = "",
        val trashed: Boolean = false,
        val created: Long = 0L,
        val modified: Long = 0L,
        val inSize: Long = 0L,
    )

    data class Inventory(
        val sourceLabel: String,
        val entries: List<NoteEntry>,
        val folders: Map<String, NoteinFolder>,
        val warnings: List<String>,
        private val tempDirs: List<File>,
    ) {
        fun cleanup() {
            for (d in tempDirs) d.deleteRecursively()
        }

        fun renderTree(): String = entries
            .sortedBy { it.pdfRel.lowercase() }
            .joinToString("\n") { e -> e.pdfRel + if (e.trashed) "   [trashed]" else "" }
    }

    fun safeName(s: String?, default: String = "Untitled"): String {
        val cleaned = BAD_CHARS.replace(s ?: "", "_").trim().trimEnd('.', ' ')
        return cleaned.take(150).ifEmpty { default }
    }

    /** Discover from an Android SAF Uri (tree folder, backup .zip, or single .in). */
    fun discoverFromUri(
        context: Context,
        uri: Uri,
        isTreeUri: Boolean,
        includeTrashed: Boolean = false,
    ): Inventory {
        val staging = File(context.cacheDir, "notein_stage_${System.nanoTime()}").apply { mkdirs() }
        val label: String
        if (isTreeUri) {
            val tree = DocumentFile.fromTreeUri(context, uri)
                ?: throw IllegalArgumentException("Cannot access selected folder")
            label = tree.name ?: "Selected Folder"
            copyDocumentTree(context, tree, staging)
        } else {
            val fileName = queryDisplayName(context, uri) ?: "backup.zip"
            label = fileName
            val localCopy = File(staging, safeName(fileName, "backup.zip"))
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(localCopy).use { output -> input.copyTo(output) }
            } ?: throw IllegalArgumentException("Cannot read selected file")
            return discoverFromFile(localCopy, includeTrashed, extraTempDirs = listOf(staging), labelOverride = label)
        }
        return discoverFromFile(staging, includeTrashed, extraTempDirs = listOf(staging), labelOverride = label)
    }

    /** Discover from a local File (backup `.zip`, directory with optional nested `.zip`s, or single `.in`). */
    fun discoverFromFile(
        source: File,
        includeTrashed: Boolean = false,
        extraTempDirs: List<File> = emptyList(),
        labelOverride: String? = null,
    ): Inventory {
        val tmps = ArrayList<File>(extraTempDirs)
        val warnings = ArrayList<String>()
        val folders = LinkedHashMap<String, NoteinFolder>()

        val scanRoot: File
        var singleFile: File? = null
        if (source.isFile && source.name.lowercase().endsWith(".zip")) {
            val tmp = createTempDir("notein_zip_")
            tmps.add(tmp)
            NoteinConverter.extractZipSafe(source, tmp)
            scanRoot = tmp
        } else if (source.isFile && source.name.lowercase().endsWith(".in")) {
            scanRoot = source.parentFile ?: source
            singleFile = source.canonicalFile
        } else {
            scanRoot = source
        }

        // Unpack any nested .zip archives inside scanRoot
        val extractedNested = ArrayList<Pair<File, List<String>>>()
        if (singleFile == null) {
            scanRoot.walkTopDown().sortedBy { it.path }.forEach { f ->
                if (f.isFile && f.name.lowercase().endsWith(".zip")) {
                    val tmp = createTempDir("notein_nested_")
                    tmps.add(tmp)
                    try {
                        NoteinConverter.extractZipSafe(f, tmp)
                        extractedNested.add(tmp to diskParts(f.parentFile ?: scanRoot, scanRoot))
                    } catch (e: Exception) {
                        warnings.add("skipped nested zip ${f.name}: ${e.message}")
                    }
                }
            }
        }

        // Load folder.tree from scanRoot and all extracted nested zips
        loadFolderTrees(scanRoot, folders, warnings)
        for ((tmp, _) in extractedNested) {
            loadFolderTrees(tmp, folders, warnings)
        }

        // Collect all raw .in files with their on-disk prefix
        val rawNotes = ArrayList<Pair<File, List<String>>>()
        if (singleFile != null) {
            rawNotes.add(singleFile to emptyList())
        } else {
            scanRoot.walkTopDown().sortedBy { it.path }.forEach { f ->
                if (f.isFile && f.name.lowercase().endsWith(".in")) {
                    rawNotes.add(f to diskParts(f.parentFile ?: scanRoot, scanRoot))
                }
            }
            for ((tmp, prefix) in extractedNested) {
                tmp.walkTopDown().sortedBy { it.path }.forEach { f ->
                    if (f.isFile && f.name.lowercase().endsWith(".in")) {
                        rawNotes.add(f to (prefix + diskParts(f.parentFile ?: tmp, tmp)))
                    }
                }
            }
        }

        val entries = ArrayList<NoteEntry>()
        val seenIds = HashSet<String>()
        for ((inFile, diskPrefix) in rawNotes) {
            val meta = try {
                readMetaPure(inFile)
            } catch (e: Exception) {
                warnings.add("skipped ${inFile.name}: not a readable Notein file (${e.message})")
                continue
            }
            val nid = meta.optString("id").ifBlank { inFile.nameWithoutExtension }
            if (!seenIds.add(nid)) {
                warnings.add("duplicate note id $nid skipped at ${inFile.name}")
                continue
            }
            val pid = meta.optString("parentId").takeIf { it.isNotBlank() && it != "null" }
            val logical = if (pid != null) folderChain(folders, pid, warnings) else emptyList()
            val trashed = meta.optBoolean("inTrashBin", false) || isFolderTrashed(folders, pid)
            val title = safeName(meta.optString("title").ifBlank { inFile.nameWithoutExtension })
            entries.add(
                NoteEntry(
                    noteId = nid,
                    title = title,
                    inFile = inFile,
                    folderParts = diskPrefix + logical,
                    trashed = trashed,
                    created = meta.optLong("creationTime", 0L),
                    modified = meta.optLong("lastModificationTime", 0L),
                    inSize = inFile.length(),
                )
            )
        }

        val filtered = if (!includeTrashed) {
            val trashedCount = entries.count { it.trashed }
            if (trashedCount > 0) {
                warnings.add("$trashedCount trashed note(s) skipped (enable 'Include trashed' to keep)")
            }
            entries.filterNot { it.trashed }
        } else {
            entries
        }

        assignUniquePaths(filtered)
        return Inventory(
            sourceLabel = labelOverride ?: source.name,
            entries = filtered,
            folders = folders,
            warnings = warnings,
            tempDirs = tmps,
        )
    }

    private fun readMetaPure(inFile: File): JSONObject {
        ZipFile(inFile).use { zip ->
            val entry = zip.getEntry("note_meta.json")
                ?: throw IllegalArgumentException("note_meta.json missing")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
            return JSONObject(text)
        }
    }

    private fun loadFolderTrees(root: File, out: MutableMap<String, NoteinFolder>, warnings: MutableList<String>) {
        root.walkTopDown().sortedBy { it.path }.forEach { f ->
            if (f.isFile && f.name.endsWith(".tree")) {
                try {
                    ZipFile(f).use { z ->
                        val entry = z.getEntry("folder_tree.json") ?: return@use
                        val arr = JSONArray(z.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText())
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            val id = obj.getString("id")
                            val title = obj.optString("title", "")
                            val parentId = obj.optString("parentId").takeIf { it.isNotBlank() && it != "null" }
                            val trashed = obj.optBoolean("inTrashBin", false)
                            out[id] = NoteinFolder(id, title, parentId, trashed)
                        }
                    }
                } catch (e: Exception) {
                    warnings.add("cannot read ${f.name}: ${e.message}")
                }
            }
        }
    }

    private fun folderChain(
        folders: Map<String, NoteinFolder>,
        startPid: String,
        warnings: MutableList<String>,
    ): List<String> {
        val parts = ArrayList<String>()
        val seen = HashSet<String>()
        var pid: String? = startPid
        while (pid != null) {
            if (!seen.add(pid)) {
                warnings.add("folder cycle at $pid")
                break
            }
            val fo = folders[pid]
            if (fo == null) {
                parts.add("_Unknown folder ${pid.take(8)}")
                break
            }
            parts.add(fo.title.ifBlank { "Folder ${pid.take(8)}" })
            pid = fo.parentId
        }
        return parts.asReversed().map { safeName(it, "Folder") }
    }

    private fun isFolderTrashed(folders: Map<String, NoteinFolder>, startPid: String?): Boolean {
        val seen = HashSet<String>()
        var pid = startPid
        while (pid != null && seen.add(pid)) {
            val fo = folders[pid] ?: return false
            if (fo.inTrashBin) return true
            pid = fo.parentId
        }
        return false
    }

    private fun diskParts(dir: File, root: File): List<String> {
        val rel = dir.relativeTo(root).path
        if (rel.isEmpty() || rel == ".") return emptyList()
        return rel.split(File.separatorChar, '/', '\\')
            .filter { it.isNotEmpty() && !WRAPPER_RE.matches(it) }
            .map { safeName(it) }
    }

    private fun assignUniquePaths(entries: List<NoteEntry>) {
        val used = HashMap<String, Int>()
        for (e in entries.sortedWith(compareBy<NoteEntry> { it.created }.thenBy { it.noteId })) {
            val base = (e.folderParts + e.title).joinToString("/")
            val key = base.lowercase()
            val n = (used[key] ?: 0) + 1
            used[key] = n
            e.pdfRel = (if (n == 1) base else "$base ($n)") + ".pdf"
        }
    }

    private fun copyDocumentTree(context: Context, doc: DocumentFile, dstDir: File) {
        for (child in doc.listFiles()) {
            val name = child.name ?: continue
            if (child.isDirectory) {
                val sub = File(dstDir, name).apply { mkdirs() }
                copyDocumentTree(context, child, sub)
            } else if (
                name.lowercase().endsWith(".in") ||
                name.lowercase().endsWith(".zip") ||
                name.lowercase().endsWith(".tree")
            ) {
                val target = File(dstDir, name)
                context.contentResolver.openInputStream(child.uri)?.use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
            }
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment
    }

    private fun createTempDir(prefix: String): File {
        val base = File(System.getProperty("java.io.tmpdir") ?: "/tmp")
        val dir = File(base, "$prefix${System.nanoTime()}")
        dir.mkdirs()
        return dir
    }
}
