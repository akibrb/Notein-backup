package com.notein2drive.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Converts a single Notein `.in` file (ZIP containing SQLite db + `-wal`/`-shm` + media)
 * into a native vector PDF using Android's `PdfDocument`.
 */
object NoteinConverter {

    private val CLOSED_SHAPES = setOf(2, 3, 4, 5, 6, 8)
    private val UUID_RE = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private const val PT = StrokeDecoder.PT

    data class ConvertStats(
        val pages: Int,
        val strokes: Int,
        val shapes: Int,
        val images: Int,
        val warnings: List<String>,
    )

    private sealed class DrawItem(val creationTime: Long, val orderRank: Int) {
        class ImageItem(
            creationTime: Long,
            val uri: String?,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
            val rotation: Float,
        ) : DrawItem(creationTime, 0)

        class StrokeItem(
            creationTime: Long,
            val stroke: StrokeDecoder.DecodedStroke,
        ) : DrawItem(creationTime, 1)

        class ShapeItem(
            creationTime: Long,
            val color: Int,
            val width: Float,
            val type: Int,
            val blendMode: Int,
            val pointsJson: String,
        ) : DrawItem(creationTime, 2)
    }

    /** Reads `note_meta.json` directly from inside a `.in` archive without extracting the database. */
    fun readMeta(inFile: File): JSONObject {
        ZipFile(inFile).use { zip ->
            val entry = zip.getEntry("note_meta.json")
                ?: throw IllegalArgumentException("note_meta.json missing in ${inFile.name}")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
            return JSONObject(text)
        }
    }

    fun convert(
        context: Context,
        inFile: File,
        outPdf: File,
        widthModel: String = "fit",
    ): ConvertStats {
        val tmpDir = File(context.cacheDir, "notein_conv_${System.nanoTime()}")
        tmpDir.mkdirs()
        val warnings = LinkedHashSet<String>()
        var pageCount = 0
        var strokeCount = 0
        var shapeCount = 0
        var imageCount = 0

        try {
            // 1. Extract the full .in ZIP so SQLite replays -wal and -shm files cleanly
            extractZipSafe(inFile, tmpDir)

            val dbFile = tmpDir.listFiles()?.firstOrNull {
                it.name.startsWith("note_database_note_") && it.name.endsWith("_db")
            } ?: throw IllegalStateException("SQLite database not found in ${inFile.name}")

            // Open READWRITE on the temp copy so Android SQLite replays the -wal file reliably
            val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
            val pdfDoc = PdfDocument()
            try {
                val pageIds = readPageList(db)
                if (countTable(db, "PdfInfoEntity") > 0) {
                    warnings.add("note is attached to a source PDF (PdfInfoEntity): background PDF NOT rendered")
                }
                if (countTable(db, "TextBoxEntity") > 0) {
                    warnings.add("TextBoxEntity rows present: text boxes NOT rendered")
                }

                val itemsByPage = HashMap<String, MutableList<DrawItem>>()

                // Read strokes
                db.rawQuery(
                    "SELECT page_id, creation_time, ink_stroke_blob FROM StrokeEntity",
                    null,
                ).use { c ->
                    while (c.moveToNext()) {
                        val pid = c.getString(0) ?: continue
                        val ctime = c.getLong(1)
                        val blob = c.getBlob(2)
                        if (blob != null && blob.isNotEmpty()) {
                            val decoded = StrokeDecoder.decode(blob)
                            itemsByPage.getOrPut(pid) { ArrayList() }
                                .add(DrawItem.StrokeItem(ctime, decoded))
                        } else {
                            warnings.add("old-format stroke (record_json) skipped: not implemented")
                        }
                    }
                }

                // Read shapes
                db.rawQuery(
                    "SELECT page_id, creation_time, color, width, type, blend_mode, points FROM ShapeEntity",
                    null,
                ).use { c ->
                    while (c.moveToNext()) {
                        val pid = c.getString(0) ?: continue
                        itemsByPage.getOrPut(pid) { ArrayList() }.add(
                            DrawItem.ShapeItem(
                                creationTime = c.getLong(1),
                                color = c.getInt(2),
                                width = c.getFloat(3),
                                type = c.getInt(4),
                                blendMode = c.getInt(5),
                                pointsJson = c.getString(6) ?: "[]",
                            )
                        )
                    }
                }

                // Read images
                db.rawQuery(
                    "SELECT page_id, creation_time, uri, left, top, right, bottom, rotation FROM ImageEntity",
                    null,
                ).use { c ->
                    while (c.moveToNext()) {
                        val pid = c.getString(0) ?: continue
                        itemsByPage.getOrPut(pid) { ArrayList() }.add(
                            DrawItem.ImageItem(
                                creationTime = c.getLong(1),
                                uri = c.getString(2),
                                left = c.getFloat(3),
                                top = c.getFloat(4),
                                right = c.getFloat(5),
                                bottom = c.getFloat(6),
                                rotation = if (c.isNull(7)) 0f else c.getFloat(7),
                            )
                        )
                    }
                }

                // Render each live page in page_list order (trashed pages are omitted)
                var pageNumber = 1
                for (pid in pageIds) {
                    val pageRow = readPageEntity(db, pid)
                    if (pageRow == null) {
                        warnings.add("page $pid listed but missing")
                        continue
                    }

                    val pwPt = (pageRow.width * PT).roundToInt().coerceAtLeast(1)
                    val phPt = (pageRow.height * PT).roundToInt().coerceAtLeast(1)
                    val pageInfo = PdfDocument.PageInfo.Builder(pwPt, phPt, pageNumber++).create()
                    val page = pdfDoc.startPage(pageInfo)
                    val canvas = page.canvas

                    // Background fill
                    val bgPaint = Paint().apply {
                        style = Paint.Style.FILL
                        color = pageRow.bgColor or (0xFF shl 24)
                    }
                    canvas.drawRect(0f, 0f, pwPt.toFloat(), phPt.toFloat(), bgPaint)

                    // Clip to page bounds and draw items in creation_time order
                    canvas.save()
                    canvas.clipRect(0f, 0f, pwPt.toFloat(), phPt.toFloat())
                    val items = itemsByPage[pid].orEmpty()
                        .sortedWith(compareBy<DrawItem> { it.creationTime }.thenBy { it.orderRank })

                    for (item in items) {
                        when (item) {
                            is DrawItem.StrokeItem -> {
                                drawStroke(canvas, item.stroke, widthModel)
                                strokeCount++
                            }
                            is DrawItem.ShapeItem -> {
                                drawShape(canvas, item)
                                shapeCount++
                            }
                            is DrawItem.ImageItem -> {
                                drawImage(canvas, item, tmpDir, warnings)
                                imageCount++
                            }
                        }
                    }

                    canvas.restore()
                    pdfDoc.finishPage(page)
                    pageCount++
                }

                // If a note has no live pages, emit a blank A4 page
                if (pageCount == 0) {
                    val info = PdfDocument.PageInfo.Builder((1240 * PT).roundToInt(), (1754 * PT).roundToInt(), 1).create()
                    val blank = pdfDoc.startPage(info)
                    pdfDoc.finishPage(blank)
                }

                outPdf.parentFile?.mkdirs()
                FileOutputStream(outPdf).use { fos ->
                    pdfDoc.writeTo(fos)
                }
            } finally {
                pdfDoc.close()
                db.close()
            }
        } finally {
            tmpDir.deleteRecursively()
        }

        return ConvertStats(
            pages = pageCount,
            strokes = strokeCount,
            shapes = shapeCount,
            images = imageCount,
            warnings = warnings.sorted(),
        )
    }

    private data class PageSpec(val width: Float, val height: Float, val bgColor: Int)

    private fun readPageList(db: SQLiteDatabase): List<String> {
        db.rawQuery("SELECT page_list FROM NoteContentEntity LIMIT 1", null).use { c ->
            if (!c.moveToFirst()) return emptyList()
            val raw = c.getString(0) ?: return emptyList()
            val arr = JSONArray(raw)
            return List(arr.length()) { idx -> arr.getString(idx) }
        }
    }

    private fun countTable(db: SQLiteDatabase, table: String): Int {
        return try {
            db.rawQuery("SELECT COUNT(*) FROM $table", null).use { c ->
                if (c.moveToFirst()) c.getInt(0) else 0
            }
        } catch (_: Exception) {
            0
        }
    }

    private fun readPageEntity(db: SQLiteDatabase, pid: String): PageSpec? {
        db.rawQuery(
            "SELECT paper_spec, page_orientation, paper_theme FROM PageEntity WHERE id = ?",
            arrayOf(pid),
        ).use { c ->
            if (!c.moveToFirst()) return null
            val spec = JSONObject(c.getString(0))
            var w = spec.getDouble("width").toFloat()
            var h = spec.getDouble("height").toFloat()
            val orient = c.getString(1) ?: ""
            if (orient == "HORIZONTAL" && w < h) {
                val tmp = w; w = h; h = tmp
            }
            val theme = JSONObject(c.getString(2))
            val bgColor = theme.getJSONObject("baseTheme").getInt("color")
            return PageSpec(w, h, bgColor)
        }
    }

    private fun drawStroke(canvas: Canvas, decoded: StrokeDecoder.DecodedStroke, widthModel: String) {
        val curve = StrokeDecoder.toCurve(decoded, widthModel)
        if (curve.xs.isEmpty()) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = curve.argbColor
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        if (curve.isDot) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(
                curve.xs[0] * PT,
                curve.ys[0] * PT,
                curve.widths[0] * PT / 2f,
                paint,
            )
            return
        }

        paint.style = Paint.Style.STROKE
        val n = curve.xs.size
        val q = IntArray(n) { (curve.widths[it] / 0.1f).roundToInt() }
        var i = 0
        val path = Path()
        while (i < n - 1) {
            var j = i
            while (j < n - 1 && abs(q[j] - q[i]) <= 1) {
                j++
            }
            if (j == i) j = i + 1
            var sumW = 0f
            for (k in i..j) sumW += curve.widths[k]
            paint.strokeWidth = (sumW / (j - i + 1)) * PT

            path.reset()
            path.moveTo(curve.xs[i] * PT, curve.ys[i] * PT)
            for (k in (i + 1)..j) {
                path.lineTo(curve.xs[k] * PT, curve.ys[k] * PT)
            }
            canvas.drawPath(path, paint)
            i = j
        }
    }

    private fun drawShape(canvas: Canvas, sh: DrawItem.ShapeItem) {
        val pts = JSONArray(sh.pointsJson)
        if (pts.length() == 0) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = sh.color or (0xFF shl 24)
            strokeWidth = sh.width * PT
            strokeCap = if (sh.blendMode == 13) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        val path = Path()
        val p0 = pts.getJSONObject(0)
        path.moveTo(p0.getDouble("x").toFloat() * PT, p0.getDouble("y").toFloat() * PT)
        for (i in 1 until pts.length()) {
            val pt = pts.getJSONObject(i)
            path.lineTo(pt.getDouble("x").toFloat() * PT, pt.getDouble("y").toFloat() * PT)
        }
        if (sh.type in CLOSED_SHAPES) {
            path.close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawImage(canvas: Canvas, im: DrawItem.ImageItem, tmpDir: File, warnings: MutableSet<String>) {
        val uuid = im.uri?.let { UUID_RE.find(it)?.value }
        val imgFile = if (uuid != null) {
            tmpDir.listFiles()?.firstOrNull { it.name.startsWith("note_image_$uuid") }
        } else null

        if (imgFile == null || !imgFile.exists()) {
            warnings.add("image file not found for uri='${im.uri}'")
            return
        }

        val bmp = BitmapFactory.decodeFile(imgFile.absolutePath)
        if (bmp == null) {
            warnings.add("could not decode image ${imgFile.name}")
            return
        }
        try {
            val l = im.left * PT
            val t = im.top * PT
            val r = im.right * PT
            val b = im.bottom * PT
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            val w = r - l
            val h = b - t
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(im.rotation) // Android Canvas rotates clockwise, matching Notein
            val dst = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)
            canvas.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
        } finally {
            bmp.recycle()
        }
    }

    internal fun extractZipSafe(zipFile: File, destDir: File) {
        val canonDest = destDir.canonicalPath + File.separator
        ZipFile(zipFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val outFile = File(destDir, entry.name)
                if (!outFile.canonicalPath.startsWith(canonDest)) {
                    throw SecurityException("Zip slip detected: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(outFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            }
        }
    }
}
