package com.notein2drive.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.notein2drive.drive.GoogleAuthHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Notein2DriveScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Notein2DriveScreen(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    val signInLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        runCatching { task.result }.onSuccess { acct -> vm.onSignedIn(acct) }
            .onFailure { vm.onSignedIn(null) }
    }

    val pickFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            vm.setSource(uri, isTree = false, label = uri.lastPathSegment ?: "Selected File")
        }
    }

    val pickFolderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            vm.setSource(uri, isTree = true, label = uri.lastPathSegment ?: "Selected Folder")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Notein2Drive") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 1. Google Account card
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Google Drive Account", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = state.signedInEmail?.let { "Connected: $it" } ?: "Not signed in",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(
                        onClick = { signInLauncher.launch(GoogleAuthHelper.signInIntent(context)) },
                        enabled = !state.busy,
                    ) {
                        Text(if (state.signedInEmail == null) "Sign in with Google" else "Switch Account")
                    }
                }
            }

            // 2. Source picker card
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. Choose Notein Backup or Folder", style = MaterialTheme.typography.titleMedium)
                    Text(state.sourceLabel, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { pickFileLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                            enabled = !state.busy,
                        ) { Text("Pick .zip / .in") }
                        OutlinedButton(
                            onClick = { pickFolderLauncher.launch(null) },
                            enabled = !state.busy,
                        ) { Text("Pick Folder") }
                    }
                }
            }

            // 3. Options card
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("2. Mirror & Sync Options", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = state.rootFolderName,
                        onValueChange = vm::updateRootFolderName,
                        label = { Text("Google Drive Root Folder") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    CheckRow("Dry run (preview Drive sync only)", state.dryRun, vm::updateDryRun)
                    CheckRow("Prune deleted notes & empty folders", state.pruneDeleted, vm::updatePruneDeleted)
                    CheckRow("Include trashed notes", state.includeTrashed, vm::updateIncludeTrashed)
                    CheckRow("Force re-convert unchanged notes", state.forceReconvert, vm::updateForceReconvert)
                }
            }

            // 4. Actions
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = vm::scan,
                    enabled = !state.busy && state.sourceUri != null,
                    modifier = Modifier.weight(1f),
                ) { Text("Scan") }
                Button(
                    onClick = { vm.convertOrSync(uploadToDrive = false) },
                    enabled = !state.busy && state.sourceUri != null,
                    modifier = Modifier.weight(1f),
                ) { Text("Convert") }
                Button(
                    onClick = { vm.convertOrSync(uploadToDrive = true) },
                    enabled = !state.busy && state.sourceUri != null,
                    modifier = Modifier.weight(1f),
                ) { Text("Sync Drive") }
            }

            if (state.busy) {
                LinearProgressIndicator(
                    progress = { state.progress },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(state.statusLine, style = MaterialTheme.typography.bodyMedium)

            if (state.treePreview.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Detected Folder Hierarchy", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(state.treePreview, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (state.logs.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Sync Log", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            state.logs.joinToString("\n"),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}
