package com.notein2drive.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.notein2drive.core.HierarchyDiscoverer
import com.notein2drive.drive.DriveMirror
import com.notein2drive.drive.GoogleAuthHelper
import com.notein2drive.sync.SyncEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class UiState(
    val signedInEmail: String? = null,
    val sourceUri: Uri? = null,
    val sourceIsTree: Boolean = false,
    val sourceLabel: String = "No backup or folder selected",
    val rootFolderName: String = "Notein PDFs",
    val includeTrashed: Boolean = false,
    val forceReconvert: Boolean = false,
    val dryRun: Boolean = true,
    val pruneDeleted: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val statusLine: String = "Select a Notein backup.zip or folder to begin.",
    val treePreview: String = "",
    val logs: List<String> = emptyList(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var account: GoogleSignInAccount? = null

    init {
        refreshAccount()
    }

    fun refreshAccount() {
        val ctx = getApplication<Application>()
        account = GoogleAuthHelper.getLastSignedInAccount(ctx)
        _state.update { it.copy(signedInEmail = account?.email) }
    }

    fun onSignedIn(acct: GoogleSignInAccount?) {
        account = acct
        _state.update {
            it.copy(
                signedInEmail = acct?.email,
                statusLine = if (acct != null) "Signed in as ${acct.email}" else "Google Sign-In cancelled",
            )
        }
    }

    fun setSource(uri: Uri, isTree: Boolean, label: String) {
        _state.update {
            it.copy(
                sourceUri = uri,
                sourceIsTree = isTree,
                sourceLabel = label,
                statusLine = "Selected: $label",
            )
        }
    }

    fun updateRootFolderName(v: String) = _state.update { it.copy(rootFolderName = v) }
    fun updateIncludeTrashed(v: Boolean) = _state.update { it.copy(includeTrashed = v) }
    fun updateForceReconvert(v: Boolean) = _state.update { it.copy(forceReconvert = v) }
    fun updateDryRun(v: Boolean) = _state.update { it.copy(dryRun = v) }
    fun updatePruneDeleted(v: Boolean) = _state.update { it.copy(pruneDeleted = v) }

    private fun appendLog(line: String) {
        _state.update { it.copy(logs = (it.logs + line).takeLast(300)) }
    }

    fun scan() {
        val st = _state.value
        val uri = st.sourceUri ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Scanning hierarchy...", logs = emptyList()) }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                inv = HierarchyDiscoverer.discoverFromUri(getApplication(), uri, st.sourceIsTree, st.includeTrashed)
                val tree = inv.renderTree().ifBlank { "(no notes found)" }
                inv.warnings.forEach { appendLog("warning: $it") }
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        treePreview = tree,
                        statusLine = "Found ${inv.entries.size} note(s) across ${inv.folders.size} Notein folder(s).",
                    )
                }
            } catch (e: Exception) {
                appendLog("Error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Scan failed: ${e.message}") }
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun convertOrSync(uploadToDrive: Boolean) {
        val st = _state.value
        val uri = st.sourceUri ?: return
        if (uploadToDrive && !st.dryRun && account?.account == null) {
            _state.update { it.copy(statusLine = "Sign in with Google first to upload to Drive.") }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    busy = true,
                    progress = 0f,
                    statusLine = if (uploadToDrive) "Syncing to Google Drive..." else "Converting notes to local PDFs...",
                    logs = emptyList(),
                )
            }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                val ctx = getApplication<Application>()
                inv = HierarchyDiscoverer.discoverFromUri(ctx, uri, st.sourceIsTree, st.includeTrashed)
                _state.update { it.copy(treePreview = inv.renderTree()) }
                inv.warnings.forEach { appendLog("warning: $it") }

                val mirror = if (uploadToDrive && !st.dryRun) {
                    val token = GoogleAuthHelper.fetchAccessToken(ctx, account!!.account!!)
                    DriveMirror(accessToken = token, rootName = st.rootFolderName.ifBlank { "Notein PDFs" })
                } else null

                val outDir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Notein_PDFs")
                val summary = SyncEngine.run(
                    context = ctx,
                    inventory = inv,
                    outDir = outDir,
                    mirror = mirror,
                    force = st.forceReconvert,
                    dryRun = uploadToDrive && st.dryRun,
                    prune = st.pruneDeleted,
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    log = { appendLog(it) },
                )

                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Done: ${summary.converted} converted, ${summary.skipped} skipped, " +
                            "${summary.uploaded} uploaded, ${summary.prunedDrive} Drive pruned, ${summary.failed.size} failed. " +
                            "Local mirror: ${outDir.absolutePath}",
                    )
                }
            } catch (e: Exception) {
                appendLog("Error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Failed: ${e.message}") }
            } finally {
                inv?.cleanup()
            }
        }
    }
}
