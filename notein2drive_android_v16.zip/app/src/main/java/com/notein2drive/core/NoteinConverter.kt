package com.notein2drive.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CancellationException
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Converts a single Notein `.in` file into a native vector PDF using Android's `PdfDocument`.
 *
 * Features:
 *  - Replays SQLite `-wal` cleanly (deletes stale `-shm`)
 *  - Respects `PageLayerEntity.visible` (skips hidden layers) and skips `tape_like = 1` mask boxes
 *  - Renders exact smooth circles/ovals (`ShapeEntity.type == 6`), smooth closed curves (`type == 5`),
 *    and smooth open curves/arcs (`type == 0`) instead of straight-line polygons
 *  - Uses translucent Multiply blending for highlighters so underlying text stays crisp and readable
 *  - Preserves exact `page_list` order for PDF-annotated notes and fits infinite-canvas notes onto
 *    a single zoomable vector PDF page
 */
object NoteinConverter {

    private val CLOSED_POLYGONS = setOf(2, 3, 4, 8)
    private val UUID_RE = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private const val PT = StrokeDecoder.PT

    data class ConvertStats(
        val pages: Int,
        val strokes: Int,
        val shapes: Int,
        val images: Int,
        val warnings: List<String>,
    )

    private data class NoteHeader(
        val pageIds: List<String>,
        val unboundedNote: Boolean,
    )

    private data class PageSpec(
        val width: Float,
        val height: Float,
        val hasExplicitSize: Boolean,
        val bgColor: Int,
        val padLeft: Float,
        val padTop: Float,
        val padRight: Float,
        val padBottom: Float,
        val padBgColor: Int,
        val isPdfPage: Boolean,
        val explicitPdfPageIndex: Int?,
        val rotationSteps: Int,
        val unbounded: Boolean,
    )

    private sealed class DrawItem(val creationTime: Long, val orderRank: Int) {
        class ImageItem(
            creationTime: Long,
            val id: String,
            val uri: String?,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
            val rotation: Float,
        ) : DrawItem(creationTime, 0)

        class StrokeItem(
            creationTime: Long,
            val stroke: StrokeDecoder.DecodedStroke,
        ) : DrawItem(creationTime, 1)

        class ShapeItem(
            creationTime: Long,
            val color: Int,
            val width: Float,
            val type: Int,
            val blendMode: Int,
            val pointsJson: String,
        ) : DrawItem(creationTime, 2)

        class TextBoxItem(
            creationTime: Long,
            val text: String,
            val textSize: Float,
            val color: Int,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
        ) : DrawItem(creationTime, 3)
    }

    fun readMeta(inFile: File): JSONObject {
        ZipFile(inFile).use { zip ->
            val entry = zip.getEntry("note_meta.json")
                ?: throw IllegalArgumentException("note_meta.json missing in ${inFile.name}")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
            return JSONObject(text)
        }
    }

    fun convert(
        context: Context,
        inFile: File,
        outPdf: File,
        widthModel: String = "fit",
        watermarkText: String? = null,
        isCancelled: () -> Boolean = { false },
    ): ConvertStats {
        val tmpDir = File(context.cacheDir, "notein_conv_${System.nanoTime()}")
        tmpDir.mkdirs()
        val warnings = LinkedHashSet<String>()
        var pageCount = 0
        var strokeCount = 0
        var shapeCount = 0
        var imageCount = 0

        try {
            if (isCancelled()) throw CancellationException("Cancelled")
            extractZipSafe(inFile, tmpDir)

            val allExtractedFiles = tmpDir.walkTopDown().filter { it.isFile }.toList()

            val dbFile = allExtractedFiles.firstOrNull {
                it.name.startsWith("note_database_note_") && it.name.endsWith("_db")
            } ?: throw IllegalStateException("SQLite database not found in ${inFile.name}")

            val shmFile = File(dbFile.parentFile, dbFile.name + "-shm")
            if (shmFile.exists()) shmFile.delete()

            val db = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.NO_LOCALIZED_COLLATORS,
            )

            val embeddedPdfFile = allExtractedFiles.firstOrNull {
                it.name.lowercase().endsWith(".pdf")
            }
            var sourcePfd: ParcelFileDescriptor? = null
            var sourceRenderer: PdfRenderer? = null
            if (embeddedPdfFile != null) {
                try {
                    sourcePfd = ParcelFileDescriptor.open(embeddedPdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                    sourceRenderer = PdfRenderer(sourcePfd)
                } catch (e: Exception) {
                    warnings.add("could not open embedded source PDF: ${e.message}")
                }
            }

            val mediaFiles = allExtractedFiles.filter { f ->
                val n = f.name.lowercase()
                !n.endsWith("_db") && !n.endsWith("_db-wal") && !n.endsWith("_db-shm") &&
                    !n.endsWith(".json") && !n.endsWith(".pdf")
            }

            val (visibleLayers, hasLayerTable) = readVisibleLayerIds(db)

            val pdfDoc = PdfDocument()
            try {
                val header = readNoteHeader(db)
                val pageIds = header.pageIds
                if (countTable(db, "PdfInfoEntity") > 0 && sourceRenderer == null) {
                    warnings.add("note is attached to a source PDF (PdfInfoEntity): background PDF not found in archive")
                }

                var pageNumber = 1
                var pdfCursor = 0

                for ((pageIdx, pid) in pageIds.withIndex()) {
                    if (isCancelled()) throw CancellationException("Cancelled")
                    val pageRow = readPageEntity(db, pid, hasEmbeddedPdf = sourceRenderer != null)
                    if (pageRow == null) {
                        warnings.add("page $pid listed but missing")
                        continue
                    }

                    val items = ArrayList<DrawItem>()
                    loadPageStrokes(db, pid, visibleLayers, hasLayerTable, items, warnings)
                    loadPageShapes(db, pid, visibleLayers, hasLayerTable, items, warnings)
                    loadPageImages(db, pid, visibleLayers, hasLayerTable, items, warnings)
                    loadPageTextBoxes(db, pid, visibleLayers, hasLayerTable, items, warnings)
                    items.sortWith(compareBy<DrawItem> { it.creationTime }.thenBy { it.orderRank })

                    val isInfiniteCanvas = (header.unboundedNote || pageRow.unbounded) && !pageRow.isPdfPage

                    var pwPt: Int
                    var basePhPt: Int
                    var phPt: Int
                    var txPt = 0f
                    var tyPt = 0f
                    var fitScale = 1f
                    var extraTopPt = 0
                    var targetPdfPageIdx: Int? = null
                    val bbox = computeContentBounds(items)

                    if (isInfiniteCanvas) {
                        if (bbox != null) {
                            val pad = 60f
                            val spanW = max(200f, (bbox[2] - bbox[0]) + 2f * pad)
                            val spanH = max(200f, (bbox[3] - bbox[1]) + 2f * pad)
                            val rawPtW = spanW * PT
                            val rawPtH = spanH * PT
                            val maxPdfPt = 14000f
                            fitScale = if (max(rawPtW, rawPtH) > maxPdfPt) maxPdfPt / max(rawPtW, rawPtH) else 1f
                            pwPt = safeRound(rawPtW * fitScale, 595).coerceIn(100, 14400)
                            basePhPt = safeRound(rawPtH * fitScale, 842).coerceIn(100, 14400)
                            phPt = basePhPt
                            txPt = (-bbox[0] + pad) * PT
                            tyPt = (-bbox[1] + pad) * PT
                        } else {
                            pwPt = safeRound(pageRow.width * PT, 595).coerceIn(50, 14400)
                            basePhPt = safeRound(pageRow.height * PT, 842).coerceIn(50, 14400)
                            phPt = basePhPt
                        }
                    } else {
                        targetPdfPageIdx = if (sourceRenderer != null && pageRow.isPdfPage) {
                            val resolved = pageRow.explicitPdfPageIndex ?: pdfCursor
                            pdfCursor = max(pdfCursor + 1, resolved + 1)
                            resolved.takeIf { it in 0 until sourceRenderer.pageCount }
                        } else {
                            null
                        }

                        pwPt = safeRound(pageRow.width * PT, 595).coerceIn(50, 14400)
                        basePhPt = safeRound(pageRow.height * PT, 842).coerceIn(50, 14400)
                        if (!pageRow.hasExplicitSize && sourceRenderer != null && targetPdfPageIdx != null) {
                            runCatching {
                                sourceRenderer.openPage(targetPdfPageIdx).use { sp ->
                                    pwPt = sp.width.coerceIn(50, 14400)
                                    basePhPt = sp.height.coerceIn(50, 14400)
                                }
                            }
                        }

                        // Auto-expand top & bottom margins when writing/diagrams spill across the joint between two pages
                        val pageHeightUnits = basePhPt / PT
                        val contentTopInPage = if (bbox != null) bbox[1] + pageRow.padTop else 0f
                        val contentBottomInPage = if (bbox != null) bbox[3] + pageRow.padTop else 0f
                        val spillTopUnits = if (bbox != null && contentTopInPage < 0f) (-contentTopInPage + 28f).coerceAtMost(450f) else 0f
                        val spillBottomUnits = if (bbox != null && contentBottomInPage > pageHeightUnits) (contentBottomInPage - pageHeightUnits + 28f).coerceAtMost(450f) else 0f
                        extraTopPt = safeRound(spillTopUnits * PT, 0)
                        val extraBottomPt = safeRound(spillBottomUnits * PT, 0)
                        phPt = (basePhPt + extraTopPt + extraBottomPt).coerceIn(50, 14400)
                        txPt = pageRow.padLeft * PT
                        tyPt = extraTopPt.toFloat() + pageRow.padTop * PT
                    }

                    val pageInfo = PdfDocument.PageInfo.Builder(pwPt, phPt, pageNumber++).create()
                    val page = pdfDoc.startPage(pageInfo)
                    val canvas = page.canvas

                    val hasPadding = pageRow.padLeft > 0f || pageRow.padTop > 0f || pageRow.padRight > 0f || pageRow.padBottom > 0f
                    val bgPaint = Paint().apply {
                        style = Paint.Style.FILL
                        color = (if (hasPadding) pageRow.padBgColor else pageRow.bgColor) or (0xFF shl 24)
                    }
                    canvas.drawRect(0f, 0f, pwPt.toFloat(), phPt.toFloat(), bgPaint)

                    if (sourceRenderer != null && targetPdfPageIdx != null) {
                        val pdfL = (pageRow.padLeft * PT).coerceIn(0f, pwPt.toFloat())
                        val pdfT = extraTopPt + (pageRow.padTop * PT).coerceIn(0f, basePhPt.toFloat())
                        val pdfR = (pwPt - pageRow.padRight * PT).coerceIn(pdfL + 10f, pwPt.toFloat())
                        val pdfB = (extraTopPt + basePhPt - pageRow.padBottom * PT).coerceIn(pdfT + 10f, (extraTopPt + basePhPt).toFloat())
                        drawSourcePdfPage(
                            canvas = canvas,
                            renderer = sourceRenderer,
                            pageIndex = targetPdfPageIdx,
                            dstRect = RectF(pdfL, pdfT, pdfR, pdfB),
                            warnings = warnings,
                        )
                    }

                    canvas.save()
                    canvas.clipRect(0f, 0f, pwPt.toFloat(), phPt.toFloat())
                    if (isInfiniteCanvas) {
                        if (fitScale != 1f) canvas.scale(fitScale, fitScale)
                        canvas.translate(txPt, tyPt)
                    } else if (txPt != 0f || tyPt != 0f) {
                        canvas.translate(txPt, tyPt)
                    }

                    for (item in items) {
                        try {
                            when (item) {
                                is DrawItem.StrokeItem -> {
                                    drawStroke(canvas, item.stroke, widthModel)
                                    strokeCount++
                                }
                                is DrawItem.ShapeItem -> {
                                    drawShape(canvas, item)
                                    shapeCount++
                                }
                                is DrawItem.ImageItem -> {
                                    if (drawImage(canvas, item, mediaFiles, warnings)) {
                                        imageCount++
                                    }
                                }
                                is DrawItem.TextBoxItem -> {
                                    drawTextBox(canvas, item)
                                }
                            }
                        } catch (e: Exception) {
                            warnings.add("skipped corrupt item on page ${pageIdx + 1}: ${e.message}")
                        }
                    }

                    canvas.restore()
                    if (!watermarkText.isNullOrBlank()) {
                        val effBg = if (sourceRenderer != null && targetPdfPageIdx != null) Color.WHITE else pageRow.bgColor
                        drawWatermark(canvas, watermarkText.trim(), pwPt, phPt, effBg)
                    }
                    pdfDoc.finishPage(page)
                    pageCount++
                }

                if (pageCount == 0) {
                    val info = PdfDocument.PageInfo.Builder(safeRound(1240 * PT, 595), safeRound(1754 * PT, 842), 1).create()
                    val blank = pdfDoc.startPage(info)
                    pdfDoc.finishPage(blank)
                }

                outPdf.parentFile?.mkdirs()
                FileOutputStream(outPdf).use { fos ->
                    pdfDoc.writeTo(fos)
                }
            } finally {
                pdfDoc.close()
                runCatching { sourceRenderer?.close() }
                runCatching { sourcePfd?.close() }
                db.close()
            }
        } finally {
            tmpDir.deleteRecursively()
        }

        return ConvertStats(
            pages = pageCount,
            strokes = strokeCount,
            shapes = shapeCount,
            images = imageCount,
            warnings = warnings.sorted(),
        )
    }

    private fun readVisibleLayerIds(db: SQLiteDatabase): Pair<Set<String>, Boolean> {
        val visible = HashSet<String>()
        var hasAny = false
        runCatching {
            db.rawQuery("SELECT id, visible FROM PageLayerEntity", null).use { c ->
                while (c.moveToNext()) {
                    hasAny = true
                    if (c.getInt(1) != 0) visible.add(c.getString(0))
                }
            }
        }
        return visible to hasAny
    }

    /** Skips detached/deleted items (`layer_id == "unspecified"`) and items on hidden layers. */
    private fun isLayerVisible(layerId: String, visibleLayers: Set<String>, hasLayerTable: Boolean): Boolean {
        if (layerId.equals("unspecified", ignoreCase = true)) return false
        if (hasLayerTable && layerId.isNotBlank()) return layerId in visibleLayers
        return true
    }

    private fun computeContentBounds(items: List<DrawItem>): FloatArray? {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        fun include(x: Float, y: Float, pad: Float = 0f) {
            if (!x.isFinite() || !y.isFinite()) return
            minX = min(minX, x - pad)
            minY = min(minY, y - pad)
            maxX = max(maxX, x + pad)
            maxY = max(maxY, y + pad)
        }

        for (item in items) {
            when (item) {
                is DrawItem.StrokeItem -> {
                    val s = item.stroke
                    val n = s.xy.size / 2
                    if (n == 0) continue
                    val m = StrokeDecoder.mul3x3(s.m13, s.m12)
                    val pad = (s.brush * 1.5f).coerceIn(2f, 80f)
                    for (i in 0 until n) {
                        val x = s.xy[i * 2]
                        val y = s.xy[i * 2 + 1]
                        val tx = m[0] * x + m[1] * y + m[2]
                        val ty = m[3] * x + m[4] * y + m[5]
                        include(tx, ty, pad)
                    }
                }
                is DrawItem.ShapeItem -> {
                    runCatching {
                        val pts = JSONArray(item.pointsJson)
                        val pad = item.width.coerceIn(2f, 80f)
                        for (i in 0 until pts.length()) {
                            val pt = pts.getJSONObject(i)
                            include(pt.optDouble("x", 0.0).toFloat(), pt.optDouble("y", 0.0).toFloat(), pad)
                        }
                    }
                }
                is DrawItem.ImageItem -> {
                    include(min(item.left, item.right), min(item.top, item.bottom))
                    include(max(item.left, item.right), max(item.top, item.bottom))
                }
                is DrawItem.TextBoxItem -> {
                    include(min(item.left, item.right), min(item.top, item.bottom))
                    include(max(item.left, item.right), max(item.top, item.bottom))
                }
            }
        }

        if (!minX.isFinite() || !minY.isFinite() || !maxX.isFinite() || !maxY.isFinite()) {
            return null
        }
        return floatArrayOf(minX, minY, maxX, maxY)
    }

    private fun safeRound(v: Float, fallback: Int): Int =
        if (v.isFinite()) v.roundToInt() else fallback

    private fun tableColumns(db: SQLiteDatabase, table: String): Set<String> {
        val cols = HashSet<String>()
        runCatching {
            db.rawQuery("PRAGMA table_info($table)", null).use { c ->
                val nameIdx = c.getColumnIndex("name")
                while (c.moveToNext()) {
                    if (nameIdx >= 0 && !c.isNull(nameIdx)) {
                        cols.add(c.getString(nameIdx).lowercase())
                    }
                }
            }
        }
        return cols
    }

    private fun readNoteHeader(db: SQLiteDatabase): NoteHeader {
        val contentCols = tableColumns(db, "NoteContentEntity")
        var pageIds: List<String> = emptyList()
        var unbounded = false

        if ("page_list" in contentCols) {
            val query = if ("unbounded_note" in contentCols) {
                "SELECT page_list, unbounded_note FROM NoteContentEntity LIMIT 1"
            } else {
                "SELECT page_list FROM NoteContentEntity LIMIT 1"
            }
            runCatching {
                db.rawQuery(query, null).use { c ->
                    if (c.moveToFirst()) {
                        val raw = if (c.isNull(0)) null else c.getString(0)
                        if ("unbounded_note" in contentCols && !c.isNull(1)) {
                            unbounded = c.getInt(1) != 0
                        }
                        if (!raw.isNullOrBlank()) {
                            val arr = JSONArray(raw)
                            val ordered = LinkedHashSet<String>()
                            for (idx in 0 until arr.length()) {
                                val id = arr.optString(idx)
                                if (id.isNotBlank()) ordered.add(id)
                            }
                            pageIds = ordered.toList()
                        }
                    }
                }
            }
        }

        // Filter out any trashed pages while preserving exact page_list order
        val pageCols = tableColumns(db, "PageEntity")
        if (pageIds.isNotEmpty() && "is_in_trash_bin" in pageCols) {
            val activeIds = HashSet<String>()
            runCatching {
                db.rawQuery("SELECT id FROM PageEntity WHERE is_in_trash_bin = 0", null).use { c ->
                    while (c.moveToNext()) activeIds.add(c.getString(0))
                }
            }
            if (activeIds.isNotEmpty()) {
                pageIds = pageIds.filter { it in activeIds }
            }
        }

        // Fallback to creation_time only if page_list is genuinely absent or empty
        if (pageIds.isEmpty()) {
            val out = ArrayList<String>()
            val fallbackQuery = if ("is_in_trash_bin" in pageCols) {
                "SELECT id FROM PageEntity WHERE is_in_trash_bin = 0 ORDER BY creation_time ASC"
            } else {
                "SELECT id FROM PageEntity ORDER BY creation_time ASC"
            }
            runCatching {
                db.rawQuery(fallbackQuery, null).use { c ->
                    while (c.moveToNext()) out.add(c.getString(0))
                }
            }
            pageIds = out
        }

        return NoteHeader(pageIds, unbounded)
    }

    private fun countTable(db: SQLiteDatabase, table: String): Int {
        return try {
            db.rawQuery("SELECT COUNT(*) FROM $table", null).use { c ->
                if (c.moveToFirst()) c.getInt(0) else 0
            }
        } catch (_: Exception) {
            0
        }
    }

    private fun findPdfPageIndex(obj: JSONObject?): Int? {
        if (obj == null) return null
        val indexKeys = listOf("pageNum", "pdfPageIndex", "pdf_page_index", "pdfIndex", "pageIndex", "page_index")
        for (k in indexKeys) {
            if (obj.has(k) && !obj.isNull(k)) {
                val v = obj.optInt(k, -1)
                if (v >= 0) return v
            }
        }
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val child = obj.optJSONObject(k)
            if (child != null) {
                findPdfPageIndex(child)?.let { return it }
            }
        }
        return null
    }

    private fun readPageEntity(db: SQLiteDatabase, pid: String, hasEmbeddedPdf: Boolean): PageSpec? {
        db.rawQuery(
            "SELECT paper_spec, page_orientation, paper_theme, rotation_direction_index, unbounded, paper_padding, padding_color, padding_style_json, source FROM PageEntity WHERE id = ?",
            arrayOf(pid),
        ).use { c ->
            if (!c.moveToFirst()) return null
            val specRaw = if (c.isNull(0)) null else c.getString(0)
            val orient = if (c.isNull(1)) "" else (c.getString(1) ?: "")
            val themeRaw = if (c.isNull(2)) null else c.getString(2)
            val rotSteps = if (c.isNull(3)) 0 else c.getInt(3)
            val unbounded = !c.isNull(4) && c.getInt(4) != 0
            val padRaw = if (c.isNull(5)) null else c.getString(5)
            val padColorCol = if (c.isNull(6)) 0 else c.getInt(6)
            val padStyleRaw = if (c.isNull(7)) null else c.getString(7)
            val sourceCol = if (c.isNull(8)) 0 else c.getInt(8)

            var w = 1240f
            var h = 1754f
            var hasExplicitSize = false
            var specObj: JSONObject? = null
            if (!specRaw.isNullOrBlank()) {
                runCatching {
                    specObj = JSONObject(specRaw)
                    val sw = specObj!!.optDouble("width", -1.0).toFloat()
                    val sh = specObj!!.optDouble("height", -1.0).toFloat()
                    if (sw.isFinite() && sw > 10f && sh.isFinite() && sh > 10f) {
                        w = sw
                        h = sh
                        hasExplicitSize = true
                    }
                }
            }
            if (orient == "HORIZONTAL" && w < h) {
                val tmp = w; w = h; h = tmp
            }

            var bgColor = Color.WHITE
            var themeObj: JSONObject? = null
            if (!themeRaw.isNullOrBlank()) {
                runCatching {
                    themeObj = JSONObject(themeRaw)
                    val base = themeObj!!.optJSONObject("baseTheme")
                    if (base != null && base.has("color")) {
                        bgColor = base.getInt("color")
                    } else if (themeObj!!.has("color")) {
                        bgColor = themeObj!!.getInt("color")
                    }
                }
            }

            // Parse extended page borders (`paper_padding` + `padding_style_json` / `padding_color`)
            var padL = 0f; var padT = 0f; var padR = 0f; var padB = 0f
            if (!padRaw.isNullOrBlank()) {
                runCatching {
                    val po = JSONObject(padRaw)
                    padL = po.optDouble("left", 0.0).toFloat().coerceAtLeast(0f)
                    padT = po.optDouble("top", 0.0).toFloat().coerceAtLeast(0f)
                    padR = po.optDouble("right", 0.0).toFloat().coerceAtLeast(0f)
                    padB = po.optDouble("bottom", 0.0).toFloat().coerceAtLeast(0f)
                }
            }
            var padBgColor = if (padColorCol != 0) padColorCol else bgColor
            if (!padStyleRaw.isNullOrBlank()) {
                runCatching {
                    val ps = JSONObject(padStyleRaw)
                    val th = ps.optJSONObject("theme") ?: ps
                    val base = th.optJSONObject("baseTheme")
                    if (base != null && base.has("color")) {
                        padBgColor = base.getInt("color")
                    }
                }
            }

            // Strict PDF page classification: Notein uses source == 2 and PdfPaperTheme with exact 0-based pageNum
            val themeType = themeObj?.optString("type").orEmpty()
            val isPdfTheme = themeType.contains("PdfPaperTheme", ignoreCase = true) ||
                themeType.contains("pdf", ignoreCase = true)
            val isPdfPage = hasEmbeddedPdf && (isPdfTheme || (sourceCol == 2 && themeType.isBlank()))
            val explicitIdx = if (isPdfPage) {
                findPdfPageIndex(themeObj) ?: findPdfPageIndex(specObj)
            } else {
                null
            }

            return PageSpec(
                width = w,
                height = h,
                hasExplicitSize = hasExplicitSize,
                bgColor = bgColor,
                padLeft = padL,
                padTop = padT,
                padRight = padR,
                padBottom = padB,
                padBgColor = padBgColor,
                isPdfPage = isPdfPage,
                explicitPdfPageIndex = explicitIdx,
                rotationSteps = rotSteps,
                unbounded = unbounded,
            )
        }
    }

    private fun loadPageStrokes(
        db: SQLiteDatabase,
        pid: String,
        visibleLayers: Set<String>,
        hasLayerTable: Boolean,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            val strokeIds = ArrayList<String>()
            db.rawQuery("SELECT id, layer_id FROM StrokeEntity WHERE page_id = ?", arrayOf(pid)).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(1)) "" else (c.getString(1) ?: "")
                    if (!isLayerVisible(lid, visibleLayers, hasLayerTable)) continue
                    strokeIds.add(c.getString(0))
                }
            }
            val batchSize = 100
            var offset = 0
            while (offset < strokeIds.size) {
                val end = minOf(offset + batchSize, strokeIds.size)
                val sub = strokeIds.subList(offset, end)
                val placeholders = sub.joinToString(",") { "?" }
                db.rawQuery(
                    "SELECT creation_time, ink_stroke_blob FROM StrokeEntity WHERE id IN ($placeholders)",
                    sub.toTypedArray(),
                ).use { c ->
                    while (c.moveToNext()) {
                        val ctime = if (c.isNull(0)) 0L else c.getLong(0)
                        val blob = if (c.isNull(1)) null else c.getBlob(1)
                        if (blob != null && blob.isNotEmpty()) {
                            runCatching { StrokeDecoder.decode(blob) }
                                .onSuccess { out.add(DrawItem.StrokeItem(ctime, it)) }
                                .onFailure { warnings.add("skipped undecodable stroke: ${it.message}") }
                        } else {
                            warnings.add("old-format stroke (record_json) skipped: not implemented")
                        }
                    }
                }
                offset = end
            }
        } catch (e: Exception) {
            warnings.add("StrokeEntity read warning: ${e.message}")
        }
    }

    private fun loadPageShapes(
        db: SQLiteDatabase,
        pid: String,
        visibleLayers: Set<String>,
        hasLayerTable: Boolean,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT creation_time, color, width, type, blend_mode, points, layer_id, tape_like FROM ShapeEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(6)) "" else (c.getString(6) ?: "")
                    val tapeLike = if (c.isNull(7)) 0 else c.getInt(7)
                    if (!isLayerVisible(lid, visibleLayers, hasLayerTable) || tapeLike != 0) continue
                    out.add(
                        DrawItem.ShapeItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            color = if (c.isNull(1)) Color.BLACK else c.getInt(1),
                            width = if (c.isNull(2)) 2f else c.getFloat(2),
                            type = if (c.isNull(3)) 0 else c.getInt(3),
                            blendMode = if (c.isNull(4)) 0 else c.getInt(4),
                            pointsJson = if (c.isNull(5)) "[]" else (c.getString(5) ?: "[]"),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("ShapeEntity read warning: ${e.message}")
        }
    }

    private fun parseBoundsJson(raw: String?): FloatArray? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val trimmed = raw.trim()
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() >= 4) {
                    floatArrayOf(
                        arr.getDouble(0).toFloat(),
                        arr.getDouble(1).toFloat(),
                        arr.getDouble(2).toFloat(),
                        arr.getDouble(3).toFloat(),
                    )
                } else null
            } else {
                val obj = JSONObject(trimmed)
                val target = obj.optJSONObject("rect")
                    ?: obj.optJSONObject("rectF")
                    ?: obj.optJSONObject("bounds")
                    ?: obj
                when {
                    target.has("left") && target.has("top") && target.has("right") && target.has("bottom") -> floatArrayOf(
                        target.getDouble("left").toFloat(),
                        target.getDouble("top").toFloat(),
                        target.getDouble("right").toFloat(),
                        target.getDouble("bottom").toFloat(),
                    )
                    target.has("x") && target.has("y") && target.has("width") && target.has("height") -> {
                        val x = target.getDouble("x").toFloat()
                        val y = target.getDouble("y").toFloat()
                        val w = target.getDouble("width").toFloat()
                        val h = target.getDouble("height").toFloat()
                        floatArrayOf(x, y, x + w, y + h)
                    }
                    else -> null
                }
            }
        }.getOrNull()
    }

    private fun loadPageImages(
        db: SQLiteDatabase,
        pid: String,
        visibleLayers: Set<String>,
        hasLayerTable: Boolean,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT id, creation_time, uri, left, top, right, bottom, rotation, bounds, layer_id FROM ImageEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(9)) "" else (c.getString(9) ?: "")
                    if (!isLayerVisible(lid, visibleLayers, hasLayerTable)) continue
                    val id = if (c.isNull(0)) "" else (c.getString(0) ?: "")
                    val ctime = if (c.isNull(1)) 0L else c.getLong(1)
                    val uri = if (c.isNull(2)) null else c.getString(2)
                    val hasCols = !c.isNull(3) && !c.isNull(4) && !c.isNull(5) && !c.isNull(6)
                    var l = if (hasCols) c.getFloat(3) else 0f
                    var t = if (hasCols) c.getFloat(4) else 0f
                    var r = if (hasCols) c.getFloat(5) else 0f
                    var b = if (hasCols) c.getFloat(6) else 0f
                    val rot = if (c.isNull(7)) 0f else c.getFloat(7)
                    val boundsRaw = if (c.isNull(8)) null else c.getString(8)

                    if (!hasCols || abs(r - l) < 1f || abs(b - t) < 1f) {
                        val parsed = parseBoundsJson(boundsRaw)
                        if (parsed != null) {
                            l = parsed[0]; t = parsed[1]; r = parsed[2]; b = parsed[3]
                        }
                    }

                    if (abs(r - l) < 1f || abs(b - t) < 1f) {
                        warnings.add("skipped image $id: missing bounds (bounds=$boundsRaw)")
                        continue
                    }

                    out.add(
                        DrawItem.ImageItem(
                            creationTime = ctime,
                            id = id,
                            uri = uri,
                            left = l,
                            top = t,
                            right = r,
                            bottom = b,
                            rotation = rot,
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("ImageEntity read warning: ${e.message}")
        }
    }

    private fun loadPageTextBoxes(
        db: SQLiteDatabase,
        pid: String,
        visibleLayers: Set<String>,
        hasLayerTable: Boolean,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT creation_time, text, text_size, default_text_color, left, top, right, bottom, layer_id FROM TextBoxEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(8)) "" else (c.getString(8) ?: "")
                    if (!isLayerVisible(lid, visibleLayers, hasLayerTable)) continue
                    val txt = if (c.isNull(1)) "" else (c.getString(1) ?: "")
                    if (txt.isBlank() || c.isNull(4) || c.isNull(5) || c.isNull(6) || c.isNull(7)) continue
                    out.add(
                        DrawItem.TextBoxItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            text = txt,
                            textSize = if (c.isNull(2)) 24f else c.getFloat(2),
                            color = if (c.isNull(3)) Color.BLACK else c.getInt(3),
                            left = c.getFloat(4),
                            top = c.getFloat(5),
                            right = c.getFloat(6),
                            bottom = c.getFloat(7),
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun drawSourcePdfPage(
        canvas: Canvas,
        renderer: PdfRenderer,
        pageIndex: Int,
        dstRect: RectF,
        warnings: MutableSet<String>,
    ) {
        try {
            renderer.openPage(pageIndex).use { srcPage ->
                val dw = dstRect.width().coerceAtLeast(10f)
                val dh = dstRect.height().coerceAtLeast(10f)
                val maxDim = 1400f
                val scale = minOf(1.5f, maxDim / max(dw, dh))
                val bmpW = (dw * scale).roundToInt().coerceIn(100, 1400)
                val bmpH = (dh * scale).roundToInt().coerceIn(100, 1600)
                val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                try {
                    bmp.eraseColor(Color.WHITE)
                    srcPage.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    canvas.drawBitmap(bmp, null, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))
                } finally {
                    bmp.recycle()
                }
            }
        } catch (e: Exception) {
            warnings.add("source PDF page ${pageIndex + 1} render warning: ${e.message}")
        }
    }

    private fun drawStroke(canvas: Canvas, decoded: StrokeDecoder.DecodedStroke, widthModel: String) {
        val curve = StrokeDecoder.toCurve(decoded, widthModel)
        if (curve.xs.isEmpty()) return

        val rawAlpha = (curve.argbColor ushr 24) and 0xFF
        val isHighlighter = decoded.isHighlighter || rawAlpha in 1..245
        val finalColor = if (isHighlighter) {
            val capped = rawAlpha.coerceAtMost(88)
            (capped shl 24) or (curve.argbColor and 0x00FFFFFF)
        } else {
            curve.argbColor
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = finalColor
            strokeCap = if (isHighlighter) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (isHighlighter) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            }
        }

        if (curve.isDot) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(
                curve.xs[0] * PT,
                curve.ys[0] * PT,
                (curve.widths[0] * PT / 2f).coerceAtLeast(0.25f),
                paint,
            )
            return
        }

        paint.style = Paint.Style.STROKE
        val n = curve.xs.size
        val q = IntArray(n) { safeRound(curve.widths[it] / 0.25f, 6) }
        var i = 0
        val path = Path()
        while (i < n - 1) {
            var j = i
            while (j < n - 1 && abs(q[j] - q[i]) <= 1) {
                j++
            }
            if (j == i) j = i + 1
            var sumW = 0f
            for (k in i..j) sumW += curve.widths[k]
            paint.strokeWidth = ((sumW / (j - i + 1)) * PT).coerceIn(0.15f, 300f)

            path.reset()
            path.moveTo(curve.xs[i] * PT, curve.ys[i] * PT)
            for (k in (i + 1)..j) {
                path.lineTo(curve.xs[k] * PT, curve.ys[k] * PT)
            }
            canvas.drawPath(path, paint)
            i = j
        }
    }

    private fun drawShape(canvas: Canvas, sh: DrawItem.ShapeItem) {
        val ptsArr = JSONArray(sh.pointsJson)
        val n = ptsArr.length()
        if (n == 0) return

        val rawAlpha = (sh.color ushr 24) and 0xFF
        if (rawAlpha == 0) return // Invisible shape

        val isHighlighter = sh.blendMode == 13 || rawAlpha < 245
        val finalColor = if (isHighlighter) {
            val capped = if (sh.blendMode == 13) rawAlpha.coerceAtMost(95) else rawAlpha.coerceAtMost(115)
            (capped shl 24) or (sh.color and 0x00FFFFFF)
        } else {
            sh.color
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = finalColor
            strokeWidth = (sh.width * PT).coerceIn(0.2f, 300f)
            strokeCap = if (isHighlighter) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (isHighlighter) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            }
        }

        val xs = FloatArray(n)
        val ys = FloatArray(n)
        for (i in 0 until n) {
            val pt = ptsArr.getJSONObject(i)
            xs[i] = pt.optDouble("x", 0.0).toFloat() * PT
            ys[i] = pt.optDouble("y", 0.0).toFloat() * PT
        }

        // Type 6: Circle / Ellipse defined by 4 cardinal points [left, top, right, bottom] (may repeat to 7-8 pts)
        if (sh.type == 6 && n >= 4) {
            val cx = (xs[0] + xs[2]) / 2f
            val cy = (ys[0] + ys[2]) / 2f
            val dx = (xs[2] - xs[0]) / 2f
            val dy = (ys[2] - ys[0]) / 2f
            val rx = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            val ry = hypot(((xs[3] - xs[1]) / 2f).toDouble(), ((ys[3] - ys[1]) / 2f).toDouble()).toFloat()
            val angleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            if (rx >= 0.5f && ry >= 0.5f) {
                canvas.save()
                canvas.translate(cx, cy)
                if (abs(angleDeg) > 0.01f) canvas.rotate(angleDeg)
                canvas.drawOval(RectF(-rx, -ry, rx, ry), paint)
                canvas.restore()
                return
            }
        }

        // Type 5: Smooth open curve / arc (must NOT be closed with a straight line back to start)
        if (sh.type == 5 && n >= 3) {
            val path = buildSmoothCurvePath(xs, ys, closed = false)
            canvas.drawPath(path, paint)
            return
        }

        // Type 0 (3+ points): Smooth open curve / arc passing through control points
        if (sh.type == 0 && n == 3) {
            val path = Path()
            path.moveTo(xs[0], ys[0])
            val cx = 2f * xs[1] - 0.5f * (xs[0] + xs[2])
            val cy = 2f * ys[1] - 0.5f * (ys[0] + ys[2])
            path.quadTo(cx, cy, xs[2], ys[2])
            canvas.drawPath(path, paint)
            return
        }
        if (sh.type == 0 && n > 3) {
            val path = buildSmoothCurvePath(xs, ys, closed = false)
            canvas.drawPath(path, paint)
            return
        }

        // Standard polyline / closed polygon (lines, triangles, rectangles, arrows)
        val path = Path()
        path.moveTo(xs[0], ys[0])
        for (i in 1 until n) {
            path.lineTo(xs[i], ys[i])
        }
        if (sh.type in CLOSED_POLYGONS) {
            path.close()
        }
        canvas.drawPath(path, paint)
    }

    /** Converts points into a smooth Catmull-Rom cubic Bezier path (open or closed). */
    private fun buildSmoothCurvePath(xs: FloatArray, ys: FloatArray, closed: Boolean): Path {
        val n = xs.size
        val path = Path()
        if (n == 0) return path
        path.moveTo(xs[0], ys[0])
        if (n == 1) return path
        if (n == 2) {
            path.lineTo(xs[1], ys[1])
            return path
        }
        val segs = if (closed) n else n - 1
        fun px(i: Int) = if (closed) xs[(i % n + n) % n] else xs[i.coerceIn(0, n - 1)]
        fun py(i: Int) = if (closed) ys[(i % n + n) % n] else ys[i.coerceIn(0, n - 1)]

        for (i in 0 until segs) {
            val p0x = px(i - 1); val p0y = py(i - 1)
            val p1x = px(i);     val p1y = py(i)
            val p2x = px(i + 1); val p2y = py(i + 1)
            val p3x = px(i + 2); val p3y = py(i + 2)

            val c1x = p1x + (p2x - p0x) / 6f
            val c1y = p1y + (p2y - p0y) / 6f
            val c2x = p2x - (p3x - p1x) / 6f
            val c2y = p2y - (p3y - p1y) / 6f
            path.cubicTo(c1x, c1y, c2x, c2y, p2x, p2y)
        }
        if (closed) path.close()
        return path
    }

    private fun decodeDownsampledBitmap(file: File, maxDim: Int = 1400): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) return null
        var sample = 1
        while (w / sample > maxDim || h / sample > maxDim) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    private fun resolveImageFile(im: DrawItem.ImageItem, mediaFiles: List<File>): File? {
        val uri = im.uri.orEmpty()
        val rawBase = uri.substringAfterLast('/').substringAfterLast('\\').substringBefore('?')
        val baseNoExt = rawBase.substringBeforeLast('.')

        if (rawBase.isNotBlank()) {
            mediaFiles.firstOrNull { it.name.equals(rawBase, ignoreCase = true) }?.let { return it }
        }
        val uriUuid = UUID_RE.find(uri)?.value
        if (!uriUuid.isNullOrBlank()) {
            mediaFiles.firstOrNull { it.name.contains(uriUuid, ignoreCase = true) }?.let { return it }
        }
        if (im.id.isNotBlank()) {
            mediaFiles.firstOrNull { it.name.contains(im.id, ignoreCase = true) }?.let { return it }
        }
        if (baseNoExt.length >= 6) {
            mediaFiles.firstOrNull { it.name.contains(baseNoExt, ignoreCase = true) }?.let { return it }
        }
        return null
    }

    private fun drawImage(
        canvas: Canvas,
        im: DrawItem.ImageItem,
        mediaFiles: List<File>,
        warnings: MutableSet<String>,
    ): Boolean {
        val imgFile = resolveImageFile(im, mediaFiles)
        if (imgFile == null || !imgFile.exists()) {
            val sampleNames = mediaFiles.take(5).joinToString(",") { it.name }
            warnings.add("image not found for uri='${im.uri}' id='${im.id}' (archive media: [$sampleNames])")
            return false
        }

        val bmp = decodeDownsampledBitmap(imgFile)
        if (bmp == null) {
            warnings.add("could not decode image ${imgFile.name}")
            return false
        }
        try {
            val l = im.left * PT
            val t = im.top * PT
            val r = im.right * PT
            val b = im.bottom * PT
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            val w = abs(r - l)
            val h = abs(b - t)
            if (w < 1f || h < 1f) return false
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(if (im.rotation.isFinite()) im.rotation else 0f)
            val dst = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)
            canvas.drawBitmap(bmp, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            return true
        } finally {
            bmp.recycle()
        }
    }

    private fun drawTextBox(canvas: Canvas, tb: DrawItem.TextBoxItem) {
        val l = tb.left * PT
        val t = tb.top * PT
        val boxW = safeRound(abs(tb.right - tb.left) * PT, 200).coerceAtLeast(20)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tb.color or (0xFF shl 24)
            textSize = (tb.textSize * PT).coerceIn(6f, 144f)
        }
        val layout = StaticLayout.Builder.obtain(tb.text, 0, tb.text.length, paint, boxW)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        canvas.save()
        canvas.translate(l, t)
        layout.draw(canvas)
        canvas.restore()
    }

    /** Draws a subtle, always-visible bottom-right watermark adapting to dark vs light page backgrounds. */
    private fun drawWatermark(canvas: Canvas, text: String, pwPt: Int, phPt: Int, bgColor: Int) {
        val luma = 0.299 * Color.red(bgColor) + 0.587 * Color.green(bgColor) + 0.114 * Color.blue(bgColor)
        val isDark = luma < 128.0
        val sizePt = (min(pwPt, phPt) * 0.018f).coerceIn(8.5f, 22f)
        val margin = sizePt * 1.15f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sizePt
            textAlign = Paint.Align.RIGHT
            color = if (isDark) Color.argb(145, 248, 250, 252) else Color.argb(125, 15, 23, 42)
        }
        canvas.drawText(text, pwPt - margin, phPt - margin, paint)
    }

    internal fun extractZipSafe(zipFile: File, destDir: File) {
        val canonDest = destDir.canonicalPath + File.separator
        ZipFile(zipFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val outFile = File(destDir, entry.name)
                if (!outFile.canonicalPath.startsWith(canonDest)) {
                    throw SecurityException("Zip slip detected: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(outFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            }
        }
    }
}
