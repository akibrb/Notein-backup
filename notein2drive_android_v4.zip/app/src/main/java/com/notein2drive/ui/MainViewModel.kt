package com.notein2drive.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.notein2drive.core.HierarchyDiscoverer
import com.notein2drive.drive.DriveMirror
import com.notein2drive.drive.GoogleAuthHelper
import com.notein2drive.sync.LocalExporter
import com.notein2drive.sync.ManifestStore
import com.notein2drive.sync.SyncEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.atomic.AtomicBoolean

data class LocalPdfItem(
    val relPath: String,
    val folderPath: String,
    val fileName: String,
    val file: File,
    val sizeBytes: Long,
    val syncedToDrive: Boolean,
)

data class UiState(
    val signedInEmail: String? = null,
    val appSha1: String = "",
    val sourceUri: Uri? = null,
    val sourceIsTree: Boolean = false,
    val sourceLabel: String = "No backup or folder selected",
    val localSaveUri: Uri? = null,
    val localSaveLabel: String = "App internal folder (tap Choose to pick device folder)",
    val rootFolderName: String = "Notein PDFs",
    val includeTrashed: Boolean = false,
    val forceReconvert: Boolean = false,
    val dryRun: Boolean = true,
    val pruneDeleted: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val statusLine: String = "Select a Notein backup.zip or folder to begin.",
    val treePreview: String = "",
    val localPdfs: List<LocalPdfItem> = emptyList(),
    val previewPdf: LocalPdfItem? = null,
    val logs: List<String> = emptyList(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("notein2drive_prefs", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var account: GoogleSignInAccount? = null
    private var activeJob: Job? = null
    private val cancelFlag = AtomicBoolean(false)

    init {
        cleanStaleTempCache(application)
        val savedUriStr = prefs.getString("local_save_uri", null)
        val savedLabel = prefs.getString("local_save_label", null)
        val sha1 = GoogleAuthHelper.getAppSha1(application)
        _state.update {
            it.copy(
                appSha1 = sha1,
                localSaveUri = savedUriStr?.let { s -> runCatching { Uri.parse(s) }.getOrNull() },
                localSaveLabel = savedLabel ?: it.localSaveLabel,
            )
        }
        refreshAccount()
        refreshLocalPdfs()
    }

    private fun cleanStaleTempCache(ctx: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            ctx.cacheDir.listFiles()?.forEach { f ->
                if (f.isDirectory && (
                        f.name.startsWith("notein_stage_") ||
                        f.name.startsWith("notein_zip_") ||
                        f.name.startsWith("notein_nested_") ||
                        f.name.startsWith("notein_conv_")
                    )
                ) {
                    f.deleteRecursively()
                }
            }
        }
    }

    private fun mirrorDir(): File {
        val ctx = getApplication<Application>()
        return File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Notein_PDFs")
    }

    fun cancelActiveTask() {
        cancelFlag.set(true)
        activeJob?.cancel()
        appendLog("! Cancelled by user (completed notes were saved).")
        _state.update { it.copy(busy = false, statusLine = "Cancelled. Already-converted notes were saved.") }
        refreshLocalPdfs()
    }

    fun refreshAccount() {
        val ctx = getApplication<Application>()
        account = GoogleAuthHelper.getLastSignedInAccount(ctx)
        _state.update { it.copy(signedInEmail = account?.email) }
    }

    fun refreshLocalPdfs() {
        viewModelScope.launch(Dispatchers.IO) {
            val root = mirrorDir()
            if (!root.exists()) {
                _state.update { it.copy(localPdfs = emptyList()) }
                return@launch
            }
            val manifest = ManifestStore.load(root)
            val syncedPaths = manifest.values
                .filter { !it.driveId.isNullOrBlank() }
                .map { it.pdfRel }
                .toSet()

            val items = root.walkTopDown()
                .filter { it.isFile && it.name.lowercase().endsWith(".pdf") }
                .map { f ->
                    val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
                    val slash = rel.lastIndexOf('/')
                    val folder = if (slash >= 0) rel.substring(0, slash) else "Root"
                    LocalPdfItem(
                        relPath = rel,
                        folderPath = folder,
                        fileName = f.name,
                        file = f,
                        sizeBytes = f.length(),
                        syncedToDrive = rel in syncedPaths,
                    )
                }
                .sortedBy { it.relPath.lowercase() }
                .toList()

            _state.update { it.copy(localPdfs = items) }
        }
    }

    fun onSignedIn(acct: GoogleSignInAccount?) {
        account = acct
        _state.update {
            it.copy(
                signedInEmail = acct?.email,
                statusLine = if (acct != null) "Connected as ${acct.email}" else "Google Sign-In cancelled",
            )
        }
    }

    fun onSignInFailed(t: Throwable) {
        val msg = GoogleAuthHelper.explainSignInError(t)
        appendLog("! $msg")
        _state.update { it.copy(statusLine = msg) }
    }

    fun setSource(uri: Uri, isTree: Boolean, label: String) {
        _state.update {
            it.copy(
                sourceUri = uri,
                sourceIsTree = isTree,
                sourceLabel = label,
                statusLine = "Ready: $label",
            )
        }
    }

    fun setLocalSaveFolder(uri: Uri, label: String) {
        prefs.edit()
            .putString("local_save_uri", uri.toString())
            .putString("local_save_label", label)
            .apply()
        _state.update {
            it.copy(
                localSaveUri = uri,
                localSaveLabel = label,
                statusLine = "Local save folder set to: $label",
            )
        }
    }

    fun clearLocalSaveFolder() {
        prefs.edit().remove("local_save_uri").remove("local_save_label").apply()
        _state.update {
            it.copy(
                localSaveUri = null,
                localSaveLabel = "App internal folder (tap Choose to pick device folder)",
                statusLine = "Reset local save location to app internal folder.",
            )
        }
    }

    fun openPreview(item: LocalPdfItem) = _state.update { it.copy(previewPdf = item) }
    fun closePreview() = _state.update { it.copy(previewPdf = null) }
    fun clearLogs() = _state.update { it.copy(logs = emptyList()) }

    fun updateRootFolderName(v: String) = _state.update { it.copy(rootFolderName = v) }
    fun updateIncludeTrashed(v: Boolean) = _state.update { it.copy(includeTrashed = v) }
    fun updateForceReconvert(v: Boolean) = _state.update { it.copy(forceReconvert = v) }
    fun updateDryRun(v: Boolean) = _state.update { it.copy(dryRun = v) }
    fun updatePruneDeleted(v: Boolean) = _state.update { it.copy(pruneDeleted = v) }

    private fun appendLog(line: String) {
        _state.update { it.copy(logs = (it.logs + line).takeLast(400)) }
    }

    fun scan() {
        val st = _state.value
        val uri = st.sourceUri ?: return
        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Reading & unpacking source...", logs = emptyList()) }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                inv = HierarchyDiscoverer.discoverFromUri(getApplication(), uri, st.sourceIsTree, st.includeTrashed)
                val tree = inv.renderTree().ifBlank { "(no notes found)" }
                inv.warnings.forEach { appendLog("warning: $it") }
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        treePreview = tree,
                        statusLine = "Found ${inv.entries.size} note(s) across ${inv.folders.size} Notein folder(s).",
                    )
                }
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Scan cancelled.") }
            } catch (e: Exception) {
                appendLog("! Scan error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Scan failed: ${e.message}") }
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun convertOrSync(uploadToDrive: Boolean) {
        val st = _state.value
        val uri = st.sourceUri ?: return
        if (uploadToDrive && !st.dryRun && account?.account == null) {
            _state.update { it.copy(statusLine = "Sign in with Google first to sync to Drive.") }
            return
        }

        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    busy = true,
                    progress = 0f,
                    statusLine = "Reading & unpacking source...",
                    logs = emptyList(),
                )
            }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                val ctx = getApplication<Application>()
                inv = HierarchyDiscoverer.discoverFromUri(ctx, uri, st.sourceIsTree, st.includeTrashed)
                _state.update { it.copy(treePreview = inv.renderTree()) }
                inv.warnings.forEach { appendLog("warning: $it") }

                val mirror = if (uploadToDrive && !st.dryRun) {
                    val token = GoogleAuthHelper.fetchAccessToken(ctx, account!!.account!!)
                    DriveMirror(accessToken = token, rootName = st.rootFolderName.ifBlank { "Notein PDFs" })
                } else null

                val outDir = mirrorDir()
                val summary = SyncEngine.run(
                    context = ctx,
                    inventory = inv,
                    outDir = outDir,
                    mirror = mirror,
                    force = st.forceReconvert,
                    dryRun = uploadToDrive && st.dryRun,
                    prune = st.pruneDeleted,
                    isCancelled = { cancelFlag.get() },
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                    log = { appendLog(it) },
                )

                var exportNote = ""
                val saveUri = st.localSaveUri
                if (saveUri != null && !(uploadToDrive && st.dryRun) && !cancelFlag.get()) {
                    val exp = LocalExporter.exportHierarchyToTree(
                        context = ctx,
                        mirrorRoot = outDir,
                        destTreeUri = saveUri,
                        isCancelled = { cancelFlag.get() },
                        onProgress = { done, total ->
                            val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                            _state.update { it.copy(progress = frac) }
                        },
                        onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                        log = { appendLog(it) },
                    )
                    exportNote = " • Saved locally: ${exp.exported} new, ${exp.skipped} unchanged"
                }

                val unchangedTotal = summary.skipped + summary.driveUnchanged
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Done: ${summary.converted} converted, ${summary.uploaded} uploaded, " +
                            "$unchangedTotal unchanged, ${summary.failed.size} failed.$exportNote",
                    )
                }
                refreshLocalPdfs()
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Cancelled. Completed notes were saved.") }
                refreshLocalPdfs()
            } catch (e: Exception) {
                appendLog("! Error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Failed: ${e.message}") }
                refreshLocalPdfs()
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun exportAllToLocalFolder(destTreeUri: Uri, label: String? = null) {
        if (label != null) {
            setLocalSaveFolder(destTreeUri, label)
        }
        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Saving PDFs hierarchically to device folder...") }
            try {
                val res = LocalExporter.exportHierarchyToTree(
                    context = getApplication(),
                    mirrorRoot = mirrorDir(),
                    destTreeUri = destTreeUri,
                    isCancelled = { cancelFlag.get() },
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                    log = { appendLog(it) },
                )
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Saved locally: ${res.exported} written, ${res.skipped} already up-to-date, ${res.failed} failed.",
                    )
                }
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Local save cancelled.") }
            } catch (e: Exception) {
                appendLog("! Export error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Local save failed: ${e.message}") }
            }
        }
    }
}
