package com.notein2drive.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CancellationException
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Converts a single Notein `.in` file into a native vector PDF using Android's `PdfDocument`.
 *
 * Memory & speed hardened for large multi-page notes on Android:
 *  - Downsamples embedded photos & source PDF pages (`RGB_565`, max 1200px) to prevent OOM freezes
 *  - Checks `isCancelled()` between pages so long notes cancel cleanly
 *  - Queries strokes per page in 100-row batches to avoid Android's 2 MB CursorWindow limit
 */
object NoteinConverter {

    private val CLOSED_SHAPES = setOf(2, 3, 4, 5, 6, 8)
    private val UUID_RE = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private const val PT = StrokeDecoder.PT

    data class ConvertStats(
        val pages: Int,
        val strokes: Int,
        val shapes: Int,
        val images: Int,
        val warnings: List<String>,
    )

    private sealed class DrawItem(val creationTime: Long, val orderRank: Int) {
        class ImageItem(
            creationTime: Long,
            val uri: String?,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
            val rotation: Float,
        ) : DrawItem(creationTime, 0)

        class StrokeItem(
            creationTime: Long,
            val stroke: StrokeDecoder.DecodedStroke,
        ) : DrawItem(creationTime, 1)

        class ShapeItem(
            creationTime: Long,
            val color: Int,
            val width: Float,
            val type: Int,
            val blendMode: Int,
            val pointsJson: String,
        ) : DrawItem(creationTime, 2)

        class TextBoxItem(
            creationTime: Long,
            val text: String,
            val textSize: Float,
            val color: Int,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
        ) : DrawItem(creationTime, 3)
    }

    fun readMeta(inFile: File): JSONObject {
        ZipFile(inFile).use { zip ->
            val entry = zip.getEntry("note_meta.json")
                ?: throw IllegalArgumentException("note_meta.json missing in ${inFile.name}")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
            return JSONObject(text)
        }
    }

    fun convert(
        context: Context,
        inFile: File,
        outPdf: File,
        widthModel: String = "fit",
        isCancelled: () -> Boolean = { false },
    ): ConvertStats {
        val tmpDir = File(context.cacheDir, "notein_conv_${System.nanoTime()}")
        tmpDir.mkdirs()
        val warnings = LinkedHashSet<String>()
        var pageCount = 0
        var strokeCount = 0
        var shapeCount = 0
        var imageCount = 0

        try {
            if (isCancelled()) throw CancellationException("Cancelled")
            extractZipSafe(inFile, tmpDir)

            val dbFile = tmpDir.walkTopDown().firstOrNull {
                it.isFile && it.name.startsWith("note_database_note_") && it.name.endsWith("_db")
            } ?: throw IllegalStateException("SQLite database not found in ${inFile.name}")

            val shmFile = File(dbFile.parentFile, dbFile.name + "-shm")
            if (shmFile.exists()) shmFile.delete()

            val db = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.NO_LOCALIZED_COLLATORS,
            )

            val embeddedPdfFile = tmpDir.walkTopDown().firstOrNull {
                it.isFile && it.name.lowercase().endsWith(".pdf")
            }
            var sourcePfd: ParcelFileDescriptor? = null
            var sourceRenderer: PdfRenderer? = null
            if (embeddedPdfFile != null) {
                try {
                    sourcePfd = ParcelFileDescriptor.open(embeddedPdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                    sourceRenderer = PdfRenderer(sourcePfd)
                } catch (e: Exception) {
                    warnings.add("could not open embedded source PDF: ${e.message}")
                }
            }

            val pdfDoc = PdfDocument()
            try {
                val pageIds = readPageList(db)
                if (countTable(db, "PdfInfoEntity") > 0 && sourceRenderer == null) {
                    warnings.add("note is attached to a source PDF (PdfInfoEntity): background PDF not found in archive")
                }

                var pageNumber = 1
                for ((pageIdx, pid) in pageIds.withIndex()) {
                    if (isCancelled()) throw CancellationException("Cancelled")
                    val pageRow = readPageEntity(db, pid)
                    if (pageRow == null) {
                        warnings.add("page $pid listed but missing")
                        continue
                    }

                    val pwPt = safeRound(pageRow.width * PT, 595).coerceIn(50, 14400)
                    val phPt = safeRound(pageRow.height * PT, 842).coerceIn(50, 14400)
                    val pageInfo = PdfDocument.PageInfo.Builder(pwPt, phPt, pageNumber++).create()
                    val page = pdfDoc.startPage(pageInfo)
                    val canvas = page.canvas

                    val bgPaint = Paint().apply {
                        style = Paint.Style.FILL
                        color = pageRow.bgColor or (0xFF shl 24)
                    }
                    canvas.drawRect(0f, 0f, pwPt.toFloat(), phPt.toFloat(), bgPaint)

                    if (sourceRenderer != null && pageIdx < sourceRenderer.pageCount) {
                        drawSourcePdfPage(canvas, sourceRenderer, pageIdx, pwPt, phPt, warnings)
                    }

                    val items = ArrayList<DrawItem>()
                    loadPageStrokes(db, pid, items, warnings)
                    loadPageShapes(db, pid, items, warnings)
                    loadPageImages(db, pid, items, warnings)
                    loadPageTextBoxes(db, pid, items, warnings)

                    items.sortWith(compareBy<DrawItem> { it.creationTime }.thenBy { it.orderRank })

                    canvas.save()
                    canvas.clipRect(0f, 0f, pwPt.toFloat(), phPt.toFloat())

                    for (item in items) {
                        try {
                            when (item) {
                                is DrawItem.StrokeItem -> {
                                    drawStroke(canvas, item.stroke, widthModel)
                                    strokeCount++
                                }
                                is DrawItem.ShapeItem -> {
                                    drawShape(canvas, item)
                                    shapeCount++
                                }
                                is DrawItem.ImageItem -> {
                                    drawImage(canvas, item, tmpDir, warnings)
                                    imageCount++
                                }
                                is DrawItem.TextBoxItem -> {
                                    drawTextBox(canvas, item)
                                }
                            }
                        } catch (e: Exception) {
                            warnings.add("skipped corrupt item on page ${pageIdx + 1}: ${e.message}")
                        }
                    }

                    canvas.restore()
                    pdfDoc.finishPage(page)
                    pageCount++
                }

                if (pageCount == 0) {
                    val info = PdfDocument.PageInfo.Builder(safeRound(1240 * PT, 595), safeRound(1754 * PT, 842), 1).create()
                    val blank = pdfDoc.startPage(info)
                    pdfDoc.finishPage(blank)
                }

                outPdf.parentFile?.mkdirs()
                FileOutputStream(outPdf).use { fos ->
                    pdfDoc.writeTo(fos)
                }
            } finally {
                pdfDoc.close()
                runCatching { sourceRenderer?.close() }
                runCatching { sourcePfd?.close() }
                db.close()
            }
        } finally {
            tmpDir.deleteRecursively()
        }

        return ConvertStats(
            pages = pageCount,
            strokes = strokeCount,
            shapes = shapeCount,
            images = imageCount,
            warnings = warnings.sorted(),
        )
    }

    private fun safeRound(v: Float, fallback: Int): Int =
        if (v.isFinite()) v.roundToInt() else fallback

    private data class PageSpec(val width: Float, val height: Float, val bgColor: Int)

    private fun readPageList(db: SQLiteDatabase): List<String> {
        return try {
            db.rawQuery("SELECT page_list FROM NoteContentEntity LIMIT 1", null).use { c ->
                if (!c.moveToFirst() || c.isNull(0)) return emptyList()
                val raw = c.getString(0)?.takeIf { it.isNotBlank() } ?: return emptyList()
                val arr = JSONArray(raw)
                List(arr.length()) { idx -> arr.getString(idx) }
            }
        } catch (_: Exception) {
            val out = ArrayList<String>()
            runCatching {
                db.rawQuery("SELECT id FROM PageEntity WHERE is_in_trash_bin = 0 ORDER BY creation_time ASC", null).use { c ->
                    while (c.moveToNext()) out.add(c.getString(0))
                }
            }
            out
        }
    }

    private fun countTable(db: SQLiteDatabase, table: String): Int {
        return try {
            db.rawQuery("SELECT COUNT(*) FROM $table", null).use { c ->
                if (c.moveToFirst()) c.getInt(0) else 0
            }
        } catch (_: Exception) {
            0
        }
    }

    private fun readPageEntity(db: SQLiteDatabase, pid: String): PageSpec? {
        db.rawQuery(
            "SELECT paper_spec, page_orientation, paper_theme FROM PageEntity WHERE id = ?",
            arrayOf(pid),
        ).use { c ->
            if (!c.moveToFirst()) return null
            var w = 1240f
            var h = 1754f
            if (!c.isNull(0)) {
                runCatching {
                    val spec = JSONObject(c.getString(0))
                    val sw = spec.optDouble("width", 1240.0).toFloat()
                    val sh = spec.optDouble("height", 1754.0).toFloat()
                    if (sw.isFinite() && sw > 10f) w = sw
                    if (sh.isFinite() && sh > 10f) h = sh
                }
            }
            val orient = if (c.isNull(1)) "" else (c.getString(1) ?: "")
            if (orient == "HORIZONTAL" && w < h) {
                val tmp = w; w = h; h = tmp
            }
            var bgColor = Color.WHITE
            if (!c.isNull(2)) {
                runCatching {
                    val theme = JSONObject(c.getString(2))
                    val base = theme.optJSONObject("baseTheme")
                    if (base != null && base.has("color")) {
                        bgColor = base.getInt("color")
                    }
                }
            }
            return PageSpec(w, h, bgColor)
        }
    }

    private fun loadPageStrokes(
        db: SQLiteDatabase,
        pid: String,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            val strokeIds = ArrayList<String>()
            db.rawQuery("SELECT id FROM StrokeEntity WHERE page_id = ?", arrayOf(pid)).use { c ->
                while (c.moveToNext()) strokeIds.add(c.getString(0))
            }
            val batchSize = 100
            var offset = 0
            while (offset < strokeIds.size) {
                val end = minOf(offset + batchSize, strokeIds.size)
                val sub = strokeIds.subList(offset, end)
                val placeholders = sub.joinToString(",") { "?" }
                db.rawQuery(
                    "SELECT creation_time, ink_stroke_blob FROM StrokeEntity WHERE id IN ($placeholders)",
                    sub.toTypedArray(),
                ).use { c ->
                    while (c.moveToNext()) {
                        val ctime = if (c.isNull(0)) 0L else c.getLong(0)
                        val blob = if (c.isNull(1)) null else c.getBlob(1)
                        if (blob != null && blob.isNotEmpty()) {
                            runCatching { StrokeDecoder.decode(blob) }
                                .onSuccess { out.add(DrawItem.StrokeItem(ctime, it)) }
                                .onFailure { warnings.add("skipped undecodable stroke: ${it.message}") }
                        } else {
                            warnings.add("old-format stroke (record_json) skipped: not implemented")
                        }
                    }
                }
                offset = end
            }
        } catch (e: Exception) {
            warnings.add("StrokeEntity read warning: ${e.message}")
        }
    }

    private fun loadPageShapes(
        db: SQLiteDatabase,
        pid: String,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT creation_time, color, width, type, blend_mode, points FROM ShapeEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    out.add(
                        DrawItem.ShapeItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            color = if (c.isNull(1)) Color.BLACK else c.getInt(1),
                            width = if (c.isNull(2)) 2f else c.getFloat(2),
                            type = if (c.isNull(3)) 0 else c.getInt(3),
                            blendMode = if (c.isNull(4)) 0 else c.getInt(4),
                            pointsJson = if (c.isNull(5)) "[]" else (c.getString(5) ?: "[]"),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("ShapeEntity read warning: ${e.message}")
        }
    }

    private fun loadPageImages(
        db: SQLiteDatabase,
        pid: String,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT creation_time, uri, left, top, right, bottom, rotation FROM ImageEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    if (c.isNull(2) || c.isNull(3) || c.isNull(4) || c.isNull(5)) continue
                    out.add(
                        DrawItem.ImageItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            uri = if (c.isNull(1)) null else c.getString(1),
                            left = c.getFloat(2),
                            top = c.getFloat(3),
                            right = c.getFloat(4),
                            bottom = c.getFloat(5),
                            rotation = if (c.isNull(6)) 0f else c.getFloat(6),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("ImageEntity read warning: ${e.message}")
        }
    }

    private fun loadPageTextBoxes(
        db: SQLiteDatabase,
        pid: String,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT creation_time, text, text_size, default_text_color, left, top, right, bottom FROM TextBoxEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    val txt = if (c.isNull(1)) "" else (c.getString(1) ?: "")
                    if (txt.isBlank() || c.isNull(4) || c.isNull(5) || c.isNull(6) || c.isNull(7)) continue
                    out.add(
                        DrawItem.TextBoxItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            text = txt,
                            textSize = if (c.isNull(2)) 24f else c.getFloat(2),
                            color = if (c.isNull(3)) Color.BLACK else c.getInt(3),
                            left = c.getFloat(4),
                            top = c.getFloat(5),
                            right = c.getFloat(6),
                            bottom = c.getFloat(7),
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun drawSourcePdfPage(
        canvas: Canvas,
        renderer: PdfRenderer,
        pageIndex: Int,
        pwPt: Int,
        phPt: Int,
        warnings: MutableSet<String>,
    ) {
        try {
            renderer.openPage(pageIndex).use { srcPage ->
                // Memory-safe cap (max 1200px on longest side) so multi-page PDFs never OOM-freeze
                val maxDim = 1200f
                val scale = minOf(1.25f, maxDim / max(pwPt, phPt).toFloat())
                val bmpW = (pwPt * scale).roundToInt().coerceIn(100, 1200)
                val bmpH = (phPt * scale).roundToInt().coerceIn(100, 1600)
                val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                try {
                    bmp.eraseColor(Color.WHITE)
                    srcPage.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    canvas.drawBitmap(bmp, null, RectF(0f, 0f, pwPt.toFloat(), phPt.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
                } finally {
                    bmp.recycle()
                }
            }
        } catch (e: Exception) {
            warnings.add("source PDF page ${pageIndex + 1} render warning: ${e.message}")
        }
    }

    private fun drawStroke(canvas: Canvas, decoded: StrokeDecoder.DecodedStroke, widthModel: String) {
        val curve = StrokeDecoder.toCurve(decoded, widthModel)
        if (curve.xs.isEmpty()) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = curve.argbColor
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        if (curve.isDot) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(
                curve.xs[0] * PT,
                curve.ys[0] * PT,
                (curve.widths[0] * PT / 2f).coerceAtLeast(0.25f),
                paint,
            )
            return
        }

        paint.style = Paint.Style.STROKE
        val n = curve.xs.size
        // Quantize width to 0.25 units to keep drawPath counts fast on huge notes
        val q = IntArray(n) { safeRound(curve.widths[it] / 0.25f, 6) }
        var i = 0
        val path = Path()
        while (i < n - 1) {
            var j = i
            while (j < n - 1 && abs(q[j] - q[i]) <= 1) {
                j++
            }
            if (j == i) j = i + 1
            var sumW = 0f
            for (k in i..j) sumW += curve.widths[k]
            paint.strokeWidth = ((sumW / (j - i + 1)) * PT).coerceIn(0.15f, 300f)

            path.reset()
            path.moveTo(curve.xs[i] * PT, curve.ys[i] * PT)
            for (k in (i + 1)..j) {
                path.lineTo(curve.xs[k] * PT, curve.ys[k] * PT)
            }
            canvas.drawPath(path, paint)
            i = j
        }
    }

    private fun drawShape(canvas: Canvas, sh: DrawItem.ShapeItem) {
        val pts = JSONArray(sh.pointsJson)
        if (pts.length() == 0) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = sh.color or (0xFF shl 24)
            strokeWidth = (sh.width * PT).coerceIn(0.2f, 300f)
            strokeCap = if (sh.blendMode == 13) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        val path = Path()
        val p0 = pts.getJSONObject(0)
        path.moveTo(p0.optDouble("x", 0.0).toFloat() * PT, p0.optDouble("y", 0.0).toFloat() * PT)
        for (i in 1 until pts.length()) {
            val pt = pts.getJSONObject(i)
            path.lineTo(pt.optDouble("x", 0.0).toFloat() * PT, pt.optDouble("y", 0.0).toFloat() * PT)
        }
        if (sh.type in CLOSED_SHAPES) {
            path.close()
        }
        canvas.drawPath(path, paint)
    }

    private fun decodeDownsampledBitmap(file: File, maxDim: Int = 1400): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) return null
        var sample = 1
        while (w / sample > maxDim || h / sample > maxDim) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    private fun drawImage(canvas: Canvas, im: DrawItem.ImageItem, tmpDir: File, warnings: MutableSet<String>) {
        val uuid = im.uri?.let { UUID_RE.find(it)?.value }
        val imgFile = if (uuid != null) {
            tmpDir.walkTopDown().firstOrNull { it.isFile && it.name.startsWith("note_image_$uuid") }
        } else null

        if (imgFile == null || !imgFile.exists()) {
            warnings.add("image file not found for uri='${im.uri}'")
            return
        }

        val bmp = decodeDownsampledBitmap(imgFile)
        if (bmp == null) {
            warnings.add("could not decode image ${imgFile.name}")
            return
        }
        try {
            val l = im.left * PT
            val t = im.top * PT
            val r = im.right * PT
            val b = im.bottom * PT
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            val w = abs(r - l)
            val h = abs(b - t)
            if (w < 1f || h < 1f) return
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(if (im.rotation.isFinite()) im.rotation else 0f)
            val dst = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)
            canvas.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
        } finally {
            bmp.recycle()
        }
    }

    private fun drawTextBox(canvas: Canvas, tb: DrawItem.TextBoxItem) {
        val l = tb.left * PT
        val t = tb.top * PT
        val boxW = safeRound(abs(tb.right - tb.left) * PT, 200).coerceAtLeast(20)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tb.color or (0xFF shl 24)
            textSize = (tb.textSize * PT).coerceIn(6f, 144f)
        }
        val layout = StaticLayout.Builder.obtain(tb.text, 0, tb.text.length, paint, boxW)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        canvas.save()
        canvas.translate(l, t)
        layout.draw(canvas)
        canvas.restore()
    }

    internal fun extractZipSafe(zipFile: File, destDir: File) {
        val canonDest = destDir.canonicalPath + File.separator
        ZipFile(zipFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val outFile = File(destDir, entry.name)
                if (!outFile.canonicalPath.startsWith(canonDest)) {
                    throw SecurityException("Zip slip detected: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(outFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            }
        }
    }
}
