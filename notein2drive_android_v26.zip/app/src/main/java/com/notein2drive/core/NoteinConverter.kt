package com.notein2drive.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import android.text.Html
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CancellationException
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Converts a single Notein `.in` file into a native vector PDF using Android's `PdfDocument`.
 *
 * Features:
 *  - Replays SQLite `-wal` cleanly (deletes stale `-shm`)
 *  - Respects `PageLayerEntity.visible` (skips explicitly hidden layers without dropping merged/orphaned layers)
 *    and skips `tape_like = 1` mask boxes
 *  - Renders exact smooth circles (`ShapeEntity.type == 6`), ellipses/ovals (`type == 8`), 5-point closed stars (`type == 5`, 5 pts),
 *    smooth open curves/arcs (`type == 0`, `type == 5`) with consecutive duplicate-point merging,
 *    dotted/dashed lines (`type == 19`), single/double arrows (`type == 21, 22`),
 *    3D boxes (`type == 11`), 3D cylinders (`type == 14`), and standard polygons/polylines
 *  - Uses translucent Multiply blending for highlighters so underlying text stays crisp and readable
 *  - Preserves exact `page_list` order, supports multiple embedded PDFs in merged notes, and fits
 *    infinite-canvas notes onto a single zoomable vector PDF page
 */
object NoteinConverter {

    private val CLOSED_POLYGONS = setOf(2, 3, 4)
    private val KNOWN_SHAPE_TYPES = setOf(0, 2, 3, 4, 5, 6, 7, 8, 11, 14, 19, 21, 22)
    private val UUID_RE = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private const val PT = StrokeDecoder.PT

    data class ConvertStats(
        val pages: Int,
        val strokes: Int,
        val shapes: Int,
        val images: Int,
        val warnings: List<String>,
    )

    private data class NoteHeader(
        val pageIds: List<String>,
        val unboundedNote: Boolean,
    )

    private class EmbeddedPdf(
        val file: File,
        val pfd: ParcelFileDescriptor,
        val renderer: PdfRenderer,
        var cursor: Int = 0,
    )

    private data class PageSpec(
        val width: Float,
        val height: Float,
        val hasExplicitSize: Boolean,
        val bgColor: Int,
        val padLeft: Float,
        val padTop: Float,
        val padRight: Float,
        val padBottom: Float,
        val padBgColor: Int,
        val isPdfPage: Boolean,
        val explicitPdfPageIndex: Int?,
        val pdfRef: String?,
        val rotationSteps: Int,
        val unbounded: Boolean,
    )

    private sealed class DrawItem(val creationTime: Long, val orderRank: Int) {
        class ImageItem(
            creationTime: Long,
            val id: String,
            val uri: String?,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
            val rotation: Float,
            val spansAdjacentPage: Boolean = false,
        ) : DrawItem(creationTime, 0)

        class StrokeItem(
            creationTime: Long,
            val stroke: StrokeDecoder.DecodedStroke,
        ) : DrawItem(creationTime, 1)

        class RecordStrokeItem(
            creationTime: Long,
            val color: Int,
            val width: Float,
            val type: Int,
            val xs: FloatArray,
            val ys: FloatArray,
            val ps: FloatArray,
        ) : DrawItem(creationTime, 1)

        class ShapeItem(
            creationTime: Long,
            val color: Int,
            val width: Float,
            val type: Int,
            val blendMode: Int,
            val pointsJson: String,
        ) : DrawItem(creationTime, 2)

        class TextBoxItem(
            creationTime: Long,
            val text: String,
            val textSize: Float,
            val color: Int,
            val bgColor: Int,
            val lineHeight: Float,
            val left: Float,
            val top: Float,
            val right: Float,
            val bottom: Float,
        ) : DrawItem(creationTime, 3)
    }

    fun readMeta(inFile: File): JSONObject {
        ZipFile(inFile).use { zip ->
            val entry = zip.getEntry("note_meta.json")
                ?: throw IllegalArgumentException("note_meta.json missing in ${inFile.name}")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
            return JSONObject(text)
        }
    }

    fun convert(
        context: Context,
        inFile: File,
        outPdf: File,
        widthModel: String = "fit",
        watermarkText: String? = null,
        isCancelled: () -> Boolean = { false },
    ): ConvertStats {
        val tmpDir = File(context.cacheDir, "notein_conv_${System.nanoTime()}")
        tmpDir.mkdirs()
        val warnings = LinkedHashSet<String>()
        var pageCount = 0
        var strokeCount = 0
        var shapeCount = 0
        var imageCount = 0

        try {
            if (isCancelled()) throw CancellationException("Cancelled")
            extractZipSafe(inFile, tmpDir)

            val allExtractedFiles = tmpDir.walkTopDown().filter { it.isFile }.toList()

            val dbFile = allExtractedFiles.firstOrNull {
                it.name.startsWith("note_database_note_") && it.name.endsWith("_db")
            } ?: throw IllegalStateException("SQLite database not found in ${inFile.name}")

            val shmFile = File(dbFile.parentFile, dbFile.name + "-shm")
            if (shmFile.exists()) shmFile.delete()

            val db = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.NO_LOCALIZED_COLLATORS,
            )

            val embeddedPdfFiles = allExtractedFiles
                .filter { it.name.lowercase().endsWith(".pdf") }
                .sortedBy { it.name.lowercase() }
            val embeddedPdfs = ArrayList<EmbeddedPdf>()
            for (pf in embeddedPdfFiles) {
                try {
                    val pfd = ParcelFileDescriptor.open(pf, ParcelFileDescriptor.MODE_READ_ONLY)
                    val renderer = PdfRenderer(pfd)
                    embeddedPdfs.add(EmbeddedPdf(pf, pfd, renderer))
                } catch (e: Exception) {
                    warnings.add("could not open embedded source PDF ${pf.name}: ${e.message}")
                }
            }
            val pdfByInfoId = buildPdfInfoMap(db, embeddedPdfs)

            val mediaFiles = allExtractedFiles.filter { f ->
                val n = f.name.lowercase()
                !n.endsWith("_db") && !n.endsWith("_db-wal") && !n.endsWith("_db-shm") &&
                    !n.endsWith(".json") && !n.endsWith(".pdf")
            }

            val hiddenLayers = readHiddenLayerIds(db)

            val pdfDoc = PdfDocument()
            try {
                val header = readNoteHeader(db)
                val pageIds = header.pageIds
                if (countTable(db, "PdfInfoEntity") > 0 && embeddedPdfs.isEmpty()) {
                    warnings.add("note is attached to a source PDF (PdfInfoEntity): background PDF not found in archive")
                }

                val pageSpecs = pageIds.map { pid ->
                    readPageEntity(db, pid, hasEmbeddedPdf = embeddedPdfs.isNotEmpty())
                }
                val pageImages = Array(pageIds.size) { ArrayList<DrawItem.ImageItem>() }
                for (i in pageIds.indices) {
                    if (pageSpecs[i] != null) {
                        val tmpImgs = ArrayList<DrawItem>()
                        loadPageImages(db, pageIds[i], hiddenLayers, tmpImgs, warnings)
                        for (it in tmpImgs) {
                            if (it is DrawItem.ImageItem) pageImages[i].add(it)
                        }
                    }
                }

                // Project images that cross page boundaries (top < 0 or bottom > pageHeight) onto adjacent pages
                val projectedImages = Array(pageIds.size) { ArrayList<DrawItem.ImageItem>() }
                for (i in pageIds.indices) {
                    val spec = pageSpecs[i] ?: continue
                    val isInf = (header.unboundedNote || spec.unbounded) && !spec.isPdfPage
                    if (isInf) continue
                    val curH = spec.height
                    for (idx in pageImages[i].indices) {
                        val im = pageImages[i][idx]
                        var projected = false

                        // Image overflows upward into previous page(s)
                        if (im.top < -1f && i > 0) {
                            var targetIdx = i - 1
                            var shiftY = 0f
                            while (targetIdx >= 0) {
                                val prevSpec = pageSpecs[targetIdx]
                                if (prevSpec == null) { targetIdx--; continue }
                                shiftY += prevSpec.height
                                val pTop = im.top + shiftY
                                val pBot = im.bottom + shiftY
                                if (pBot > 0f && pTop < prevSpec.height) {
                                    projectedImages[targetIdx].add(
                                        DrawItem.ImageItem(
                                            creationTime = im.creationTime,
                                            id = im.id,
                                            uri = im.uri,
                                            left = im.left,
                                            top = pTop,
                                            right = im.right,
                                            bottom = pBot,
                                            rotation = im.rotation,
                                            spansAdjacentPage = true,
                                        )
                                    )
                                    projected = true
                                }
                                if (pTop >= 0f) break
                                targetIdx--
                            }
                        }

                        // Image overflows downward into next page(s)
                        if (im.bottom > curH + 1f && i + 1 < pageIds.size) {
                            var targetIdx = i + 1
                            var shiftY = curH
                            while (targetIdx < pageIds.size) {
                                val nextSpec = pageSpecs[targetIdx]
                                if (nextSpec == null) { targetIdx++; continue }
                                val nTop = im.top - shiftY
                                val nBot = im.bottom - shiftY
                                if (nBot > 0f && nTop < nextSpec.height) {
                                    projectedImages[targetIdx].add(
                                        DrawItem.ImageItem(
                                            creationTime = im.creationTime,
                                            id = im.id,
                                            uri = im.uri,
                                            left = im.left,
                                            top = nTop,
                                            right = im.right,
                                            bottom = nBot,
                                            rotation = im.rotation,
                                            spansAdjacentPage = true,
                                        )
                                    )
                                    projected = true
                                }
                                shiftY += nextSpec.height
                                if (nBot <= nextSpec.height) break
                                targetIdx++
                            }
                        }

                        if (projected) {
                            pageImages[i][idx] = DrawItem.ImageItem(
                                creationTime = im.creationTime,
                                id = im.id,
                                uri = im.uri,
                                left = im.left,
                                top = im.top,
                                right = im.right,
                                bottom = im.bottom,
                                rotation = im.rotation,
                                spansAdjacentPage = true,
                            )
                        }
                    }
                }

                var pageNumber = 1

                for ((pageIdx, pid) in pageIds.withIndex()) {
                    if (isCancelled()) throw CancellationException("Cancelled")
                    val pageRow = pageSpecs[pageIdx]
                    if (pageRow == null) {
                        warnings.add("page $pid listed but missing")
                        continue
                    }

                    val items = ArrayList<DrawItem>()
                    loadPageStrokes(db, pid, hiddenLayers, items, warnings)
                    loadPageShapes(db, pid, hiddenLayers, items, warnings)
                    items.addAll(pageImages[pageIdx])
                    items.addAll(projectedImages[pageIdx])
                    loadPageTextBoxes(db, pid, hiddenLayers, items, warnings)
                    // Always render images beneath strokes, shapes, and text boxes (preserving creationTime within each group)
                    items.sortWith(compareBy<DrawItem> { if (it is DrawItem.ImageItem) 0 else 1 }.thenBy { it.creationTime }.thenBy { it.orderRank })

                    val isInfiniteCanvas = (header.unboundedNote || pageRow.unbounded) && !pageRow.isPdfPage

                    var pwPt: Int
                    var basePhPt: Int
                    var phPt: Int
                    var txPt = 0f
                    var tyPt = 0f
                    var fitScale = 1f
                    var extraTopPt = 0
                    var targetPdf: EmbeddedPdf? = null
                    var targetPdfPageIdx: Int? = null
                    val bbox = computeContentBounds(items, excludeCrossPageImages = !isInfiniteCanvas)

                    if (isInfiniteCanvas) {
                        if (bbox != null) {
                            val pad = 60f
                            val spanW = max(200f, (bbox[2] - bbox[0]) + 2f * pad)
                            val spanH = max(200f, (bbox[3] - bbox[1]) + 2f * pad)
                            val rawPtW = spanW * PT
                            val rawPtH = spanH * PT
                            val maxPdfPt = 14000f
                            fitScale = if (max(rawPtW, rawPtH) > maxPdfPt) maxPdfPt / max(rawPtW, rawPtH) else 1f
                            pwPt = safeRound(rawPtW * fitScale, 595).coerceIn(100, 14400)
                            basePhPt = safeRound(rawPtH * fitScale, 842).coerceIn(100, 14400)
                            phPt = basePhPt
                            txPt = (-bbox[0] + pad) * PT
                            tyPt = (-bbox[1] + pad) * PT
                        } else {
                            pwPt = safeRound(pageRow.width * PT, 595).coerceIn(50, 14400)
                            basePhPt = safeRound(pageRow.height * PT, 842).coerceIn(50, 14400)
                            phPt = basePhPt
                        }
                    } else {
                        if (embeddedPdfs.isNotEmpty() && pageRow.isPdfPage) {
                            targetPdf = resolveEmbeddedPdf(pageRow.pdfRef, pdfByInfoId, embeddedPdfs)
                            if (targetPdf != null) {
                                val resolved = pageRow.explicitPdfPageIndex ?: targetPdf.cursor
                                targetPdf.cursor = max(targetPdf.cursor + 1, resolved + 1)
                                targetPdfPageIdx = resolved.takeIf { it in 0 until targetPdf.renderer.pageCount }
                            }
                        }

                        pwPt = safeRound(pageRow.width * PT, 595).coerceIn(50, 14400)
                        basePhPt = safeRound(pageRow.height * PT, 842).coerceIn(50, 14400)
                        if (!pageRow.hasExplicitSize && targetPdf != null && targetPdfPageIdx != null) {
                            runCatching {
                                targetPdf.renderer.openPage(targetPdfPageIdx).use { sp ->
                                    pwPt = sp.width.coerceIn(50, 14400)
                                    basePhPt = sp.height.coerceIn(50, 14400)
                                }
                            }
                        }

                        // Auto-expand top & bottom margins when writing/diagrams spill across the joint between two pages
                        val pageHeightUnits = basePhPt / PT
                        val contentTopInPage = if (bbox != null) bbox[1] + pageRow.padTop else 0f
                        val contentBottomInPage = if (bbox != null) bbox[3] + pageRow.padTop else 0f
                        val spillTopUnits = if (bbox != null && contentTopInPage < 0f) (-contentTopInPage + 28f).coerceAtMost(450f) else 0f
                        val spillBottomUnits = if (bbox != null && contentBottomInPage > pageHeightUnits) (contentBottomInPage - pageHeightUnits + 28f).coerceAtMost(450f) else 0f
                        extraTopPt = safeRound(spillTopUnits * PT, 0)
                        val extraBottomPt = safeRound(spillBottomUnits * PT, 0)
                        phPt = (basePhPt + extraTopPt + extraBottomPt).coerceIn(50, 14400)
                        txPt = pageRow.padLeft * PT
                        tyPt = extraTopPt.toFloat() + pageRow.padTop * PT
                    }

                    val pageInfo = PdfDocument.PageInfo.Builder(pwPt, phPt, pageNumber++).create()
                    val page = pdfDoc.startPage(pageInfo)
                    val canvas = page.canvas

                    val hasPadding = pageRow.padLeft > 0f || pageRow.padTop > 0f || pageRow.padRight > 0f || pageRow.padBottom > 0f
                    val bgPaint = Paint().apply {
                        style = Paint.Style.FILL
                        color = (if (hasPadding) pageRow.padBgColor else pageRow.bgColor) or (0xFF shl 24)
                    }
                    canvas.drawRect(0f, 0f, pwPt.toFloat(), phPt.toFloat(), bgPaint)

                    if (targetPdf != null && targetPdfPageIdx != null) {
                        val pdfL = (pageRow.padLeft * PT).coerceIn(0f, pwPt.toFloat())
                        val pdfT = extraTopPt + (pageRow.padTop * PT).coerceIn(0f, basePhPt.toFloat())
                        val pdfR = (pwPt - pageRow.padRight * PT).coerceIn(pdfL + 10f, pwPt.toFloat())
                        val pdfB = (extraTopPt + basePhPt - pageRow.padBottom * PT).coerceIn(pdfT + 10f, (extraTopPt + basePhPt).toFloat())
                        drawSourcePdfPage(
                            canvas = canvas,
                            renderer = targetPdf.renderer,
                            pageIndex = targetPdfPageIdx,
                            dstRect = RectF(pdfL, pdfT, pdfR, pdfB),
                            warnings = warnings,
                        )
                    }

                    canvas.save()
                    canvas.clipRect(0f, 0f, pwPt.toFloat(), phPt.toFloat())
                    if (isInfiniteCanvas) {
                        if (fitScale != 1f) canvas.scale(fitScale, fitScale)
                        canvas.translate(txPt, tyPt)
                    } else if (txPt != 0f || tyPt != 0f) {
                        canvas.translate(txPt, tyPt)
                    }

                    val effPageBg = if (targetPdf != null && targetPdfPageIdx != null) Color.WHITE else pageRow.bgColor
                    val isDarkPage = (0.299 * Color.red(effPageBg) + 0.587 * Color.green(effPageBg) + 0.114 * Color.blue(effPageBg)) < 80.0

                    for (item in items) {
                        try {
                            when (item) {
                                is DrawItem.StrokeItem -> {
                                    drawStroke(canvas, item.stroke, widthModel, isDarkPage)
                                    strokeCount++
                                }
                                is DrawItem.RecordStrokeItem -> {
                                    drawRecordStroke(canvas, item, isDarkPage)
                                    strokeCount++
                                }
                                is DrawItem.ShapeItem -> {
                                    drawShape(canvas, item, isDarkPage, warnings)
                                    shapeCount++
                                }
                                is DrawItem.ImageItem -> {
                                    if (drawImage(canvas, item, mediaFiles, warnings)) {
                                        imageCount++
                                    }
                                }
                                is DrawItem.TextBoxItem -> {
                                    drawTextBox(canvas, item)
                                }
                            }
                        } catch (e: Exception) {
                            warnings.add("skipped corrupt item on page ${pageIdx + 1}: ${e.message}")
                        }
                    }

                    canvas.restore()
                    if (!watermarkText.isNullOrBlank()) {
                        val effBg = if (targetPdf != null && targetPdfPageIdx != null) Color.WHITE else pageRow.bgColor
                        drawWatermark(canvas, watermarkText.trim(), pwPt, phPt, effBg)
                    }
                    pdfDoc.finishPage(page)
                    pageCount++
                }

                if (pageCount == 0) {
                    val info = PdfDocument.PageInfo.Builder(safeRound(1240 * PT, 595), safeRound(1754 * PT, 842), 1).create()
                    val blank = pdfDoc.startPage(info)
                    pdfDoc.finishPage(blank)
                }

                outPdf.parentFile?.mkdirs()
                FileOutputStream(outPdf).use { fos ->
                    pdfDoc.writeTo(fos)
                }
            } finally {
                pdfDoc.close()
                for (ep in embeddedPdfs) {
                    runCatching { ep.renderer.close() }
                    runCatching { ep.pfd.close() }
                }
                db.close()
            }
        } finally {
            tmpDir.deleteRecursively()
        }

        return ConvertStats(
            pages = pageCount,
            strokes = strokeCount,
            shapes = shapeCount,
            images = imageCount,
            warnings = warnings.sorted(),
        )
    }

    private fun buildPdfInfoMap(db: SQLiteDatabase, embeddedPdfs: List<EmbeddedPdf>): Map<String, EmbeddedPdf> {
        val map = HashMap<String, EmbeddedPdf>()
        if (embeddedPdfs.isEmpty()) return map
        runCatching {
            db.rawQuery("SELECT * FROM PdfInfoEntity", null).use { c ->
                val colCount = c.columnCount
                while (c.moveToNext()) {
                    val rowStrings = ArrayList<String>()
                    var idVal: String? = null
                    for (i in 0 until colCount) {
                        if (c.isNull(i)) continue
                        val colName = c.getColumnName(i).lowercase()
                        val str = runCatching { c.getString(i) }.getOrNull() ?: continue
                        if (str.isBlank()) continue
                        if (colName == "id" || colName == "pdf_id") idVal = str
                        rowStrings.add(str)
                    }
                    val matched = matchPdfByTokens(rowStrings, embeddedPdfs) ?: continue
                    if (!idVal.isNullOrBlank()) {
                        map[idVal.lowercase()] = matched
                    }
                    for (s in rowStrings) {
                        UUID_RE.find(s)?.value?.let { map[it.lowercase()] = matched }
                    }
                }
            }
        }
        return map
    }

    private fun matchPdfByTokens(tokens: List<String>, embeddedPdfs: List<EmbeddedPdf>): EmbeddedPdf? {
        for (tok in tokens) {
            val base = tok.substringAfterLast('/').substringAfterLast('\\').substringBefore('?')
            if (base.isNotBlank()) {
                embeddedPdfs.firstOrNull { it.file.name.equals(base, ignoreCase = true) }?.let { return it }
            }
            val uuid = UUID_RE.find(tok)?.value
            if (!uuid.isNullOrBlank()) {
                embeddedPdfs.firstOrNull { it.file.name.contains(uuid, ignoreCase = true) }?.let { return it }
            }
            if (base.length >= 6) {
                val baseNoExt = base.substringBeforeLast('.')
                if (baseNoExt.length >= 6) {
                    embeddedPdfs.firstOrNull { it.file.name.contains(baseNoExt, ignoreCase = true) }?.let { return it }
                }
            }
        }
        return null
    }

    private fun resolveEmbeddedPdf(
        pdfRef: String?,
        pdfByInfoId: Map<String, EmbeddedPdf>,
        embeddedPdfs: List<EmbeddedPdf>,
    ): EmbeddedPdf? {
        if (embeddedPdfs.isEmpty()) return null
        if (embeddedPdfs.size == 1) return embeddedPdfs[0]
        if (!pdfRef.isNullOrBlank()) {
            pdfByInfoId[pdfRef.lowercase()]?.let { return it }
            UUID_RE.find(pdfRef)?.value?.lowercase()?.let { uuid ->
                pdfByInfoId[uuid]?.let { return it }
            }
            matchPdfByTokens(listOf(pdfRef), embeddedPdfs)?.let { return it }
        }
        return embeddedPdfs[0]
    }

    private fun readHiddenLayerIds(db: SQLiteDatabase): Set<String> {
        val hidden = HashSet<String>()
        runCatching {
            db.rawQuery("SELECT id, visible FROM PageLayerEntity", null).use { c ->
                while (c.moveToNext()) {
                    if (!c.isNull(0) && c.getInt(1) == 0) {
                        hidden.add(c.getString(0))
                    }
                }
            }
        }
        return hidden
    }

    /** Skips detached/deleted items (`layer_id == "unspecified"`) and items on explicitly hidden layers. */
    private fun isLayerVisible(layerId: String, hiddenLayers: Set<String>): Boolean {
        if (layerId.equals("unspecified", ignoreCase = true)) return false
        if (layerId.isNotBlank() && layerId in hiddenLayers) return false
        return true
    }

    private fun computeContentBounds(items: List<DrawItem>, excludeCrossPageImages: Boolean = false): FloatArray? {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        fun include(x: Float, y: Float, pad: Float = 0f) {
            if (!x.isFinite() || !y.isFinite()) return
            minX = min(minX, x - pad)
            minY = min(minY, y - pad)
            maxX = max(maxX, x + pad)
            maxY = max(maxY, y + pad)
        }

        for (item in items) {
            when (item) {
                is DrawItem.StrokeItem -> {
                    val s = item.stroke
                    val n = s.xy.size / 2
                    if (n == 0) continue
                    val m = StrokeDecoder.mul3x3(s.m13, s.m12)
                    val pad = (s.brush * 1.5f).coerceIn(2f, 80f)
                    for (i in 0 until n) {
                        val x = s.xy[i * 2]
                        val y = s.xy[i * 2 + 1]
                        val tx = m[0] * x + m[1] * y + m[2]
                        val ty = m[3] * x + m[4] * y + m[5]
                        include(tx, ty, pad)
                    }
                }
                is DrawItem.RecordStrokeItem -> {
                    val pad = (item.width * 1.5f).coerceIn(2f, 80f)
                    for (i in item.xs.indices) {
                        include(item.xs[i], item.ys[i], pad)
                    }
                }
                is DrawItem.ShapeItem -> {
                    runCatching {
                        val pts = JSONArray(item.pointsJson)
                        val pad = item.width.coerceIn(2f, 80f)
                        for (i in 0 until pts.length()) {
                            val pt = pts.getJSONObject(i)
                            include(pt.optDouble("x", 0.0).toFloat(), pt.optDouble("y", 0.0).toFloat(), pad)
                        }
                    }
                }
                is DrawItem.ImageItem -> {
                    if (!excludeCrossPageImages || !item.spansAdjacentPage) {
                        include(min(item.left, item.right), min(item.top, item.bottom))
                        include(max(item.left, item.right), max(item.top, item.bottom))
                    }
                }
                is DrawItem.TextBoxItem -> {
                    include(min(item.left, item.right), min(item.top, item.bottom))
                    include(max(item.left, item.right), max(item.top, item.bottom))
                }
            }
        }

        if (!minX.isFinite() || !minY.isFinite() || !maxX.isFinite() || !maxY.isFinite()) {
            return null
        }
        return floatArrayOf(minX, minY, maxX, maxY)
    }

    private fun safeRound(v: Float, fallback: Int): Int =
        if (v.isFinite()) v.roundToInt() else fallback

    private fun tableColumns(db: SQLiteDatabase, table: String): Set<String> {
        val cols = HashSet<String>()
        runCatching {
            db.rawQuery("PRAGMA table_info($table)", null).use { c ->
                val nameIdx = c.getColumnIndex("name")
                while (c.moveToNext()) {
                    if (nameIdx >= 0 && !c.isNull(nameIdx)) {
                        cols.add(c.getString(nameIdx).lowercase())
                    }
                }
            }
        }
        return cols
    }

    private fun readNoteHeader(db: SQLiteDatabase): NoteHeader {
        val contentCols = tableColumns(db, "NoteContentEntity")
        var pageIds: List<String> = emptyList()
        var unbounded = false

        if ("page_list" in contentCols) {
            val query = if ("unbounded_note" in contentCols) {
                "SELECT page_list, unbounded_note FROM NoteContentEntity LIMIT 1"
            } else {
                "SELECT page_list FROM NoteContentEntity LIMIT 1"
            }
            runCatching {
                db.rawQuery(query, null).use { c ->
                    if (c.moveToFirst()) {
                        val raw = if (c.isNull(0)) null else c.getString(0)
                        if ("unbounded_note" in contentCols && !c.isNull(1)) {
                            unbounded = c.getInt(1) != 0
                        }
                        if (!raw.isNullOrBlank()) {
                            val arr = JSONArray(raw)
                            val ordered = LinkedHashSet<String>()
                            for (idx in 0 until arr.length()) {
                                val id = arr.optString(idx)
                                if (id.isNotBlank()) ordered.add(id)
                            }
                            pageIds = ordered.toList()
                        }
                    }
                }
            }
        }

        // Filter out any trashed pages while preserving exact page_list order
        val pageCols = tableColumns(db, "PageEntity")
        if (pageIds.isNotEmpty() && "is_in_trash_bin" in pageCols) {
            val activeIds = HashSet<String>()
            runCatching {
                db.rawQuery("SELECT id FROM PageEntity WHERE is_in_trash_bin = 0", null).use { c ->
                    while (c.moveToNext()) activeIds.add(c.getString(0))
                }
            }
            if (activeIds.isNotEmpty()) {
                pageIds = pageIds.filter { it in activeIds }
            }
        }

        // Fallback to creation_time only if page_list is genuinely absent or empty
        if (pageIds.isEmpty()) {
            val out = ArrayList<String>()
            val fallbackQuery = if ("is_in_trash_bin" in pageCols) {
                "SELECT id FROM PageEntity WHERE is_in_trash_bin = 0 ORDER BY creation_time ASC"
            } else {
                "SELECT id FROM PageEntity ORDER BY creation_time ASC"
            }
            runCatching {
                db.rawQuery(fallbackQuery, null).use { c ->
                    while (c.moveToNext()) out.add(c.getString(0))
                }
            }
            pageIds = out
        }

        return NoteHeader(pageIds, unbounded)
    }

    private fun countTable(db: SQLiteDatabase, table: String): Int {
        return try {
            db.rawQuery("SELECT COUNT(*) FROM $table", null).use { c ->
                if (c.moveToFirst()) c.getInt(0) else 0
            }
        } catch (_: Exception) {
            0
        }
    }

    private fun findPdfPageIndex(obj: JSONObject?): Int? {
        if (obj == null) return null
        val indexKeys = listOf("pageNum", "pdfPageIndex", "pdf_page_index", "pdfIndex", "pageIndex", "page_index")
        for (k in indexKeys) {
            if (obj.has(k) && !obj.isNull(k)) {
                val v = obj.optInt(k, -1)
                if (v >= 0) return v
            }
        }
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val child = obj.optJSONObject(k)
            if (child != null) {
                findPdfPageIndex(child)?.let { return it }
            }
        }
        return null
    }

    private fun findPdfRef(obj: JSONObject?): String? {
        if (obj == null) return null
        val refKeys = listOf("pdfId", "pdf_id", "pdfInfoId", "pdf_info_id", "pdfFileId", "fileId", "pdfPath", "filePath", "uri", "path", "fileName")
        for (k in refKeys) {
            if (obj.has(k) && !obj.isNull(k)) {
                val v = obj.optString(k)
                if (v.isNotBlank()) return v
            }
        }
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val child = obj.optJSONObject(k)
            if (child != null) {
                findPdfRef(child)?.let { return it }
            }
        }
        return null
    }

    private fun readPageEntity(db: SQLiteDatabase, pid: String, hasEmbeddedPdf: Boolean): PageSpec? {
        db.rawQuery(
            "SELECT paper_spec, page_orientation, paper_theme, rotation_direction_index, unbounded, paper_padding, padding_color, padding_style_json, source FROM PageEntity WHERE id = ?",
            arrayOf(pid),
        ).use { c ->
            if (!c.moveToFirst()) return null
            val specRaw = if (c.isNull(0)) null else c.getString(0)
            val orient = if (c.isNull(1)) "" else (c.getString(1) ?: "")
            val themeRaw = if (c.isNull(2)) null else c.getString(2)
            val rotSteps = if (c.isNull(3)) 0 else c.getInt(3)
            val unbounded = !c.isNull(4) && c.getInt(4) != 0
            val padRaw = if (c.isNull(5)) null else c.getString(5)
            val padColorCol = if (c.isNull(6)) 0 else c.getInt(6)
            val padStyleRaw = if (c.isNull(7)) null else c.getString(7)
            val sourceCol = if (c.isNull(8)) 0 else c.getInt(8)

            var w = 1240f
            var h = 1754f
            var hasExplicitSize = false
            var specObj: JSONObject? = null
            if (!specRaw.isNullOrBlank()) {
                runCatching {
                    specObj = JSONObject(specRaw)
                    val sw = specObj!!.optDouble("width", -1.0).toFloat()
                    val sh = specObj!!.optDouble("height", -1.0).toFloat()
                    if (sw.isFinite() && sw > 10f && sh.isFinite() && sh > 10f) {
                        w = sw
                        h = sh
                        hasExplicitSize = true
                    }
                }
            }
            if (orient == "HORIZONTAL" && w < h) {
                val tmp = w; w = h; h = tmp
            }

            var bgColor = Color.WHITE
            var themeObj: JSONObject? = null
            if (!themeRaw.isNullOrBlank()) {
                runCatching {
                    themeObj = JSONObject(themeRaw)
                    val base = themeObj!!.optJSONObject("baseTheme")
                    if (base != null && base.has("color")) {
                        bgColor = base.getInt("color")
                    } else if (themeObj!!.has("color")) {
                        bgColor = themeObj!!.getInt("color")
                    }
                }
            }

            // Parse extended page borders (`paper_padding` + `padding_style_json` / `padding_color`)
            var padL = 0f; var padT = 0f; var padR = 0f; var padB = 0f
            if (!padRaw.isNullOrBlank()) {
                runCatching {
                    val po = JSONObject(padRaw)
                    padL = po.optDouble("left", 0.0).toFloat().coerceAtLeast(0f)
                    padT = po.optDouble("top", 0.0).toFloat().coerceAtLeast(0f)
                    padR = po.optDouble("right", 0.0).toFloat().coerceAtLeast(0f)
                    padB = po.optDouble("bottom", 0.0).toFloat().coerceAtLeast(0f)
                }
            }
            var padBgColor = if (padColorCol != 0) padColorCol else bgColor
            if (!padStyleRaw.isNullOrBlank()) {
                runCatching {
                    val ps = JSONObject(padStyleRaw)
                    val th = ps.optJSONObject("theme") ?: ps
                    val base = th.optJSONObject("baseTheme")
                    if (base != null && base.has("color")) {
                        padBgColor = base.getInt("color")
                    }
                }
            }

            // Strict PDF page classification: Notein uses source == 2 and PdfPaperTheme with exact 0-based pageNum
            val themeType = themeObj?.optString("type").orEmpty()
            val isPdfTheme = themeType.contains("PdfPaperTheme", ignoreCase = true) ||
                themeType.contains("pdf", ignoreCase = true)
            val isPdfPage = hasEmbeddedPdf && (isPdfTheme || (sourceCol == 2 && themeType.isBlank()))
            val explicitIdx = if (isPdfPage) {
                findPdfPageIndex(themeObj) ?: findPdfPageIndex(specObj)
            } else {
                null
            }
            val pdfRef = if (isPdfPage) {
                findPdfRef(themeObj) ?: findPdfRef(specObj)
            } else {
                null
            }

            return PageSpec(
                width = w,
                height = h,
                hasExplicitSize = hasExplicitSize,
                bgColor = bgColor,
                padLeft = padL,
                padTop = padT,
                padRight = padR,
                padBottom = padB,
                padBgColor = padBgColor,
                isPdfPage = isPdfPage,
                explicitPdfPageIndex = explicitIdx,
                pdfRef = pdfRef,
                rotationSteps = rotSteps,
                unbounded = unbounded,
            )
        }
    }

    private fun loadPageStrokes(
        db: SQLiteDatabase,
        pid: String,
        hiddenLayers: Set<String>,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            val strokeIds = ArrayList<String>()
            db.rawQuery("SELECT id, layer_id FROM StrokeEntity WHERE page_id = ?", arrayOf(pid)).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(1)) "" else (c.getString(1) ?: "")
                    if (!isLayerVisible(lid, hiddenLayers)) continue
                    strokeIds.add(c.getString(0))
                }
            }
            val strokeCols = tableColumns(db, "StrokeEntity")
            val hasRecordJson = "record_json" in strokeCols
            val selectCols = if (hasRecordJson) {
                "creation_time, ink_stroke_blob, record_json"
            } else {
                "creation_time, ink_stroke_blob, NULL"
            }
            val batchSize = 100
            var offset = 0
            while (offset < strokeIds.size) {
                val end = minOf(offset + batchSize, strokeIds.size)
                val sub = strokeIds.subList(offset, end)
                val placeholders = sub.joinToString(",") { "?" }
                db.rawQuery(
                    "SELECT $selectCols FROM StrokeEntity WHERE id IN ($placeholders)",
                    sub.toTypedArray(),
                ).use { c ->
                    while (c.moveToNext()) {
                        val ctime = if (c.isNull(0)) 0L else c.getLong(0)
                        val blob = if (c.isNull(1)) null else c.getBlob(1)
                        if (blob != null && blob.isNotEmpty()) {
                            runCatching { StrokeDecoder.decode(blob) }
                                .onSuccess { out.add(DrawItem.StrokeItem(ctime, it)) }
                                .onFailure { warnings.add("skipped undecodable stroke: ${it.message}") }
                        } else {
                            val recJson = if (c.isNull(2)) null else c.getString(2)
                            val parsed = parseRecordJsonStroke(ctime, recJson)
                            if (parsed != null) {
                                out.add(parsed)
                            } else {
                                warnings.add("skipped empty/unparseable record_json stroke")
                            }
                        }
                    }
                }
                offset = end
            }
        } catch (e: Exception) {
            warnings.add("StrokeEntity read warning: ${e.message}")
        }
    }

    private fun loadPageShapes(
        db: SQLiteDatabase,
        pid: String,
        hiddenLayers: Set<String>,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT creation_time, color, width, type, blend_mode, points, layer_id, tape_like FROM ShapeEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(6)) "" else (c.getString(6) ?: "")
                    val tapeLike = if (c.isNull(7)) 0 else c.getInt(7)
                    if (!isLayerVisible(lid, hiddenLayers) || tapeLike != 0) continue
                    out.add(
                        DrawItem.ShapeItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            color = if (c.isNull(1)) Color.BLACK else c.getInt(1),
                            width = if (c.isNull(2)) 2f else c.getFloat(2),
                            type = if (c.isNull(3)) 0 else c.getInt(3),
                            blendMode = if (c.isNull(4)) 0 else c.getInt(4),
                            pointsJson = if (c.isNull(5)) "[]" else (c.getString(5) ?: "[]"),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("ShapeEntity read warning: ${e.message}")
        }
    }

    private fun parseBoundsJson(raw: String?): FloatArray? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val trimmed = raw.trim()
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() >= 4) {
                    floatArrayOf(
                        arr.getDouble(0).toFloat(),
                        arr.getDouble(1).toFloat(),
                        arr.getDouble(2).toFloat(),
                        arr.getDouble(3).toFloat(),
                    )
                } else null
            } else {
                val obj = JSONObject(trimmed)
                val target = obj.optJSONObject("rect")
                    ?: obj.optJSONObject("rectF")
                    ?: obj.optJSONObject("bounds")
                    ?: obj
                when {
                    target.has("left") && target.has("top") && target.has("right") && target.has("bottom") -> floatArrayOf(
                        target.getDouble("left").toFloat(),
                        target.getDouble("top").toFloat(),
                        target.getDouble("right").toFloat(),
                        target.getDouble("bottom").toFloat(),
                    )
                    target.has("x") && target.has("y") && target.has("width") && target.has("height") -> {
                        val x = target.getDouble("x").toFloat()
                        val y = target.getDouble("y").toFloat()
                        val w = target.getDouble("width").toFloat()
                        val h = target.getDouble("height").toFloat()
                        floatArrayOf(x, y, x + w, y + h)
                    }
                    else -> null
                }
            }
        }.getOrNull()
    }

    private fun loadPageImages(
        db: SQLiteDatabase,
        pid: String,
        hiddenLayers: Set<String>,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            db.rawQuery(
                "SELECT id, creation_time, uri, left, top, right, bottom, rotation, bounds, layer_id FROM ImageEntity WHERE page_id = ?",
                arrayOf(pid),
            ).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(9)) "" else (c.getString(9) ?: "")
                    if (!isLayerVisible(lid, hiddenLayers)) continue
                    val id = if (c.isNull(0)) "" else (c.getString(0) ?: "")
                    val ctime = if (c.isNull(1)) 0L else c.getLong(1)
                    val uri = if (c.isNull(2)) null else c.getString(2)
                    val hasCols = !c.isNull(3) && !c.isNull(4) && !c.isNull(5) && !c.isNull(6)
                    var l = if (hasCols) c.getFloat(3) else 0f
                    var t = if (hasCols) c.getFloat(4) else 0f
                    var r = if (hasCols) c.getFloat(5) else 0f
                    var b = if (hasCols) c.getFloat(6) else 0f
                    val rot = if (c.isNull(7)) 0f else c.getFloat(7)
                    val boundsRaw = if (c.isNull(8)) null else c.getString(8)

                    if (!hasCols || abs(r - l) < 1f || abs(b - t) < 1f) {
                        val parsed = parseBoundsJson(boundsRaw)
                        if (parsed != null) {
                            l = parsed[0]; t = parsed[1]; r = parsed[2]; b = parsed[3]
                        }
                    }

                    if (abs(r - l) < 1f || abs(b - t) < 1f) {
                        warnings.add("skipped image $id: missing bounds (bounds=$boundsRaw)")
                        continue
                    }

                    out.add(
                        DrawItem.ImageItem(
                            creationTime = ctime,
                            id = id,
                            uri = uri,
                            left = l,
                            top = t,
                            right = r,
                            bottom = b,
                            rotation = rot,
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("ImageEntity read warning: ${e.message}")
        }
    }

    private fun loadPageTextBoxes(
        db: SQLiteDatabase,
        pid: String,
        hiddenLayers: Set<String>,
        out: MutableList<DrawItem>,
        warnings: MutableSet<String>,
    ) {
        try {
            val cols = tableColumns(db, "TextBoxEntity")
            val hasBg = "background_color" in cols
            val hasLh = "line_height" in cols
            val hasBounds = "bounds" in cols
            val query = buildString {
                append("SELECT creation_time, text, text_size, default_text_color, left, top, right, bottom, layer_id")
                append(if (hasBg) ", background_color" else ", 0")
                append(if (hasLh) ", line_height" else ", 1.0")
                append(if (hasBounds) ", bounds" else ", NULL")
                append(" FROM TextBoxEntity WHERE page_id = ?")
            }
            db.rawQuery(query, arrayOf(pid)).use { c ->
                while (c.moveToNext()) {
                    val lid = if (c.isNull(8)) "" else (c.getString(8) ?: "")
                    if (!isLayerVisible(lid, hiddenLayers)) continue
                    val txt = if (c.isNull(1)) "" else (c.getString(1) ?: "")
                    if (txt.isBlank()) continue

                    val hasCols = !c.isNull(4) && !c.isNull(5) && !c.isNull(6) && !c.isNull(7)
                    var l = if (hasCols) c.getFloat(4) else 0f
                    var t = if (hasCols) c.getFloat(5) else 0f
                    var r = if (hasCols) c.getFloat(6) else 0f
                    var b = if (hasCols) c.getFloat(7) else 0f
                    if (!hasCols || abs(r - l) < 1f || abs(b - t) < 1f) {
                        val boundsRaw = if (c.isNull(11)) null else c.getString(11)
                        val parsed = parseBoundsJson(boundsRaw)
                        if (parsed != null) {
                            l = parsed[0]; t = parsed[1]; r = parsed[2]; b = parsed[3]
                        }
                    }
                    if (abs(r - l) < 1f || abs(b - t) < 1f) continue

                    out.add(
                        DrawItem.TextBoxItem(
                            creationTime = if (c.isNull(0)) 0L else c.getLong(0),
                            text = txt,
                            textSize = if (c.isNull(2)) 24f else c.getFloat(2),
                            color = if (c.isNull(3)) Color.BLACK else c.getInt(3),
                            bgColor = if (c.isNull(9)) 0 else c.getInt(9),
                            lineHeight = if (c.isNull(10)) 1.0f else c.getFloat(10).coerceIn(0.6f, 3.0f),
                            left = l,
                            top = t,
                            right = r,
                            bottom = b,
                        )
                    )
                }
            }
        } catch (e: Exception) {
            warnings.add("TextBoxEntity read warning: ${e.message}")
        }
    }

    private fun drawSourcePdfPage(
        canvas: Canvas,
        renderer: PdfRenderer,
        pageIndex: Int,
        dstRect: RectF,
        warnings: MutableSet<String>,
    ) {
        try {
            renderer.openPage(pageIndex).use { srcPage ->
                val dw = dstRect.width().coerceAtLeast(10f)
                val dh = dstRect.height().coerceAtLeast(10f)
                val maxDim = 1400f
                val scale = minOf(1.5f, maxDim / max(dw, dh))
                val bmpW = (dw * scale).roundToInt().coerceIn(100, 1400)
                val bmpH = (dh * scale).roundToInt().coerceIn(100, 1600)
                val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                try {
                    bmp.eraseColor(Color.WHITE)
                    srcPage.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    canvas.drawBitmap(bmp, null, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))
                } finally {
                    bmp.recycle()
                }
            }
        } catch (e: Exception) {
            warnings.add("source PDF page ${pageIndex + 1} render warning: ${e.message}")
        }
    }

    private fun drawStroke(canvas: Canvas, decoded: StrokeDecoder.DecodedStroke, widthModel: String, isDarkPage: Boolean) {
        val curve = StrokeDecoder.toCurve(decoded, widthModel)
        if (curve.xs.isEmpty()) return

        val rawAlpha = (curve.argbColor ushr 24) and 0xFF
        val isHighlighter = decoded.isHighlighter || rawAlpha in 1..245
        val finalColor = if (isHighlighter) {
            val capped = rawAlpha.coerceAtMost(88)
            (capped shl 24) or (curve.argbColor and 0x00FFFFFF)
        } else {
            curve.argbColor
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = finalColor
            strokeCap = if (isHighlighter) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (isHighlighter && !isDarkPage) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            }
        }

        if (curve.isDot) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(
                curve.xs[0] * PT,
                curve.ys[0] * PT,
                (curve.widths[0] * PT / 2f).coerceAtLeast(0.25f),
                paint,
            )
            return
        }

        paint.style = Paint.Style.STROKE
        val n = curve.xs.size
        val q = IntArray(n) { safeRound(curve.widths[it] / 0.25f, 6) }
        var i = 0
        val path = Path()
        while (i < n - 1) {
            var j = i
            while (j < n - 1 && abs(q[j] - q[i]) <= 1) {
                j++
            }
            if (j == i) j = i + 1
            var sumW = 0f
            for (k in i..j) sumW += curve.widths[k]
            paint.strokeWidth = ((sumW / (j - i + 1)) * PT).coerceIn(0.15f, 300f)

            path.reset()
            path.moveTo(curve.xs[i] * PT, curve.ys[i] * PT)
            for (k in (i + 1)..j) {
                path.lineTo(curve.xs[k] * PT, curve.ys[k] * PT)
            }
            canvas.drawPath(path, paint)
            i = j
        }
    }

    private fun parseRecordJsonStroke(ctime: Long, raw: String?): DrawItem.RecordStrokeItem? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val obj = JSONObject(raw)
            val pts = obj.optJSONArray("points") ?: return@runCatching null
            val n = pts.length()
            if (n == 0) return@runCatching null
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            val ps = FloatArray(n)
            var count = 0
            for (i in 0 until n) {
                val pt = pts.optJSONObject(i) ?: continue
                val x = pt.optDouble("x", Double.NaN).toFloat()
                val y = pt.optDouble("y", Double.NaN).toFloat()
                if (!x.isFinite() || !y.isFinite()) continue
                val p = pt.optDouble("p", 1.0).toFloat()
                xs[count] = x
                ys[count] = y
                ps[count] = if (p.isFinite() && p > 0f) p else 1f
                count++
            }
            if (count == 0) return@runCatching null
            val color = obj.optInt("color", Color.BLACK)
            val width = obj.optDouble("width", 2.0).toFloat().let { if (it.isFinite() && it > 0f) it else 2f }
            val type = obj.optInt("type", 0)
            DrawItem.RecordStrokeItem(
                creationTime = ctime,
                color = color,
                width = width,
                type = type,
                xs = xs.copyOf(count),
                ys = ys.copyOf(count),
                ps = ps.copyOf(count),
            )
        }.getOrNull()
    }

    private fun drawRecordStroke(canvas: Canvas, item: DrawItem.RecordStrokeItem, isDarkPage: Boolean) {
        val n = item.xs.size
        if (n == 0) return

        val rawAlpha = (item.color ushr 24) and 0xFF
        if (rawAlpha == 0) return

        val isHighlighter = rawAlpha in 1..245
        val finalColor = if (isHighlighter) {
            val capped = rawAlpha.coerceAtMost(88)
            (capped shl 24) or (item.color and 0x00FFFFFF)
        } else {
            item.color
        }

        val strokeW = (item.width * PT).coerceIn(0.15f, 300f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = finalColor
            strokeWidth = strokeW
            strokeCap = if (isHighlighter) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (isHighlighter && !isDarkPage) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            }
        }

        if (n == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(item.xs[0] * PT, item.ys[0] * PT, (strokeW / 2f).coerceAtLeast(0.25f), paint)
            return
        }

        paint.style = Paint.Style.STROKE
        if (n == 2) {
            canvas.drawLine(item.xs[0] * PT, item.ys[0] * PT, item.xs[1] * PT, item.ys[1] * PT, paint)
            return
        }

        val path = Path()
        path.moveTo(item.xs[0] * PT, item.ys[0] * PT)
        for (i in 1 until n) {
            path.lineTo(item.xs[i] * PT, item.ys[i] * PT)
        }
        canvas.drawPath(path, paint)
    }

    /** Merges consecutive repeated points closer than `minDistPt` so Catmull-Rom splines do not degenerate. */
    private fun mergeConsecutivePoints(
        xs: FloatArray,
        ys: FloatArray,
        minDistPt: Float = 0.25f * PT,
    ): Pair<FloatArray, FloatArray> {
        val n = xs.size
        if (n <= 1) return xs to ys
        val outX = FloatArray(n)
        val outY = FloatArray(n)
        var count = 0
        outX[count] = xs[0]
        outY[count] = ys[0]
        count++
        for (i in 1 until n) {
            val dx = xs[i] - outX[count - 1]
            val dy = ys[i] - outY[count - 1]
            if (hypot(dx.toDouble(), dy.toDouble()) >= minDistPt.toDouble()) {
                outX[count] = xs[i]
                outY[count] = ys[i]
                count++
            }
        }
        return outX.copyOf(count) to outY.copyOf(count)
    }

    private fun drawArrowHead(
        canvas: Canvas,
        fromX: Float,
        fromY: Float,
        tipX: Float,
        tipY: Float,
        paint: Paint,
    ) {
        val segLen = hypot((tipX - fromX).toDouble(), (tipY - fromY).toDouble()).toFloat()
        if (segLen < 0.5f) return
        val angle = atan2((tipY - fromY).toDouble(), (tipX - fromX).toDouble())
        val headLen = min(segLen * 0.4f, (paint.strokeWidth * 5.0f).coerceIn(6f, 22f))
        val spread = Math.toRadians(28.0)
        val x1 = (tipX - headLen * cos(angle - spread)).toFloat()
        val y1 = (tipY - headLen * sin(angle - spread)).toFloat()
        val x2 = (tipX - headLen * cos(angle + spread)).toFloat()
        val y2 = (tipY - headLen * sin(angle + spread)).toFloat()
        val headPaint = Paint(paint).apply {
            pathEffect = null
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(tipX, tipY)
            lineTo(x2, y2)
        }
        canvas.drawPath(p, headPaint)
    }

    private fun drawCuboid(canvas: Canvas, xs: FloatArray, ys: FloatArray, paint: Paint) {
        var l = Float.POSITIVE_INFINITY
        var t = Float.POSITIVE_INFINITY
        var r = Float.NEGATIVE_INFINITY
        var b = Float.NEGATIVE_INFINITY
        for (i in xs.indices) {
            l = min(l, xs[i]); r = max(r, xs[i])
            t = min(t, ys[i]); b = max(b, ys[i])
        }
        val w = r - l
        val h = b - t
        if (w < 1f || h < 1f) return

        val dx = w * 0.25f
        val dy = h * 0.20f

        val solidPaint = Paint(paint).apply { pathEffect = null }
        val dashUnit = max(paint.strokeWidth * 3.0f, 3.0f)
        val dashedPaint = Paint(paint).apply {
            pathEffect = DashPathEffect(floatArrayOf(dashUnit, dashUnit), 0f)
        }

        // Front face (solid)
        canvas.drawRect(l, t + dy, r - dx, b, solidPaint)

        // Visible back edges & connectors (solid)
        val visible = Path().apply {
            moveTo(l, t + dy); lineTo(l + dx, t)
            lineTo(r, t); lineTo(r, b - dy)
            lineTo(r - dx, b)
            moveTo(r - dx, t + dy); lineTo(r, t)
        }
        canvas.drawPath(visible, solidPaint)

        // Hidden interior edges (dashed)
        val hidden = Path().apply {
            moveTo(l + dx, t); lineTo(l + dx, b - dy)
            lineTo(r, b - dy)
            moveTo(l, b); lineTo(l + dx, b - dy)
        }
        canvas.drawPath(hidden, dashedPaint)
    }

    private fun drawCylinder(canvas: Canvas, xs: FloatArray, ys: FloatArray, paint: Paint) {
        var l = Float.POSITIVE_INFINITY
        var t = Float.POSITIVE_INFINITY
        var r = Float.NEGATIVE_INFINITY
        var b = Float.NEGATIVE_INFINITY
        for (i in xs.indices) {
            l = min(l, xs[i]); r = max(r, xs[i])
            t = min(t, ys[i]); b = max(b, ys[i])
        }
        val w = r - l
        val h = b - t
        if (w < 1f || h < 1f) return

        val ry = min(h * 0.14f, w * 0.25f).coerceAtLeast(1f)
        val solidPaint = Paint(paint).apply { pathEffect = null }
        val dashUnit = max(paint.strokeWidth * 3.0f, 3.0f)
        val dashedPaint = Paint(paint).apply {
            pathEffect = DashPathEffect(floatArrayOf(dashUnit, dashUnit), 0f)
        }

        // Top ellipse (solid)
        canvas.drawOval(RectF(l, t, r, t + 2f * ry), solidPaint)

        // Left & right vertical walls (solid)
        canvas.drawLine(l, t + ry, l, b - ry, solidPaint)
        canvas.drawLine(r, t + ry, r, b - ry, solidPaint)

        // Bottom ellipse: front half solid, back half dashed
        val bottomRect = RectF(l, b - 2f * ry, r, b)
        canvas.drawArc(bottomRect, 0f, 180f, false, solidPaint)
        canvas.drawArc(bottomRect, 180f, 180f, false, dashedPaint)
    }

    private fun drawShape(canvas: Canvas, sh: DrawItem.ShapeItem, isDarkPage: Boolean, warnings: MutableSet<String>) {
        val ptsArr = JSONArray(sh.pointsJson)
        val n = ptsArr.length()
        if (n == 0) return

        val rawAlpha = (sh.color ushr 24) and 0xFF
        if (rawAlpha == 0) return // Invisible shape

        val isHighlighter = sh.blendMode == 13 || rawAlpha < 245
        val finalColor = if (isHighlighter) {
            val capped = if (sh.blendMode == 13) rawAlpha.coerceAtMost(95) else rawAlpha.coerceAtMost(115)
            (capped shl 24) or (sh.color and 0x00FFFFFF)
        } else {
            sh.color
        }

        val strokeW = (sh.width * PT).coerceIn(0.2f, 300f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = finalColor
            strokeWidth = strokeW
            strokeCap = if (isHighlighter) Paint.Cap.BUTT else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (isHighlighter && !isDarkPage) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            }
        }

        val xs = FloatArray(n)
        val ys = FloatArray(n)
        for (i in 0 until n) {
            val pt = ptsArr.getJSONObject(i)
            xs[i] = pt.optDouble("x", 0.0).toFloat() * PT
            ys[i] = pt.optDouble("y", 0.0).toFloat() * PT
        }

        // Type 6: Circle / Ellipse defined by 4 cardinal points [left, top, right, bottom] (may repeat to 7-8 pts)
        if (sh.type == 6 && n >= 4) {
            val cx = (xs[0] + xs[2]) / 2f
            val cy = (ys[0] + ys[2]) / 2f
            val dx = (xs[2] - xs[0]) / 2f
            val dy = (ys[2] - ys[0]) / 2f
            val rx = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            val ry = hypot(((xs[3] - xs[1]) / 2f).toDouble(), ((ys[3] - ys[1]) / 2f).toDouble()).toFloat()
            val angleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            if (rx >= 0.5f && ry >= 0.5f) {
                canvas.save()
                canvas.translate(cx, cy)
                if (abs(angleDeg) > 0.01f) canvas.rotate(angleDeg)
                canvas.drawOval(RectF(-rx, -ry, rx, ry), paint)
                canvas.restore()
                return
            }
        }

        // Type 8: Ellipse / Oval defined by 4 bounding-box corners [p0, p1, p2, p3] (supports rotation)
        if (sh.type == 8 && n >= 4) {
            val cx = (xs[0] + xs[2]) / 2f
            val cy = (ys[0] + ys[2]) / 2f
            val dx = xs[1] - xs[0]
            val dy = ys[1] - ys[0]
            val rx = hypot(dx.toDouble(), dy.toDouble()).toFloat() / 2f
            val ry = hypot((xs[2] - xs[1]).toDouble(), (ys[2] - ys[1]).toDouble()).toFloat() / 2f
            val angleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            if (rx >= 0.5f && ry >= 0.5f) {
                canvas.save()
                canvas.translate(cx, cy)
                if (abs(angleDeg) > 0.01f) canvas.rotate(angleDeg)
                canvas.drawOval(RectF(-rx, -ry, rx, ry), paint)
                canvas.restore()
                return
            }
        }
        if (sh.type == 8 && n == 2) {
            val l = min(xs[0], xs[1])
            val t = min(ys[0], ys[1])
            val r = max(xs[0], xs[1])
            val b = max(ys[0], ys[1])
            if (r - l >= 0.5f && b - t >= 0.5f) {
                canvas.drawOval(RectF(l, t, r, b), paint)
                return
            }
        }

        // Type 11: 3D Box (Cuboid)
        if (sh.type == 11 && n >= 4) {
            drawCuboid(canvas, xs, ys, paint)
            return
        }

        // Type 14: 3D Cylinder
        if (sh.type == 14 && n >= 4) {
            drawCylinder(canvas, xs, ys, paint)
            return
        }

        // Type 19: Dotted / dashed line
        if (sh.type == 19 && n >= 2) {
            val dashLen = max(strokeW * 3.0f, 3.0f)
            val gapLen = max(strokeW * 2.5f, 2.5f)
            paint.pathEffect = DashPathEffect(floatArrayOf(dashLen, gapLen), 0f)
            val path = Path()
            path.moveTo(xs[0], ys[0])
            for (i in 1 until n) path.lineTo(xs[i], ys[i])
            canvas.drawPath(path, paint)
            return
        }

        // Type 21: Single-ended arrow; Type 22: Double-ended arrow
        if ((sh.type == 21 || sh.type == 22) && n >= 2) {
            val path = Path()
            path.moveTo(xs[0], ys[0])
            for (i in 1 until n) path.lineTo(xs[i], ys[i])
            canvas.drawPath(path, paint)
            drawArrowHead(canvas, xs[n - 2], ys[n - 2], xs[n - 1], ys[n - 1], paint)
            if (sh.type == 22) {
                drawArrowHead(canvas, xs[1], ys[1], xs[0], ys[0], paint)
            }
            return
        }

        // Type 5 with 5 points = star (pentagram): straight edges, closed
        if (sh.type == 5 && n == 5) {
            val path = Path()
            path.moveTo(xs[0], ys[0])
            for (i in 1 until n) path.lineTo(xs[i], ys[i])
            path.close()
            canvas.drawPath(path, paint)
            return
        }

        // Curves (Type 0, or Type 5 with != 5 points): merge repeated points (< 0.25 units) before smoothing
        if (sh.type == 0 || sh.type == 5) {
            val (dxs, dys) = mergeConsecutivePoints(xs, ys)
            val dn = dxs.size
            if (dn == 2) {
                val path = Path()
                path.moveTo(dxs[0], dys[0])
                path.lineTo(dxs[1], dys[1])
                canvas.drawPath(path, paint)
                return
            }
            if (sh.type == 0 && dn == 3) {
                val path = Path()
                path.moveTo(dxs[0], dys[0])
                val cx = 2f * dxs[1] - 0.5f * (dxs[0] + dxs[2])
                val cy = 2f * dys[1] - 0.5f * (dys[0] + dys[2])
                path.quadTo(cx, cy, dxs[2], dys[2])
                canvas.drawPath(path, paint)
                return
            }
            if (dn >= 3) {
                val path = buildSmoothCurvePath(dxs, dys, closed = false)
                canvas.drawPath(path, paint)
                return
            }
        }

        // Standard polyline / closed polygon (lines, triangles, rectangles)
        val path = Path()
        path.moveTo(xs[0], ys[0])
        for (i in 1 until n) {
            path.lineTo(xs[i], ys[i])
        }
        if (sh.type in CLOSED_POLYGONS) {
            path.close()
        }
        canvas.drawPath(path, paint)

        if (sh.type !in KNOWN_SHAPE_TYPES) {
            warnings.add("unknown shape type ${sh.type}")
        }
    }

    /** Converts points into a smooth Catmull-Rom cubic Bezier path (open or closed). */
    private fun buildSmoothCurvePath(xs: FloatArray, ys: FloatArray, closed: Boolean): Path {
        val n = xs.size
        val path = Path()
        if (n == 0) return path
        path.moveTo(xs[0], ys[0])
        if (n == 1) return path
        if (n == 2) {
            path.lineTo(xs[1], ys[1])
            return path
        }
        val segs = if (closed) n else n - 1
        fun px(i: Int) = if (closed) xs[(i % n + n) % n] else xs[i.coerceIn(0, n - 1)]
        fun py(i: Int) = if (closed) ys[(i % n + n) % n] else ys[i.coerceIn(0, n - 1)]

        for (i in 0 until segs) {
            val p0x = px(i - 1); val p0y = py(i - 1)
            val p1x = px(i);     val p1y = py(i)
            val p2x = px(i + 1); val p2y = py(i + 1)
            val p3x = px(i + 2); val p3y = py(i + 2)

            val c1x = p1x + (p2x - p0x) / 6f
            val c1y = p1y + (p2y - p0y) / 6f
            val c2x = p2x - (p3x - p1x) / 6f
            val c2y = p2y - (p3y - p1y) / 6f
            path.cubicTo(c1x, c1y, c2x, c2y, p2x, p2y)
        }
        if (closed) path.close()
        return path
    }

    private fun decodeDownsampledBitmap(file: File, maxDim: Int = 1400): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) return null
        var sample = 1
        while (w / sample > maxDim || h / sample > maxDim) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    private fun resolveImageFile(im: DrawItem.ImageItem, mediaFiles: List<File>): File? {
        val uri = im.uri.orEmpty()
        val rawBase = uri.substringAfterLast('/').substringAfterLast('\\').substringBefore('?')
        val baseNoExt = rawBase.substringBeforeLast('.')

        if (rawBase.isNotBlank()) {
            mediaFiles.firstOrNull { it.name.equals(rawBase, ignoreCase = true) }?.let { return it }
        }
        val uriUuid = UUID_RE.find(uri)?.value
        if (!uriUuid.isNullOrBlank()) {
            mediaFiles.firstOrNull { it.name.contains(uriUuid, ignoreCase = true) }?.let { return it }
        }
        if (im.id.isNotBlank()) {
            mediaFiles.firstOrNull { it.name.contains(im.id, ignoreCase = true) }?.let { return it }
        }
        if (baseNoExt.length >= 6) {
            mediaFiles.firstOrNull { it.name.contains(baseNoExt, ignoreCase = true) }?.let { return it }
        }
        return null
    }

    private fun drawImage(
        canvas: Canvas,
        im: DrawItem.ImageItem,
        mediaFiles: List<File>,
        warnings: MutableSet<String>,
    ): Boolean {
        val imgFile = resolveImageFile(im, mediaFiles)
        if (imgFile == null || !imgFile.exists()) {
            val sampleNames = mediaFiles.take(5).joinToString(",") { it.name }
            warnings.add("image not found for uri='${im.uri}' id='${im.id}' (archive media: [$sampleNames])")
            return false
        }

        val bmp = decodeDownsampledBitmap(imgFile)
        if (bmp == null) {
            warnings.add("could not decode image ${imgFile.name}")
            return false
        }
        try {
            val l = im.left * PT
            val t = im.top * PT
            val r = im.right * PT
            val b = im.bottom * PT
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            val w = abs(r - l)
            val h = abs(b - t)
            if (w < 1f || h < 1f) return false
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(if (im.rotation.isFinite()) im.rotation else 0f)
            val dst = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)
            canvas.drawBitmap(bmp, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            return true
        } finally {
            bmp.recycle()
        }
    }

    private val STYLE_BLOCK_RE = Regex("(?is)<style[^>]*>.*?</style>")
    private val FONT_STYLE_COLOR_RE = Regex("(?i)style\\s*=\\s*\"[^\"]*?color\\s*:\\s*(#[0-9a-fA-F]{3,8})[^\"]*\"")

    private fun parseHtmlTextBox(raw: String): Pair<CharSequence, Int?> {
        if (!raw.contains("<")) return raw.replace("\uFEFF", "") to null

        // Strip <style>...</style> blocks so CSS rules are never rendered as visible text
        var cleaned = STYLE_BLOCK_RE.replace(raw, "").replace("\uFEFF", "")

        // Extract first explicit CSS color as fallback in case default_text_color is black on dark bg
        val firstHex = FONT_STYLE_COLOR_RE.find(cleaned)?.groupValues?.getOrNull(1)
        val fallbackColor = firstHex?.let { runCatching { Color.parseColor(it) }.getOrNull() }

        // Convert inline CSS `style="color:#ffffff"` into `<font color="#ffffff">` for Android Html.fromHtml
        cleaned = FONT_STYLE_COLOR_RE.replace(cleaned) { m -> "color=\"${m.groupValues[1]}\"" }
        cleaned = cleaned.trim()

        val spanned = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(cleaned, Html.FROM_HTML_MODE_LEGACY)
        } else {
            @Suppress("DEPRECATION")
            Html.fromHtml(cleaned)
        }
        return spanned.trim() to fallbackColor
    }

    private fun drawTextBox(canvas: Canvas, tb: DrawItem.TextBoxItem) {
        val l = min(tb.left, tb.right) * PT
        val t = min(tb.top, tb.bottom) * PT
        val r = max(tb.left, tb.right) * PT
        val b = max(tb.top, tb.bottom) * PT
        val boxW = safeRound(r - l, 200).coerceAtLeast(20)

        val (styledText, htmlFallbackColor) = parseHtmlTextBox(tb.text)
        if (styledText.isBlank()) return

        val bgAlpha = (tb.bgColor ushr 24) and 0xFF
        if (bgAlpha > 0) {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = tb.bgColor
            }
            canvas.drawRect(l, t, r, b, bgPaint)
        }

        val effectiveColor = htmlFallbackColor ?: (tb.color or (0xFF shl 24))
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = effectiveColor
            textSize = (tb.textSize * PT).coerceIn(6f, 144f)
        }
        val layout = StaticLayout.Builder.obtain(styledText, 0, styledText.length, paint, boxW)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, tb.lineHeight)
            .build()
        canvas.save()
        canvas.translate(l, t)
        layout.draw(canvas)
        canvas.restore()
    }

    /** Draws a subtle, always-visible bottom-right watermark adapting to dark vs light page backgrounds. */
    private fun drawWatermark(canvas: Canvas, text: String, pwPt: Int, phPt: Int, bgColor: Int) {
        val luma = 0.299 * Color.red(bgColor) + 0.587 * Color.green(bgColor) + 0.114 * Color.blue(bgColor)
        val isDark = luma < 128.0
        val sizePt = (min(pwPt, phPt) * 0.018f).coerceIn(8.5f, 22f)
        val margin = sizePt * 1.15f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sizePt
            textAlign = Paint.Align.RIGHT
            color = if (isDark) Color.argb(145, 248, 250, 252) else Color.argb(125, 15, 23, 42)
        }
        canvas.drawText(text, pwPt - margin, phPt - margin, paint)
    }

    internal fun extractZipSafe(zipFile: File, destDir: File) {
        val canonDest = destDir.canonicalPath + File.separator
        ZipFile(zipFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val outFile = File(destDir, entry.name)
                if (!outFile.canonicalPath.startsWith(canonDest)) {
                    throw SecurityException("Zip slip detected: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(outFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            }
        }
    }
}
