package com.notein2drive.ui

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Shared single-threaded PDFium worker across the app.
 * Android's PdfRenderer wraps native PDFium with a process-wide lock; keeping all open/render/close
 * operations on one shared daemon thread prevents thread leaks, native lock contention, and deadlocks
 * when switching between large PDFs.
 */
private object PdfRenderWorker {
    val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "notein-pdf-renderer").apply { isDaemon = true }
    }
    val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()
}

private data class PdfSession(
    val pfd: ParcelFileDescriptor,
    val renderer: PdfRenderer,
    val pageCount: Int,
    val defaultAspect: Float,
)

/**
 * Full-screen scrollable multi-page PDF viewer powered by Android's native `PdfRenderer`.
 * Uses a shared single-threaded worker, scroll-debounced rendering, and a tight byte-capped LRU cache
 * so large multi-page PDFs load smoothly without UI lag, stuck locks, or OOM crashes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfPreviewDialog(
    pdfFile: File,
    title: String,
    onDismiss: () -> Unit,
) {
    var session by remember(pdfFile) { mutableStateOf<PdfSession?>(null) }
    var errorMsg by remember(pdfFile) { mutableStateOf<String?>(null) }
    var zoom by remember(pdfFile) { mutableFloatStateOf(1.0f) }
    var pan by remember(pdfFile) { mutableStateOf(Offset.Zero) }

    val isClosed = remember(pdfFile) { AtomicBoolean(false) }
    val sessionRef = remember(pdfFile) { AtomicReference<PdfSession?>(null) }

    // Tight 16 MB bitmap cache (holds ~5-7 pages at 880-1080px without thrashing or OOM)
    val bitmapCache = remember(pdfFile) {
        val maxCacheKb = 16 * 1024
        object : LruCache<Int, Bitmap>(maxCacheKb) {
            override fun sizeOf(key: Int, value: Bitmap): Int {
                return (value.allocationByteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    LaunchedEffect(pdfFile) {
        isClosed.set(false)
        errorMsg = null
        session = null
        try {
            val opened = withContext(PdfRenderWorker.dispatcher) {
                if (isClosed.get()) return@withContext null
                if (!pdfFile.exists() || pdfFile.length() <= 0L) {
                    throw IllegalStateException("PDF file not found or empty")
                }
                val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = try {
                    PdfRenderer(pfd)
                } catch (t: Throwable) {
                    runCatching { pfd.close() }
                    throw t
                }
                val count = renderer.pageCount
                if (count <= 0) {
                    runCatching { renderer.close() }
                    runCatching { pfd.close() }
                    throw IllegalStateException("PDF has no pages")
                }
                val aspect = runCatching {
                    renderer.openPage(0).use { p0 ->
                        val pw = p0.width.coerceAtLeast(1).toFloat()
                        val ph = p0.height.coerceAtLeast(1).toFloat()
                        (pw / ph).coerceIn(0.25f, 3.0f)
                    }
                }.getOrDefault(0.707f)

                if (isClosed.get()) {
                    runCatching { renderer.close() }
                    runCatching { pfd.close() }
                    return@withContext null
                }
                val s = PdfSession(pfd, renderer, count, aspect)
                sessionRef.set(s)
                s
            }
            if (opened != null && !isClosed.get()) {
                session = opened
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            if (!isClosed.get()) {
                errorMsg = t.message ?: t.javaClass.simpleName
            }
        }
    }

    DisposableEffect(pdfFile) {
        onDispose {
            // Immediately short-circuit all pending page renders so close() runs next
            isClosed.set(true)
            session = null
            bitmapCache.evictAll()
            PdfRenderWorker.executor.execute {
                val s = sessionRef.getAndSet(null)
                runCatching { s?.renderer?.close() }
                runCatching { s?.pfd?.close() }
            }
        }
    }

    val pageCount = session?.pageCount ?: 0
    val listState = rememberLazyListState()
    val visiblePage by remember(pageCount) {
        derivedStateOf { (listState.firstVisibleItemIndex + 1).coerceIn(1, maxOf(1, pageCount)) }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.titleMedium,
                            )
                            if (pageCount > 0) {
                                Text(
                                    "Page $visiblePage of $pageCount  •  ${(zoom * 100).roundToInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close preview")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                zoom = (zoom - 0.5f).coerceAtLeast(1.0f)
                                if (zoom <= 1.01f) pan = Offset.Zero
                            },
                            enabled = zoom > 1.0f,
                        ) {
                            Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom out")
                        }
                        IconButton(
                            onClick = { zoom = (zoom + 0.5f).coerceAtMost(5.0f) },
                            enabled = zoom < 5.0f,
                        ) {
                            Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom in")
                        }
                        if (zoom > 1.05f) {
                            IconButton(onClick = { zoom = 1.0f; pan = Offset.Zero }) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "Reset zoom")
                            }
                        }
                    },
                )
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(Color(0xFF0B1120))
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                val pointerCount = event.changes.count { it.pressed }
                                if (pointerCount >= 2 || zoom > 1.05f) {
                                    val zoomChange = event.calculateZoom()
                                    val panChange = event.calculatePan()
                                    val nextZoom = (zoom * zoomChange).coerceIn(1.0f, 5.0f)
                                    zoom = nextZoom
                                    pan = if (nextZoom > 1.05f) {
                                        Offset(pan.x + panChange.x, pan.y + panChange.y)
                                    } else {
                                        Offset.Zero
                                    }
                                    if (pointerCount >= 2 || nextZoom > 1.05f) {
                                        event.changes.forEach { it.consume() }
                                    }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                val activeSession = session
                when {
                    errorMsg != null -> Text(
                        errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(24.dp),
                    )

                    activeSession != null && activeSession.pageCount > 0 -> {
                        // Use lighter bitmap dimensions on large PDFs to keep PDFium fast and memory low
                        val targetMaxDim = if (activeSession.pageCount > 30) 880f else 1080f
                        LazyColumn(
                            state = listState,
                            userScrollEnabled = zoom <= 1.05f,
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = zoom,
                                    scaleY = zoom,
                                    translationX = pan.x,
                                    translationY = pan.y,
                                ),
                        ) {
                            items(activeSession.pageCount, key = { it }) { idx ->
                                PdfPageCard(
                                    renderer = activeSession.renderer,
                                    pageIndex = idx,
                                    pageCount = activeSession.pageCount,
                                    defaultAspect = activeSession.defaultAspect,
                                    targetMaxDim = targetMaxDim,
                                    isClosed = isClosed,
                                    cache = bitmapCache,
                                )
                            }
                        }
                    }

                    else -> CircularProgressIndicator()
                }
            }
        }
    }
}

private fun renderPageSafe(
    renderer: PdfRenderer,
    pageIndex: Int,
    maxDim: Float,
): Bitmap {
    renderer.openPage(pageIndex).use { page ->
        val pw = page.width.coerceAtLeast(1).toFloat()
        val ph = page.height.coerceAtLeast(1).toFloat()
        val scale = minOf(1.5f, maxDim / max(pw, ph))
        val w = (pw * scale).roundToInt().coerceIn(32, maxDim.roundToInt())
        val h = (ph * scale).roundToInt().coerceIn(32, maxDim.roundToInt())
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.eraseColor(AndroidColor.WHITE)
        page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return b
    }
}

@Composable
private fun PdfPageCard(
    renderer: PdfRenderer,
    pageIndex: Int,
    pageCount: Int,
    defaultAspect: Float,
    targetMaxDim: Float,
    isClosed: AtomicBoolean,
    cache: LruCache<Int, Bitmap>,
) {
    var bmp by remember(pageIndex) { mutableStateOf(cache.get(pageIndex)) }
    var pageError by remember(pageIndex) { mutableStateOf<String?>(null) }
    var retryTick by remember(pageIndex) { mutableIntStateOf(0) }

    LaunchedEffect(pageIndex, retryTick) {
        if (bmp != null) return@LaunchedEffect
        // Fast scroll debounce: skip rendering pages that scroll off-screen within 75ms
        delay(75L)
        if (isClosed.get()) return@LaunchedEffect
        pageError = null
        try {
            val rendered = withContext(PdfRenderWorker.dispatcher) {
                ensureActive()
                if (!isActive || isClosed.get()) return@withContext null
                cache.get(pageIndex)?.let { return@withContext it }
                try {
                    val b = renderPageSafe(renderer, pageIndex, maxDim = targetMaxDim)
                    if (!isClosed.get()) cache.put(pageIndex, b)
                    b
                } catch (_: OutOfMemoryError) {
                    cache.evictAll()
                    System.gc()
                    val b = renderPageSafe(renderer, pageIndex, maxDim = 600f)
                    if (!isClosed.get()) cache.put(pageIndex, b)
                    b
                }
            }
            if (rendered != null && !isClosed.get()) {
                bmp = rendered
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            if (!isClosed.get()) {
                pageError = t.message ?: t.javaClass.simpleName
            }
        }
    }

    val imageBitmap = remember(bmp) { bmp?.asImageBitmap() }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth(),
    ) {
        when {
            imageBitmap != null && bmp != null -> {
                val rawAspect = bmp!!.width.toFloat() / bmp!!.height.toFloat().coerceAtLeast(1f)
                val safeAspect = rawAspect.coerceIn(0.18f, 4.0f)
                Image(
                    bitmap = imageBitmap,
                    contentDescription = "Page ${pageIndex + 1}",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(safeAspect)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.White),
                )
            }
            pageError != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B))
                        .clickable { retryTick++ }
                        .padding(16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "Unable to render page ${pageIndex + 1}\n($pageError)\nTap to retry",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center,
                    )
                }
            }
            else -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(defaultAspect)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B)),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Page ${pageIndex + 1} of $pageCount",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF94A3B8),
        )
    }
}
