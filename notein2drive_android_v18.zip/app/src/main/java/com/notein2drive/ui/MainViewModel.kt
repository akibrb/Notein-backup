package com.notein2drive.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.notein2drive.core.HierarchyDiscoverer
import com.notein2drive.drive.DriveMirror
import com.notein2drive.drive.GoogleAuthHelper
import com.notein2drive.sync.LocalExporter
import com.notein2drive.sync.ManifestStore
import com.notein2drive.sync.SyncEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.atomic.AtomicBoolean

data class LocalPdfItem(
    val relPath: String,
    val folderPath: String,
    val fileName: String,
    val file: File,
    val sizeBytes: Long,
    val syncedToDrive: Boolean,
)

data class ScannedNoteItem(
    val noteId: String,
    val title: String,
    val folderPath: String,
    val pdfRel: String,
)

data class FolderNode(
    val path: String,          // "" for Root (unfiled), "University", "University/EEE", etc.
    val name: String,          // Display name
    val parentPath: String?,   // null for top-level / Root
    val depth: Int,
    val directNotes: Int,
    val totalNotes: Int,
    val hasChildren: Boolean,  // true if has subfolders OR direct notes (so user can expand to pick notes)
)

data class UiState(
    val signedInEmail: String? = null,
    val appSha1: String = "",
    val sourceUri: Uri? = null,
    val sourceIsTree: Boolean = false,
    val sourceLabel: String = "No backup or folder selected",
    val localSaveUri: Uri? = null,
    val localSaveLabel: String = "App internal folder (tap Choose to pick device folder)",
    val rootFolderName: String = "Notein PDFs",
    val includeTrashed: Boolean = false,
    val forceReconvert: Boolean = false,
    val dryRun: Boolean = true,
    val pruneDeleted: Boolean = false,
    val watermarkEnabled: Boolean = false,
    val watermarkText: String = "",
    val busy: Boolean = false,
    val progress: Float = 0f,
    val statusLine: String = "Select a Notein backup.zip or folder to begin.",
    val folderNodes: List<FolderNode> = emptyList(),
    val scannedNotes: List<ScannedNoteItem> = emptyList(),
    val selectedNoteIds: Set<String> = emptySet(),
    val expandedFolders: Set<String> = emptySet(),
    val totalScannedNotes: Int = 0,
    val treePreview: String = "",
    val localPdfs: List<LocalPdfItem> = emptyList(),
    val previewPdf: LocalPdfItem? = null,
    val logs: List<String> = emptyList(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("notein2drive_prefs", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var account: GoogleSignInAccount? = null
    private var activeJob: Job? = null
    private val cancelFlag = AtomicBoolean(false)

    init {
        cleanStaleTempCache(application)
        val savedUriStr = prefs.getString("local_save_uri", null)
        val savedLabel = prefs.getString("local_save_label", null)
        val wmEnabled = prefs.getBoolean("watermark_enabled", false)
        val wmText = prefs.getString("watermark_text", "") ?: ""
        val sha1 = GoogleAuthHelper.getAppSha1(application)
        _state.update {
            it.copy(
                appSha1 = sha1,
                localSaveUri = savedUriStr?.let { s -> runCatching { Uri.parse(s) }.getOrNull() },
                localSaveLabel = savedLabel ?: it.localSaveLabel,
                watermarkEnabled = wmEnabled,
                watermarkText = wmText,
            )
        }
        refreshAccount()
        refreshLocalPdfs()
    }

    private fun cleanStaleTempCache(ctx: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            ctx.cacheDir.listFiles()?.forEach { f ->
                if (f.isDirectory && (
                        f.name.startsWith("notein_stage_") ||
                        f.name.startsWith("notein_zip_") ||
                        f.name.startsWith("notein_nested_") ||
                        f.name.startsWith("notein_conv_")
                    )
                ) {
                    f.deleteRecursively()
                }
            }
        }
    }

    private fun mirrorDir(): File {
        val ctx = getApplication<Application>()
        return File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Notein_PDFs")
    }

    fun cancelActiveTask() {
        cancelFlag.set(true)
        activeJob?.cancel()
        appendLog("! Cancelled by user (completed notes were saved).")
        _state.update { it.copy(busy = false, statusLine = "Cancelled. Already-converted notes were saved.") }
        refreshLocalPdfs()
    }

    fun refreshAccount() {
        val ctx = getApplication<Application>()
        account = GoogleAuthHelper.getLastSignedInAccount(ctx)
        _state.update { it.copy(signedInEmail = account?.email) }
    }

    fun refreshLocalPdfs() {
        viewModelScope.launch(Dispatchers.IO) {
            val root = mirrorDir()
            if (!root.exists()) {
                _state.update { it.copy(localPdfs = emptyList()) }
                return@launch
            }
            val manifest = ManifestStore.load(root)
            val syncedPaths = manifest.values
                .filter { !it.driveId.isNullOrBlank() }
                .map { it.pdfRel }
                .toSet()

            val items = root.walkTopDown()
                .filter { it.isFile && it.name.lowercase().endsWith(".pdf") }
                .map { f ->
                    val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
                    val slash = rel.lastIndexOf('/')
                    val folder = if (slash >= 0) rel.substring(0, slash) else "Root"
                    LocalPdfItem(
                        relPath = rel,
                        folderPath = folder,
                        fileName = f.name,
                        file = f,
                        sizeBytes = f.length(),
                        syncedToDrive = rel in syncedPaths,
                    )
                }
                .sortedBy { it.relPath.lowercase() }
                .toList()

            _state.update { it.copy(localPdfs = items) }
        }
    }

    fun onSignedIn(acct: GoogleSignInAccount?) {
        account = acct
        _state.update {
            it.copy(
                signedInEmail = acct?.email,
                statusLine = if (acct != null) "Connected as ${acct.email}" else "Google Sign-In cancelled",
            )
        }
    }

    fun onSignInFailed(t: Throwable) {
        val msg = GoogleAuthHelper.explainSignInError(t)
        appendLog("! $msg")
        _state.update { it.copy(statusLine = msg) }
    }

    fun setSource(uri: Uri, isTree: Boolean, label: String) {
        _state.update {
            it.copy(
                sourceUri = uri,
                sourceIsTree = isTree,
                sourceLabel = label,
                folderNodes = emptyList(),
                scannedNotes = emptyList(),
                selectedNoteIds = emptySet(),
                totalScannedNotes = 0,
                statusLine = "Selected: $label (tap Scan to choose folders or notes)",
            )
        }
    }

    fun setLocalSaveFolder(uri: Uri, label: String) {
        prefs.edit()
            .putString("local_save_uri", uri.toString())
            .putString("local_save_label", label)
            .apply()
        _state.update {
            it.copy(
                localSaveUri = uri,
                localSaveLabel = label,
                statusLine = "Local save folder set to: $label",
            )
        }
    }

    fun clearLocalSaveFolder() {
        prefs.edit().remove("local_save_uri").remove("local_save_label").apply()
        _state.update {
            it.copy(
                localSaveUri = null,
                localSaveLabel = "App internal folder (tap Choose to pick device folder)",
                statusLine = "Reset local save location to app internal folder.",
            )
        }
    }

    // -- Folder + per-note selection tree logic --------------------------------------------------

    private fun buildTree(entries: List<HierarchyDiscoverer.NoteEntry>): Pair<List<FolderNode>, List<ScannedNoteItem>> {
        val directCounts = HashMap<String, Int>()
        val allPaths = LinkedHashSet<String>()
        val notes = ArrayList<ScannedNoteItem>(entries.size)

        for (e in entries.sortedBy { it.pdfRel.lowercase() }) {
            val fullPath = e.folderParts.joinToString("/")
            directCounts[fullPath] = (directCounts[fullPath] ?: 0) + 1
            notes.add(ScannedNoteItem(e.noteId, e.title, fullPath, e.pdfRel))
            if (fullPath.isEmpty()) {
                allPaths.add("")
            } else {
                var acc = ""
                for (part in e.folderParts) {
                    acc = if (acc.isEmpty()) part else "$acc/$part"
                    allPaths.add(acc)
                }
            }
        }

        val nodes = allPaths.sortedWith(compareBy<String>({ it.isNotEmpty() }, { it.lowercase() })).map { path ->
            val isRoot = path.isEmpty()
            val parts = if (isRoot) emptyList() else path.split("/")
            val parent = when {
                isRoot -> null
                parts.size == 1 -> null
                else -> parts.dropLast(1).joinToString("/")
            }
            val direct = directCounts[path] ?: 0
            val total = if (isRoot) {
                direct
            } else {
                directCounts.entries.sumOf { (k, v) ->
                    if (k == path || k.startsWith("$path/")) v else 0
                }
            }
            val hasSubfolders = !isRoot && allPaths.any { it.startsWith("$path/") }
            FolderNode(
                path = path,
                name = if (isRoot) "Root (Unfiled notes)" else parts.last(),
                parentPath = parent,
                depth = if (isRoot) 0 else parts.size - 1,
                directNotes = direct,
                totalNotes = total,
                hasChildren = hasSubfolders || direct > 0,
            )
        }

        return nodes to notes
    }

    /** Returns all note IDs belonging to `folderPath` (direct notes + notes in any subfolder). */
    fun noteIdsUnder(folderPath: String, allNotes: List<ScannedNoteItem> = _state.value.scannedNotes): Set<String> {
        if (folderPath.isEmpty()) {
            return allNotes.filter { it.folderPath.isEmpty() }.mapTo(LinkedHashSet()) { it.noteId }
        }
        return allNotes.filter { it.folderPath == folderPath || it.folderPath.startsWith("$folderPath/") }
            .mapTo(LinkedHashSet()) { it.noteId }
    }

    fun toggleFolderSelection(folderPath: String) {
        _state.update { st ->
            val targets = noteIdsUnder(folderPath, st.scannedNotes)
            if (targets.isEmpty()) return@update st
            val allSelected = targets.all { it in st.selectedNoteIds }
            val updated = if (allSelected) st.selectedNoteIds - targets else st.selectedNoteIds + targets
            st.copy(selectedNoteIds = updated)
        }
    }

    fun toggleNoteSelection(noteId: String) {
        _state.update { st ->
            val updated = if (noteId in st.selectedNoteIds) st.selectedNoteIds - noteId else st.selectedNoteIds + noteId
            st.copy(selectedNoteIds = updated)
        }
    }

    fun selectAllNotes() = _state.update { st ->
        st.copy(selectedNoteIds = st.scannedNotes.map { it.noteId }.toSet())
    }

    fun clearAllNotes() = _state.update { it.copy(selectedNoteIds = emptySet()) }

    fun toggleFolderExpanded(folderPath: String) {
        _state.update { st ->
            val next = if (folderPath in st.expandedFolders) st.expandedFolders - folderPath else st.expandedFolders + folderPath
            st.copy(expandedFolders = next)
        }
    }

    fun expandAllFolders() = _state.update { st ->
        st.copy(expandedFolders = st.folderNodes.filter { it.hasChildren }.map { it.path }.toSet())
    }

    fun collapseAllFolders() = _state.update { it.copy(expandedFolders = emptySet()) }

    fun openPreview(item: LocalPdfItem) = _state.update { it.copy(previewPdf = item) }
    fun closePreview() = _state.update { it.copy(previewPdf = null) }
    fun clearLogs() = _state.update { it.copy(logs = emptyList()) }

    fun updateRootFolderName(v: String) = _state.update { it.copy(rootFolderName = v) }
    fun updateIncludeTrashed(v: Boolean) = _state.update { it.copy(includeTrashed = v) }
    fun updateForceReconvert(v: Boolean) = _state.update { it.copy(forceReconvert = v) }
    fun updateDryRun(v: Boolean) = _state.update { it.copy(dryRun = v) }
    fun updatePruneDeleted(v: Boolean) = _state.update { it.copy(pruneDeleted = v) }

    fun updateWatermarkEnabled(v: Boolean) {
        prefs.edit().putBoolean("watermark_enabled", v).apply()
        _state.update { it.copy(watermarkEnabled = v) }
    }

    fun updateWatermarkText(v: String) {
        prefs.edit().putString("watermark_text", v).apply()
        _state.update { it.copy(watermarkText = v) }
    }

    private fun appendLog(line: String) {
        _state.update { it.copy(logs = (it.logs + line).takeLast(400)) }
    }

    fun scan() {
        val st = _state.value
        val uri = st.sourceUri ?: return
        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Reading & unpacking source...", logs = emptyList()) }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                inv = HierarchyDiscoverer.discoverFromUri(getApplication(), uri, st.sourceIsTree, st.includeTrashed)
                val (nodes, notes) = buildTree(inv.entries)
                val allIds = notes.map { it.noteId }.toSet()
                val defaultExpanded = if (notes.size <= 15) {
                    nodes.filter { it.hasChildren }.map { it.path }.toSet()
                } else {
                    emptySet()
                }
                val tree = inv.renderTree().ifBlank { "(no notes found)" }
                inv.warnings.forEach { appendLog("warning: $it") }
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        folderNodes = nodes,
                        scannedNotes = notes,
                        selectedNoteIds = allIds,
                        expandedFolders = defaultExpanded,
                        totalScannedNotes = notes.size,
                        treePreview = tree,
                        statusLine = "Found ${notes.size} note(s) in ${nodes.size} folder(s). Tap folders or individual notes below.",
                    )
                }
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Scan cancelled.") }
            } catch (e: Exception) {
                appendLog("! Scan error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Scan failed: ${e.message}") }
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun convertOrSync(uploadToDrive: Boolean) {
        val st = _state.value
        val uri = st.sourceUri ?: return
        if (uploadToDrive && !st.dryRun && account?.account == null) {
            _state.update { it.copy(statusLine = "Sign in with Google first to sync to Drive.") }
            return
        }
        if (st.scannedNotes.isNotEmpty() && st.selectedNoteIds.isEmpty()) {
            _state.update { it.copy(statusLine = "Select at least one folder or note before converting or syncing.") }
            return
        }

        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    busy = true,
                    progress = 0f,
                    statusLine = "Reading & unpacking source...",
                    logs = emptyList(),
                )
            }
            var inv: HierarchyDiscoverer.Inventory? = null
            try {
                val ctx = getApplication<Application>()
                inv = HierarchyDiscoverer.discoverFromUri(ctx, uri, st.sourceIsTree, st.includeTrashed)
                val (nodes, notes) = buildTree(inv.entries)
                val allIds = notes.map { it.noteId }.toSet()
                val activeSelection = if (st.scannedNotes.isNotEmpty()) st.selectedNoteIds else allIds
                val isPartialSelection = activeSelection.size < allIds.size

                val filteredEntries = inv.entries.filter { e -> e.noteId in activeSelection }
                val filteredInv = inv.copy(entries = filteredEntries)

                _state.update {
                    it.copy(
                        folderNodes = if (it.folderNodes.isEmpty()) nodes else it.folderNodes,
                        scannedNotes = if (it.scannedNotes.isEmpty()) notes else it.scannedNotes,
                        selectedNoteIds = if (it.scannedNotes.isEmpty()) allIds else it.selectedNoteIds,
                        totalScannedNotes = notes.size,
                        treePreview = filteredInv.renderTree(),
                    )
                }
                inv.warnings.forEach { appendLog("warning: $it") }

                val effectivePrune = if (st.pruneDeleted && isPartialSelection) {
                    appendLog("note: Partial selection active — pruning skipped to protect unselected notes.")
                    false
                } else {
                    st.pruneDeleted
                }

                val mirror = if (uploadToDrive && !st.dryRun) {
                    val token = GoogleAuthHelper.fetchAccessToken(ctx, account!!.account!!)
                    DriveMirror(accessToken = token, rootName = st.rootFolderName.ifBlank { "Notein PDFs" })
                } else null

                val outDir = mirrorDir()
                val summary = SyncEngine.run(
                    context = ctx,
                    inventory = filteredInv,
                    outDir = outDir,
                    mirror = mirror,
                    force = st.forceReconvert,
                    dryRun = uploadToDrive && st.dryRun,
                    prune = effectivePrune,
                    watermarkText = if (st.watermarkEnabled) st.watermarkText.takeIf { it.isNotBlank() } else null,
                    isCancelled = { cancelFlag.get() },
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                    log = { appendLog(it) },
                )

                var exportNote = ""
                val saveUri = st.localSaveUri
                if (saveUri != null && !(uploadToDrive && st.dryRun) && !cancelFlag.get()) {
                    val exp = LocalExporter.exportHierarchyToTree(
                        context = ctx,
                        mirrorRoot = outDir,
                        destTreeUri = saveUri,
                        isCancelled = { cancelFlag.get() },
                        onProgress = { done, total ->
                            val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                            _state.update { it.copy(progress = frac) }
                        },
                        onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                        log = { appendLog(it) },
                    )
                    exportNote = " • Saved locally: ${exp.exported} new, ${exp.skipped} unchanged"
                }

                val unchangedTotal = summary.skipped + summary.driveUnchanged
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Done (${filteredEntries.size} selected): ${summary.converted} converted, " +
                            "${summary.uploaded} uploaded, $unchangedTotal unchanged, ${summary.failed.size} failed.$exportNote",
                    )
                }
                refreshLocalPdfs()
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Cancelled. Completed notes were saved.") }
                refreshLocalPdfs()
            } catch (e: Exception) {
                appendLog("! Error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Failed: ${e.message}") }
                refreshLocalPdfs()
            } finally {
                inv?.cleanup()
            }
        }
    }

    fun exportAllToLocalFolder(destTreeUri: Uri, label: String? = null) {
        if (label != null) {
            setLocalSaveFolder(destTreeUri, label)
        }
        cancelFlag.set(false)
        activeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, statusLine = "Saving PDFs hierarchically to device folder...") }
            try {
                val res = LocalExporter.exportHierarchyToTree(
                    context = getApplication(),
                    mirrorRoot = mirrorDir(),
                    destTreeUri = destTreeUri,
                    isCancelled = { cancelFlag.get() },
                    onProgress = { done, total ->
                        val frac = if (total > 0) done.toFloat() / total.toFloat() else 1f
                        _state.update { it.copy(progress = frac) }
                    },
                    onStatus = { msg -> _state.update { it.copy(statusLine = msg) } },
                    log = { appendLog(it) },
                )
                _state.update {
                    it.copy(
                        busy = false,
                        progress = 1f,
                        statusLine = "Saved locally: ${res.exported} written, ${res.skipped} already up-to-date, ${res.failed} failed.",
                    )
                }
            } catch (ce: CancellationException) {
                _state.update { it.copy(busy = false, statusLine = "Local save cancelled.") }
            } catch (e: Exception) {
                appendLog("! Export error: ${e.message}")
                _state.update { it.copy(busy = false, statusLine = "Local save failed: ${e.message}") }
            }
        }
    }
}
