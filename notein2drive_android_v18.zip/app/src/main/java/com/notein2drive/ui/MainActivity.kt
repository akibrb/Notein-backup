package com.notein2drive.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CloudSync
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.notein2drive.drive.GoogleAuthHelper

private val NoteinDarkColors = darkColorScheme(
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF082F49),
    primaryContainer = Color(0xFF0C4A6E),
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = Color(0xFF34D399),
    onSecondary = Color(0xFF052E16),
    secondaryContainer = Color(0xFF064E3B),
    onSecondaryContainer = Color(0xFFD1FAE5),
    background = Color(0xFF0B1120),
    surface = Color(0xFF111827),
    surfaceVariant = Color(0xFF1E293B),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF334155),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = NoteinDarkColors) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Notein2DriveApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Notein2DriveApp(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var currentTab by remember { mutableIntStateOf(0) }

    val signInLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val acct = task.getResult(ApiException::class.java)
            vm.onSignedIn(acct)
        } catch (e: Exception) {
            vm.onSignInFailed(e)
        }
    }

    val pickFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            vm.setSource(uri, isTree = false, label = uri.lastPathSegment ?: "Selected Backup")
        }
    }

    val pickSourceFolderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val name = DocumentFile.fromTreeUri(context, uri)?.name ?: uri.lastPathSegment ?: "Selected Folder"
            vm.setSource(uri, isTree = true, label = name)
        }
    }

    val pickLocalSaveLocationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            val name = DocumentFile.fromTreeUri(context, uri)?.name ?: uri.lastPathSegment ?: "Device Folder"
            vm.setLocalSaveFolder(uri, name)
        }
    }

    val pickExportFolderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            val name = DocumentFile.fromTreeUri(context, uri)?.name ?: uri.lastPathSegment ?: "Device Folder"
            vm.exportAllToLocalFolder(uri, name)
        }
    }

    state.previewPdf?.let { item ->
        PdfPreviewDialog(
            pdfFile = item.file,
            title = item.relPath,
            onDismiss = vm::closePreview,
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Notein2Drive", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Exact folder mirror • Smart Drive sync",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Rounded.CloudSync, contentDescription = null) },
                    label = { Text("Sync") },
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1; vm.refreshLocalPdfs() },
                    icon = { Icon(Icons.Rounded.PictureAsPdf, contentDescription = null) },
                    label = { Text("PDFs (${state.localPdfs.size})") },
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Rounded.Terminal, contentDescription = null) },
                    label = { Text("Logs") },
                )
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
        ) {
            if (state.busy) {
                LinearProgressIndicator(
                    progress = { state.progress },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = state.statusLine,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    if (state.busy) {
                        TextButton(onClick = vm::cancelActiveTask) {
                            Text("Cancel", color = Color(0xFFF87171))
                        }
                    }
                }
            }

            when (currentTab) {
                0 -> SyncTab(
                    state = state,
                    vm = vm,
                    onSignIn = { signInLauncher.launch(GoogleAuthHelper.signInIntent(context)) },
                    onCopySha1 = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("App SHA-1", state.appSha1))
                        Toast.makeText(context, "SHA-1 copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    onPickFile = { pickFileLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    onPickFolder = { pickSourceFolderLauncher.launch(null) },
                    onPickLocalSave = { pickLocalSaveLocationLauncher.launch(null) },
                    onClearLocalSave = vm::clearLocalSaveFolder,
                    onRootNameChange = vm::updateRootFolderName,
                    onDryRunChange = vm::updateDryRun,
                    onPruneChange = vm::updatePruneDeleted,
                    onTrashedChange = vm::updateIncludeTrashed,
                    onForceChange = vm::updateForceReconvert,
                    onWatermarkEnabledChange = vm::updateWatermarkEnabled,
                    onWatermarkTextChange = vm::updateWatermarkText,
                    onScan = vm::scan,
                    onConvert = { vm.convertOrSync(uploadToDrive = false) },
                    onSync = { vm.convertOrSync(uploadToDrive = true) },
                )

                1 -> PdfsTab(
                    pdfs = state.localPdfs,
                    busy = state.busy,
                    onPreview = vm::openPreview,
                    onExportAllLocally = {
                        val existing = state.localSaveUri
                        if (existing != null) vm.exportAllToLocalFolder(existing)
                        else pickExportFolderLauncher.launch(null)
                    },
                    onChooseNewExportFolder = { pickExportFolderLauncher.launch(null) },
                )

                2 -> LogsTab(
                    logs = state.logs,
                    onClear = vm::clearLogs,
                )
            }
        }
    }
}

@Composable
private fun SyncTab(
    state: UiState,
    vm: MainViewModel,
    onSignIn: () -> Unit,
    onCopySha1: () -> Unit,
    onPickFile: () -> Unit,
    onPickFolder: () -> Unit,
    onPickLocalSave: () -> Unit,
    onClearLocalSave: () -> Unit,
    onRootNameChange: (String) -> Unit,
    onDryRunChange: (Boolean) -> Unit,
    onPruneChange: (Boolean) -> Unit,
    onTrashedChange: (Boolean) -> Unit,
    onForceChange: (Boolean) -> Unit,
    onWatermarkEnabledChange: (Boolean) -> Unit,
    onWatermarkTextChange: (String) -> Unit,
    onScan: () -> Unit,
    onConvert: () -> Unit,
    onSync: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // 1. Google Account card
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(
                            Icons.Rounded.AccountCircle,
                            contentDescription = null,
                            tint = if (state.signedInEmail != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(34.dp),
                        )
                        Column {
                            Text("Google Drive", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                state.signedInEmail ?: "Not connected",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    FilledTonalButton(onClick = onSignIn, enabled = !state.busy) {
                        Text(if (state.signedInEmail == null) "Sign in" else "Switch")
                    }
                }
                if (state.signedInEmail == null && state.appSha1.isNotBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("APK SHA-1 (for Cloud Console OAuth)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    state.appSha1,
                                    fontFamily = FontFamily.Monospace,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(onClick = onCopySha1) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy SHA-1", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // 2. Source picker card
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("1. Notein Source", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    state.sourceLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onPickFile,
                        enabled = !state.busy,
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Backup .zip")
                    }
                    OutlinedButton(
                        onClick = onPickFolder,
                        enabled = !state.busy,
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Folder")
                    }
                }
                OutlinedButton(
                    onClick = onScan,
                    enabled = !state.busy && state.sourceUri != null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Scan & Choose Folders")
                }
            }
        }

        // 3. Interactive Hierarchical Folder Selector (shown after Scan)
        if (state.folderNodes.isNotEmpty()) {
            FolderSelectionCard(state = state, vm = vm)
        }

        // 4. Selectable Local Save Location card
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2. Local Save Location (Hierarchical PDFs)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    state.localSaveLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.localSaveUri != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilledTonalButton(onClick = onPickLocalSave, enabled = !state.busy) {
                        Icon(Icons.Rounded.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (state.localSaveUri == null) "Choose Folder" else "Change Folder")
                    }
                    if (state.localSaveUri != null) {
                        TextButton(onClick = onClearLocalSave, enabled = !state.busy) {
                            Text("Reset")
                        }
                    }
                }
            }
        }

        // 5. Mirror options card
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("3. Sync & Mirror Options", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                OutlinedTextField(
                    value = state.rootFolderName,
                    onValueChange = onRootNameChange,
                    label = { Text("Google Drive Root Folder") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                OptionSwitch("Dry run (preview without uploading)", state.dryRun, onDryRunChange)
                OptionSwitch("Prune deleted notes & empty folders", state.pruneDeleted, onPruneChange)
                OptionSwitch("Include trashed notes", state.includeTrashed, onTrashedChange)
                OptionSwitch("Force re-convert & re-upload all", state.forceReconvert, onForceChange)
                OptionSwitch("Add bottom-right watermark", state.watermarkEnabled, onWatermarkEnabledChange)
                if (state.watermarkEnabled) {
                    OutlinedTextField(
                        value = state.watermarkText,
                        onValueChange = onWatermarkTextChange,
                        label = { Text("Watermark text (auto dark/light contrast)") },
                        placeholder = { Text("e.g. Your Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text(
                    "Identical files are matched by SHA-256 hash and skipped automatically so unchanged PDFs are never replaced on Drive.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // 6. Primary action buttons
        val selectedCount = state.selectedNoteIds.size
        val hasSelection = state.scannedNotes.isEmpty() || selectedCount > 0

        FilledTonalButton(
            onClick = onConvert,
            enabled = !state.busy && state.sourceUri != null && hasSelection,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(14.dp),
        ) {
            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                if (state.folderNodes.isNotEmpty()) "Convert Selected ($selectedCount notes)"
                else "Convert All Notes to PDF"
            )
        }

        Button(
            onClick = onSync,
            enabled = !state.busy && state.sourceUri != null && hasSelection,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(14.dp),
        ) {
            Icon(Icons.Rounded.CloudSync, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    state.dryRun -> "Preview Drive Sync (Dry Run)"
                    state.folderNodes.isNotEmpty() -> "Sync Selected ($selectedCount) to Google Drive"
                    else -> "Sync Changed PDFs to Google Drive"
                }
            )
        }
    }
}

@Composable
private fun FolderSelectionCard(
    state: UiState,
    vm: MainViewModel,
) {
    val selectedNotes = state.selectedNoteIds.size
    val notesByFolder = remember(state.scannedNotes) { state.scannedNotes.groupBy { it.folderPath } }

    val visibleNodes = remember(state.folderNodes, state.expandedFolders) {
        state.folderNodes.filter { node ->
            if (node.parentPath == null) {
                true
            } else {
                var p: String? = node.parentPath
                var ok = true
                while (p != null) {
                    if (p !in state.expandedFolders) {
                        ok = false
                        break
                    }
                    val slash = p.lastIndexOf('/')
                    p = if (slash >= 0) p.substring(0, slash) else null
                }
                ok
            }
        }
    }

    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Select Folders & Notes", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "$selectedNotes / ${state.totalScannedNotes} notes selected",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = vm::selectAllNotes,
                        enabled = !state.busy,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    ) { Text("Select All", style = MaterialTheme.typography.labelMedium) }
                    TextButton(
                        onClick = vm::clearAllNotes,
                        enabled = !state.busy,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    ) { Text("Clear", style = MaterialTheme.typography.labelMedium) }
                }
            }

            if (state.folderNodes.any { it.hasChildren }) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(
                        onClick = vm::expandAllFolders,
                        label = { Text("Expand all", style = MaterialTheme.typography.labelSmall) },
                    )
                    AssistChip(
                        onClick = vm::collapseAllFolders,
                        label = { Text("Collapse all", style = MaterialTheme.typography.labelSmall) },
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            visibleNodes.forEach { node ->
                val targets = vm.noteIdsUnder(node.path, state.scannedNotes)
                val selInFolder = targets.count { it in state.selectedNoteIds }
                val toggleState = when {
                    targets.isEmpty() || selInFolder == 0 -> ToggleableState.Off
                    selInFolder == targets.size -> ToggleableState.On
                    else -> ToggleableState.Indeterminate
                }
                val isExpanded = node.path in state.expandedFolders

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = (node.depth * 16).dp)
                        .clickable(enabled = !state.busy) {
                            if (node.hasChildren) vm.toggleFolderExpanded(node.path)
                            else vm.toggleFolderSelection(node.path)
                        }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (node.hasChildren) {
                        IconButton(
                            onClick = { vm.toggleFolderExpanded(node.path) },
                            modifier = Modifier.size(28.dp),
                        ) {
                            Icon(
                                if (isExpanded) Icons.Rounded.ExpandMore else Icons.Rounded.ChevronRight,
                                contentDescription = "Expand or collapse",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    } else {
                        Spacer(Modifier.width(28.dp))
                    }

                    TriStateCheckbox(
                        state = toggleState,
                        onClick = { if (!state.busy) vm.toggleFolderSelection(node.path) },
                    )

                    Icon(
                        Icons.Rounded.Folder,
                        contentDescription = null,
                        tint = if (toggleState != ToggleableState.Off) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = node.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = "$selInFolder/${node.totalNotes}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 6.dp),
                    )
                }

                // When this folder is expanded, show its individual notes for per-note toggling
                if (isExpanded) {
                    val directNotes = notesByFolder[node.path].orEmpty()
                    directNotes.forEach { note ->
                        val checked = note.noteId in state.selectedNoteIds
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = ((node.depth + 1) * 16 + 24).dp)
                                .clickable(enabled = !state.busy) { vm.toggleNoteSelection(note.noteId) }
                                .padding(vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = { if (!state.busy) vm.toggleNoteSelection(note.noteId) },
                            )
                            Icon(
                                Icons.Rounded.PictureAsPdf,
                                contentDescription = null,
                                tint = if (checked) Color(0xFFF87171) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (checked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfsTab(
    pdfs: List<LocalPdfItem>,
    busy: Boolean,
    onPreview: (LocalPdfItem) -> Unit,
    onExportAllLocally: () -> Unit,
    onChooseNewExportFolder: () -> Unit,
) {
    val grouped = remember(pdfs) { pdfs.groupBy { it.folderPath } }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Converted PDFs", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Tap any PDF to preview",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onChooseNewExportFolder,
                        enabled = !busy && pdfs.isNotEmpty(),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                    Button(
                        onClick = onExportAllLocally,
                        enabled = !busy && pdfs.isNotEmpty(),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Icon(Icons.Rounded.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Save All")
                    }
                }
            }
        }

        if (pdfs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No converted PDFs yet.\nGo to the Sync tab and tap Convert.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                grouped.forEach { (folder, files) ->
                    item(key = "hdr_$folder") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 6.dp, bottom = 2.dp),
                        ) {
                            Icon(
                                Icons.Rounded.Folder,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp),
                            )
                            Text(
                                folder,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                    items(files, key = { it.relPath }) { item ->
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPreview(item) },
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Icon(
                                    Icons.Rounded.PictureAsPdf,
                                    contentDescription = null,
                                    tint = Color(0xFFF87171),
                                    modifier = Modifier.size(28.dp),
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        item.fileName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        formatFileSize(item.sizeBytes) + if (item.syncedToDrive) "  •  Synced to Drive" else "  •  Local only",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                if (item.syncedToDrive) {
                                    Icon(
                                        Icons.Rounded.CheckCircle,
                                        contentDescription = "Synced",
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LogsTab(
    logs: List<String>,
    onClear: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Activity Log", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = onClear, enabled = logs.isNotEmpty()) {
                Text("Clear")
            }
        }
        ElevatedCard(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF020617)),
            modifier = Modifier.fillMaxSize(),
        ) {
            if (logs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No logs yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(logs) { line ->
                        Text(
                            line,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall,
                            color = when {
                                line.startsWith("!") -> Color(0xFFF87171)
                                line.startsWith("+") || line.contains("Drive created") || line.contains("Drive updated") -> Color(0xFF34D399)
                                line.startsWith("=") || line.contains("unchanged") -> Color(0xFF94A3B8)
                                else -> Color(0xFFE2E8F0)
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun formatFileSize(bytes: Long): String = when {
    bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
    bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "$bytes B"
}
